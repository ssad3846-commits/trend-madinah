import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTweetSchema, insertQuestionSchema, insertAnswerSchema, registerUserSchema, loginUserSchema, insertEventSchema, forgotPasswordSchema, resetPasswordSchema } from "@shared/schema";
import { z } from "zod";
import { setupAuth, isAuthenticated } from "./auth";
import { fetchTwitterTrends, fetchUserTweets } from "./twitter";
import { scrapeAndPostRegionalNews, postAllPrayerTimes } from "./news-scraper";
import { sendPasswordResetEmail } from "./gmail";
import { generateAppleAuthUrl, generateState, generateNonce, exchangeCodeForTokens, verifyAppleToken } from "./apple-oauth";

function formatArabicNumber(num: number): string {
  if (num >= 1000000) {
    return `${(num / 1000000).toFixed(1)} مليون`;
  } else if (num >= 1000) {
    return `${(num / 1000).toFixed(1)} ألف`;
  }
  return num.toString();
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  setupAuth(app);

  app.post("/api/auth/signup", async (req, res) => {
    try {
      const data = registerUserSchema.parse(req.body);
      
      const { handleExists, emailExists } = await storage.checkHandleOrEmailExists(data.handle, data.email);
      
      if (handleExists) {
        return res.status(400).json({ error: "اسم المستخدم محجوز، جرب اسم آخر" });
      }
      if (emailExists) {
        return res.status(400).json({ error: "البريد الإلكتروني مسجل مسبقاً" });
      }
      
      const user = await storage.createUserWithPassword(data);
      
      req.session.userId = user.id;
      
      const { passwordHash, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0]?.message || "بيانات غير صالحة" });
      }
      console.error("Error during signup:", error);
      res.status(500).json({ error: "فشل في إنشاء الحساب" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginUserSchema.parse(req.body);
      
      const user = await storage.verifyPassword(data.email, data.password);
      
      if (!user) {
        return res.status(401).json({ error: "البريد الإلكتروني أو كلمة المرور غير صحيحة" });
      }
      
      req.session.userId = user.id;
      
      const { passwordHash, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0]?.message || "بيانات غير صالحة" });
      }
      console.error("Error during login:", error);
      res.status(500).json({ error: "فشل في تسجيل الدخول" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "فشل في تسجيل الخروج" });
      }
      res.clearCookie("connect.sid");
      res.json({ message: "تم تسجيل الخروج بنجاح" });
    });
  });

  // Apple Sign In - Redirect to Apple OAuth
  app.get("/api/auth/apple", (req, res) => {
    try {
      const protocol = req.headers["x-forwarded-proto"] || req.protocol;
      const host = req.headers.host;
      const redirectUri = `${protocol}://${host}/api/auth/apple/callback`;
      
      // Generate CSRF state and nonce
      const state = generateState();
      const nonce = generateNonce();
      
      // Store in session for verification
      req.session.appleState = state;
      req.session.appleNonce = nonce;
      
      const authUrl = generateAppleAuthUrl(redirectUri, state, nonce);
      res.redirect(authUrl);
    } catch (error) {
      console.error("Error generating Apple auth URL:", error);
      res.redirect("/auth?error=apple_auth_failed");
    }
  });

  // Apple Sign In - Callback handler
  app.post("/api/auth/apple/callback", async (req, res) => {
    try {
      const { code, id_token, user: userInfo, state } = req.body;
      
      // Verify CSRF state
      if (!state || state !== req.session.appleState) {
        console.error("Apple OAuth state mismatch");
        return res.redirect("/auth?error=invalid_state");
      }
      
      // Clear state from session
      const expectedNonce = req.session.appleNonce;
      delete req.session.appleState;
      delete req.session.appleNonce;
      
      // Get protocol and host for redirect URI
      const protocol = req.headers["x-forwarded-proto"] || req.protocol;
      const host = req.headers.host;
      const redirectUri = `${protocol}://${host}/api/auth/apple/callback`;
      
      let payload: any = null;
      
      // Try to exchange code for tokens first
      if (code) {
        const tokens = await exchangeCodeForTokens(code, redirectUri);
        if (tokens && tokens.id_token) {
          payload = await verifyAppleToken(tokens.id_token, expectedNonce);
        }
      }
      
      // Fallback to id_token from form post
      if (!payload && id_token) {
        payload = await verifyAppleToken(id_token, expectedNonce);
      }
      
      if (!payload || !payload.sub) {
        return res.redirect("/auth?error=invalid_token");
      }

      const appleUserId = payload.sub;
      const email = payload.email || `${appleUserId}@privaterelay.appleid.com`;
      
      // Parse user info if provided (first sign-in only)
      let name = "مستخدم Apple";
      if (userInfo) {
        try {
          const parsedUser = typeof userInfo === "string" ? JSON.parse(userInfo) : userInfo;
          if (parsedUser.name) {
            name = `${parsedUser.name.firstName || ""} ${parsedUser.name.lastName || ""}`.trim() || name;
          }
        } catch (e) {
          console.error("Error parsing Apple user info:", e);
        }
      }

      // Check if user exists with this email
      let user = await storage.getUserByEmail(email);
      
      if (!user) {
        // Create new user with Apple ID (social login without password)
        const handle = `apple_${appleUserId.substring(0, 8)}`;
        user = await storage.createUser({
          name,
          handle,
          email,
          avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name)}`,
          verified: true,
        });
      }

      // Set session
      req.session.userId = user.id;
      
      // Redirect to home
      res.redirect("/");
    } catch (error) {
      console.error("Error during Apple callback:", error);
      res.redirect("/auth?error=apple_callback_failed");
    }
  });

  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const data = forgotPasswordSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(data.email);
      if (!user) {
        return res.status(404).json({ error: "البريد الإلكتروني غير مسجل" });
      }
      
      const code = await storage.createPasswordResetCode(data.email);
      
      const emailSent = await sendPasswordResetEmail(data.email, code);
      
      if (emailSent) {
        res.json({ 
          message: "تم إرسال رمز التحقق إلى بريدك الإلكتروني"
        });
      } else {
        res.json({ 
          message: "تم إرسال رمز التحقق إلى بريدك الإلكتروني",
          code: code
        });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0]?.message || "بيانات غير صالحة" });
      }
      console.error("Error during forgot password:", error);
      res.status(500).json({ error: "فشل في إرسال رمز التحقق" });
    }
  });

  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const data = resetPasswordSchema.parse(req.body);
      
      const isValid = await storage.verifyPasswordResetCode(data.email, data.code);
      if (!isValid) {
        return res.status(400).json({ error: "رمز التحقق غير صحيح أو منتهي الصلاحية" });
      }
      
      const success = await storage.resetPassword(data.email, data.newPassword);
      if (!success) {
        return res.status(500).json({ error: "فشل في تحديث كلمة المرور" });
      }
      
      res.json({ message: "تم تغيير كلمة المرور بنجاح" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0]?.message || "بيانات غير صالحة" });
      }
      console.error("Error during reset password:", error);
      res.status(500).json({ error: "فشل في تغيير كلمة المرور" });
    }
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "غير مسجل الدخول" });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        req.session.destroy(() => {});
        return res.status(401).json({ error: "المستخدم غير موجود" });
      }
      
      const { passwordHash, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      console.error("Error fetching current user:", error);
      res.status(500).json({ error: "فشل في جلب بيانات المستخدم" });
    }
  });

  app.patch("/api/auth/profile", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "غير مسجل الدخول" });
    }

    try {
      const { name, bio, location, website, twitter, snapchat, tiktok, linkedin } = req.body;
      
      const updates: Record<string, string | null> = {};
      if (name !== undefined) updates.name = name;
      if (bio !== undefined) updates.bio = bio || null;
      if (location !== undefined) updates.location = location || null;
      if (website !== undefined) updates.website = website || null;
      if (twitter !== undefined) updates.twitter = twitter || null;
      if (snapchat !== undefined) updates.snapchat = snapchat || null;
      if (tiktok !== undefined) updates.tiktok = tiktok || null;
      if (linkedin !== undefined) updates.linkedin = linkedin || null;

      const updatedUser = await storage.updateUser(req.session.userId, updates);
      if (!updatedUser) {
        return res.status(404).json({ error: "المستخدم غير موجود" });
      }

      const { passwordHash, ...safeUser } = updatedUser;
      res.json(safeUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ error: "فشل في تحديث الملف الشخصي" });
    }
  });

  app.get("/api/auth/check-handle/:handle", async (req, res) => {
    try {
      const handle = req.params.handle;
      const user = await storage.getUserByHandle(handle);
      res.json({ available: !user });
    } catch (error) {
      console.error("Error checking handle:", error);
      res.status(500).json({ error: "فشل في التحقق من اسم المستخدم" });
    }
  });

  // Get all tweets (optionally filtered by location) with pagination
  app.get("/api/tweets", async (req, res) => {
    try {
      const locationId = req.query.locationId as string | undefined;
      const limit = Math.min(parseInt(req.query.limit as string) || 30, 50);
      const offset = parseInt(req.query.offset as string) || 0;
      const tweets = await storage.getTweets(locationId, limit, offset);
      res.json(tweets);
    } catch (error) {
      console.error("Error fetching tweets:", error);
      res.status(500).json({ error: "Failed to fetch tweets" });
    }
  });

  // Get single tweet by ID
  app.get("/api/tweets/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const tweet = await storage.getTweetById(id);
      if (!tweet) {
        return res.status(404).json({ error: "Tweet not found" });
      }
      res.json(tweet);
    } catch (error) {
      console.error("Error fetching tweet:", error);
      res.status(500).json({ error: "Failed to fetch tweet" });
    }
  });

  // Get tweet replies
  app.get("/api/tweets/:id/replies", async (req, res) => {
    try {
      const tweetId = parseInt(req.params.id);
      const replies = await storage.getReplies(tweetId);
      res.json(replies);
    } catch (error) {
      console.error("Error fetching replies:", error);
      res.status(500).json({ error: "Failed to fetch replies" });
    }
  });

  // Create reply to tweet
  app.post("/api/tweets/:id/replies", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ error: "يجب تسجيل الدخول للرد" });
      }
      const tweetId = parseInt(req.params.id);
      const { content } = req.body;
      
      if (!content || content.trim().length === 0) {
        return res.status(400).json({ error: "محتوى الرد مطلوب" });
      }
      
      const reply = await storage.createReply(tweetId, req.session.userId, content.trim());
      res.status(201).json(reply);
    } catch (error) {
      console.error("Error creating reply:", error);
      res.status(500).json({ error: "Failed to create reply" });
    }
  });

  // Create new tweet
  app.post("/api/tweets", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ error: "Authentication required" });
      }
      const tweetData = insertTweetSchema.parse({
        ...req.body,
        userId: req.session.userId,
      });
      const tweet = await storage.createTweet(tweetData);
      res.status(201).json(tweet);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error creating tweet:", error);
      res.status(500).json({ error: "Failed to create tweet" });
    }
  });

  // Like a tweet
  app.post("/api/tweets/:id/like", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ error: "Authentication required" });
      }
      const id = parseInt(req.params.id);
      const result = await storage.likeTweet(id, req.session.userId);
      if (!result) {
        return res.status(404).json({ error: "Tweet not found" });
      }
      res.json(result);
    } catch (error) {
      console.error("Error liking tweet:", error);
      res.status(500).json({ error: "Failed to like tweet" });
    }
  });

  // Retweet a tweet
  app.post("/api/tweets/:id/retweet", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ error: "Authentication required" });
      }
      const id = parseInt(req.params.id);
      const result = await storage.retweetTweet(id, req.session.userId);
      if (!result) {
        return res.status(404).json({ error: "Tweet not found" });
      }
      res.json(result);
    } catch (error) {
      console.error("Error retweeting:", error);
      res.status(500).json({ error: "Failed to retweet" });
    }
  });

  // Get user liked tweets
  app.get("/api/users/:id/likes", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const tweets = await storage.getUserLikedTweets(userId);
      res.json(tweets);
    } catch (error) {
      console.error("Error fetching user likes:", error);
      res.status(500).json({ error: "Failed to fetch user likes" });
    }
  });

  // Get user retweeted tweets
  app.get("/api/users/:id/retweets", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const tweets = await storage.getUserRetweetedTweets(userId);
      res.json(tweets);
    } catch (error) {
      console.error("Error fetching user retweets:", error);
      res.status(500).json({ error: "Failed to fetch user retweets" });
    }
  });

  // Get user's like and retweet status for tweets
  app.post("/api/tweets/status", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.json({ likes: [], retweets: [] });
      }
      const tweetIds = req.body.tweetIds as number[];
      const [likes, retweets] = await Promise.all([
        storage.getUserLikeStatus(req.session.userId, tweetIds),
        storage.getUserRetweetStatus(req.session.userId, tweetIds),
      ]);
      res.json({ likes, retweets });
    } catch (error) {
      console.error("Error fetching tweet status:", error);
      res.status(500).json({ error: "Failed to fetch tweet status" });
    }
  });

  // Get all questions (optionally filtered by location)
  app.get("/api/questions", async (req, res) => {
    try {
      const locationId = req.query.locationId as string | undefined;
      const questions = await storage.getQuestions(locationId);
      
      if (questions.length === 0) {
        const defaultQuestions = [
          { id: 1, content: "وين أفضل مكان للفطور في المدينة؟", timestamp: "منذ ساعة", location: "المدينة المنورة", answersCount: 3 },
          { id: 2, content: "هل فيه حديقة مناسبة للأطفال قريبة من قباء؟", timestamp: "منذ 3 ساعات", location: "قباء", answersCount: 2 },
          { id: 3, content: "كم سعر تذكرة متحف دار المدينة؟", timestamp: "منذ 5 ساعات", location: "المدينة المنورة", answersCount: 1 },
        ];
        res.json(defaultQuestions);
      } else {
        res.json(questions);
      }
    } catch (error) {
      console.error("Error fetching questions:", error);
      res.status(500).json({ error: "Failed to fetch questions" });
    }
  });

  // Get single question by ID
  app.get("/api/questions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const question = await storage.getQuestionById(id);
      if (!question) {
        return res.status(404).json({ error: "Question not found" });
      }
      res.json(question);
    } catch (error) {
      console.error("Error fetching question:", error);
      res.status(500).json({ error: "Failed to fetch question" });
    }
  });

  // Create new question
  app.post("/api/questions", async (req, res) => {
    try {
      const questionData = insertQuestionSchema.parse(req.body);
      const question = await storage.createQuestion(questionData);
      res.status(201).json(question);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error creating question:", error);
      res.status(500).json({ error: "Failed to create question" });
    }
  });

  // Get answers for a question
  app.get("/api/questions/:id/answers", async (req, res) => {
    try {
      const questionId = parseInt(req.params.id);
      const answers = await storage.getAnswersByQuestion(questionId);
      res.json(answers);
    } catch (error) {
      console.error("Error fetching answers:", error);
      res.status(500).json({ error: "Failed to fetch answers" });
    }
  });

  // Create answer for a question
  app.post("/api/questions/:id/answers", async (req, res) => {
    try {
      const questionId = parseInt(req.params.id);
      const answerData = insertAnswerSchema.parse({
        ...req.body,
        questionId
      });
      const answer = await storage.createAnswer(answerData);
      res.status(201).json(answer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error creating answer:", error);
      res.status(500).json({ error: "Failed to create answer" });
    }
  });

  // Get all places (optionally filtered by location and category)
  app.get("/api/places", async (req, res) => {
    try {
      const locationId = req.query.locationId as string | undefined;
      const category = req.query.category as string | undefined;
      const places = await storage.getPlaces(locationId, category);
      
      if (places.length === 0) {
        const defaultPlaces = [
          { id: 1, name: "مطعم البيك", rating: 4.5, reviews: 1200, cuisine: "وجبات سريعة", image: "https://images.unsplash.com/photo-1544025162-d76694265947?w=600&h=400&fit=crop", location: "المدينة المنورة", locationId: "all", priceRange: "$$", googleMapsUrl: null, category: "RESTAURANT" },
          { id: 2, name: "مطعم الطازج", rating: 4.3, reviews: 850, cuisine: "مأكولات شعبية", image: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600&h=400&fit=crop", location: "المدينة المنورة", locationId: "all", priceRange: "$$", googleMapsUrl: null, category: "RESTAURANT" },
          { id: 3, name: "مطعم هرفي", rating: 4.2, reviews: 950, cuisine: "وجبات سريعة", image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&h=400&fit=crop", location: "المدينة المنورة", locationId: "all", priceRange: "$$", googleMapsUrl: null, category: "RESTAURANT" },
          { id: 4, name: "كافيه دوز", rating: 4.6, reviews: 420, cuisine: "قهوة مختصة", image: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=600&h=400&fit=crop", location: "المدينة المنورة", locationId: "all", priceRange: "$$", googleMapsUrl: null, category: "CAFE" },
          { id: 5, name: "كافيه بارنيز", rating: 4.4, reviews: 380, cuisine: "قهوة", image: "https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=600&h=400&fit=crop", location: "المدينة المنورة", locationId: "all", priceRange: "$$", googleMapsUrl: null, category: "CAFE" },
          { id: 6, name: "فندق المدينة موڤنبيك", rating: 4.8, reviews: 1500, cuisine: "فندق 5 نجوم", image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600&h=400&fit=crop", location: "المدينة المنورة", locationId: "all", priceRange: "$$$$", googleMapsUrl: null, category: "HOTEL" },
          { id: 7, name: "فندق دار الإيمان", rating: 4.6, reviews: 1200, cuisine: "فندق 4 نجوم", image: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=600&h=400&fit=crop", location: "المدينة المنورة", locationId: "all", priceRange: "$$$", googleMapsUrl: null, category: "HOTEL" },
          { id: 8, name: "فندق أنوار المدينة", rating: 4.5, reviews: 980, cuisine: "فندق 4 نجوم", image: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=600&h=400&fit=crop", location: "المدينة المنورة", locationId: "all", priceRange: "$$$", googleMapsUrl: null, category: "HOTEL" },
        ];
        
        let filtered = defaultPlaces;
        if (category) {
          filtered = filtered.filter(p => p.category === category);
        }
        res.json(filtered);
      } else {
        res.json(places);
      }
    } catch (error) {
      console.error("Error fetching places:", error);
      res.status(500).json({ error: "Failed to fetch places" });
    }
  });

  // Get single place by ID
  app.get("/api/places/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const place = await storage.getPlaceById(id);
      if (!place) {
        return res.status(404).json({ error: "Place not found" });
      }
      res.json(place);
    } catch (error) {
      console.error("Error fetching place:", error);
      res.status(500).json({ error: "Failed to fetch place" });
    }
  });

  // Get neighborhood engagement stats
  app.get("/api/neighborhoods/engagement", async (req, res) => {
    try {
      const engagement = await storage.getNeighborhoodEngagement();
      res.json(engagement);
    } catch (error) {
      console.error("Error fetching engagement stats:", error);
      res.status(500).json({ error: "Failed to fetch engagement stats" });
    }
  });

  // Get all live cameras (optionally filtered by location and category)
  app.get("/api/cameras", async (req, res) => {
    try {
      const locationId = req.query.locationId as string | undefined;
      const category = req.query.category as string | undefined;
      const cameras = await storage.getLiveCameras(locationId, category);
      res.json(cameras);
    } catch (error) {
      console.error("Error fetching cameras:", error);
      res.status(500).json({ error: "Failed to fetch cameras" });
    }
  });

  // Get single camera by ID
  app.get("/api/cameras/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const camera = await storage.getLiveCameraById(id);
      if (!camera) {
        return res.status(404).json({ error: "Camera not found" });
      }
      res.json(camera);
    } catch (error) {
      console.error("Error fetching camera:", error);
      res.status(500).json({ error: "Failed to fetch camera" });
    }
  });

  // Get all trends (optionally filtered by location)
  app.get("/api/trends", async (req, res) => {
    try {
      const locationId = req.query.locationId as string | undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      
      const dynamicTrends = await storage.getDynamicTrends(locationId, limit);
      
      const formattedTrends = dynamicTrends.map((trend, index) => ({
        id: index + 1,
        rank: index + 1,
        hashtag: trend.hashtag,
        posts: formatArabicNumber(trend.count),
        category: "ترند",
        locationId: trend.locationId || "all",
        createdAt: new Date().toISOString()
      }));
      
      if (formattedTrends.length === 0) {
        const staticTrends = await storage.getTrends(locationId, limit);
        if (staticTrends.length === 0) {
          const defaultTrends = [
            { id: 1, rank: 1, hashtag: "#المدينة_المنورة", posts: "متداول", category: "ترند", locationId: "all", createdAt: new Date().toISOString() },
            { id: 2, rank: 2, hashtag: "#المسجد_النبوي", posts: "متداول", category: "ترند", locationId: "all", createdAt: new Date().toISOString() },
            { id: 3, rank: 3, hashtag: "#طيبة_الطيبة", posts: "متداول", category: "ترند", locationId: "all", createdAt: new Date().toISOString() },
            { id: 4, rank: 4, hashtag: "#قباء", posts: "متداول", category: "ترند", locationId: "all", createdAt: new Date().toISOString() },
            { id: 5, rank: 5, hashtag: "#الحرم_النبوي", posts: "متداول", category: "ترند", locationId: "all", createdAt: new Date().toISOString() },
          ];
          res.json(defaultTrends.slice(0, limit));
        } else {
          res.json(staticTrends);
        }
      } else {
        res.json(formattedTrends);
      }
    } catch (error) {
      console.error("Error fetching trends:", error);
      res.status(500).json({ error: "Failed to fetch trends" });
    }
  });

  // Get Twitter trends for Saudi Arabia
  app.get("/api/twitter/trends", async (req, res) => {
    try {
      const trends = await fetchTwitterTrends();
      res.json(trends);
    } catch (error) {
      console.error("Error fetching Twitter trends:", error);
      res.status(500).json({ error: "Failed to fetch Twitter trends" });
    }
  });

  // Import tweets from Twitter user (ask_almadina)
  app.post("/api/twitter/import/:username", async (req, res) => {
    try {
      const username = req.params.username;
      const maxResults = parseInt(req.query.max as string) || 10;
      
      const twitterTweets = await fetchUserTweets(username, maxResults);
      
      if (twitterTweets.length === 0) {
        return res.status(404).json({ error: "No tweets found or user not found" });
      }

      let user = await storage.getUserByHandle(username);
      
      if (!user) {
        user = await storage.createUser({
          name: username === "ask_almadina" ? "اسأل المدينة" : username,
          handle: username,
          avatar: "https://images.unsplash.com/photo-1589309736404-2e142a2acdf0?w=100&h=100&fit=crop",
          bio: username === "ask_almadina" ? "دليل لتساؤلات سكان المدينة المنورة ونقل الأحداث التي تهم المجتمع المحلي" : null,
          verified: true,
        });
      }

      const importedTweets = [];
      for (const tweet of twitterTweets) {
        const newTweet = await storage.createTweet({
          userId: user.id,
          content: tweet.text,
          locationId: "all",
          locationName: "المدينة المنورة",
        });
        importedTweets.push(newTweet);
      }

      res.json({ 
        message: `Imported ${importedTweets.length} tweets from @${username}`,
        user,
        tweets: importedTweets 
      });
    } catch (error) {
      console.error("Error importing Twitter user tweets:", error);
      res.status(500).json({ error: "Failed to import tweets" });
    }
  });

  // Get all neighborhoods
  app.get("/api/neighborhoods", async (req, res) => {
    try {
      const neighborhoods = await storage.getNeighborhoods();
      res.json(neighborhoods);
    } catch (error) {
      console.error("Error fetching neighborhoods:", error);
      res.status(500).json({ error: "Failed to fetch neighborhoods" });
    }
  });

  // Search users
  app.get("/api/users/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query || query.trim().length === 0) {
        return res.json([]);
      }
      const users = await storage.searchUsers(query.trim());
      res.json(users);
    } catch (error) {
      console.error("Error searching users:", error);
      res.status(500).json({ error: "Failed to search users" });
    }
  });

  // Get user by handle
  app.get("/api/users/handle/:handle", async (req, res) => {
    try {
      const handle = req.params.handle;
      const user = await storage.getUserByHandle(handle);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user by handle:", error);
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  // Get user by ID
  app.get("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  // Get user tweets
  app.get("/api/users/:id/tweets", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const tweets = await storage.getTweetsByUser(userId);
      res.json(tweets);
    } catch (error) {
      console.error("Error fetching user tweets:", error);
      res.status(500).json({ error: "Failed to fetch user tweets" });
    }
  });

  // Follow/unfollow user
  app.post("/api/users/:id/follow", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ error: "Authentication required" });
      }
      const followingId = parseInt(req.params.id);
      const result = await storage.followUser(req.session.userId, followingId);
      res.json(result);
    } catch (error) {
      console.error("Error following user:", error);
      res.status(500).json({ error: error instanceof Error ? error.message : "Failed to follow user" });
    }
  });

  // Check if following user
  app.get("/api/users/:id/following", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.json({ following: false });
      }
      const followingId = parseInt(req.params.id);
      const isFollowing = await storage.isFollowing(req.session.userId, followingId);
      res.json({ following: isFollowing });
    } catch (error) {
      console.error("Error checking follow status:", error);
      res.status(500).json({ error: "Failed to check follow status" });
    }
  });

  // Get user's followers list
  app.get("/api/users/:id/followers", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const followers = await storage.getFollowers(userId);
      res.json(followers);
    } catch (error) {
      console.error("Error fetching followers:", error);
      res.status(500).json({ error: "Failed to fetch followers" });
    }
  });

  // Get user's following list
  app.get("/api/users/:id/following-list", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const following = await storage.getFollowing(userId);
      res.json(following);
    } catch (error) {
      console.error("Error fetching following:", error);
      res.status(500).json({ error: "Failed to fetch following" });
    }
  });

  // Hide/unhide account
  app.post("/api/users/:id/hide", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ error: "يجب تسجيل الدخول" });
      }
      const hiddenUserId = parseInt(req.params.id);
      
      if (req.session.userId === hiddenUserId) {
        return res.status(400).json({ error: "لا يمكنك إخفاء حسابك" });
      }
      
      const isHidden = await storage.isAccountHidden(req.session.userId, hiddenUserId);
      
      if (isHidden) {
        await storage.unhideAccount(req.session.userId, hiddenUserId);
        res.json({ hidden: false, message: "تم إظهار الحساب" });
      } else {
        await storage.hideAccount(req.session.userId, hiddenUserId);
        res.json({ hidden: true, message: "تم إخفاء الحساب" });
      }
    } catch (error) {
      console.error("Error hiding account:", error);
      res.status(500).json({ error: "فشل في إخفاء الحساب" });
    }
  });

  // Check if account is hidden
  app.get("/api/users/:id/hidden", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.json({ hidden: false });
      }
      const hiddenUserId = parseInt(req.params.id);
      const isHidden = await storage.isAccountHidden(req.session.userId, hiddenUserId);
      res.json({ hidden: isHidden });
    } catch (error) {
      console.error("Error checking hidden status:", error);
      res.status(500).json({ error: "Failed to check hidden status" });
    }
  });

  // Get all hidden accounts for current user
  app.get("/api/hidden-accounts", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ error: "يجب تسجيل الدخول" });
      }
      const hiddenAccounts = await storage.getHiddenAccounts(req.session.userId);
      res.json(hiddenAccounts);
    } catch (error) {
      console.error("Error fetching hidden accounts:", error);
      res.status(500).json({ error: "Failed to fetch hidden accounts" });
    }
  });

  // Get all events (optionally filtered by location)
  app.get("/api/events", async (req, res) => {
    try {
      const locationId = req.query.locationId as string | undefined;
      const events = await storage.getEvents(locationId);
      res.json(events);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ error: "فشل في جلب الفعاليات" });
    }
  });

  // Get single event by ID
  app.get("/api/events/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const event = await storage.getEventById(id);
      if (!event) {
        return res.status(404).json({ error: "الفعالية غير موجودة" });
      }
      res.json(event);
    } catch (error) {
      console.error("Error fetching event:", error);
      res.status(500).json({ error: "فشل في جلب الفعالية" });
    }
  });

  // Create new event
  app.post("/api/events", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ error: "يجب تسجيل الدخول لإنشاء فعالية" });
      }
      const eventData = insertEventSchema.parse({
        ...req.body,
        userId: req.session.userId,
      });
      const event = await storage.createEvent(eventData);
      res.status(201).json(event);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error creating event:", error);
      res.status(500).json({ error: "فشل في إنشاء الفعالية" });
    }
  });

  // Toggle event attendance (attending/interested)
  app.post("/api/events/:id/attend", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ error: "يجب تسجيل الدخول للتسجيل في الفعالية" });
      }
      const eventId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !["attending", "interested"].includes(status)) {
        return res.status(400).json({ error: "الحالة غير صالحة" });
      }
      
      const result = await storage.toggleEventAttendance(eventId, req.session.userId, status);
      res.json(result);
    } catch (error) {
      console.error("Error toggling event attendance:", error);
      res.status(500).json({ error: "فشل في تحديث حالة الحضور" });
    }
  });

  // Get user's event attendance status
  app.get("/api/events/:id/status", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.json({ status: null });
      }
      const eventId = parseInt(req.params.id);
      const status = await storage.getUserEventStatus(req.session.userId, eventId);
      res.json({ status });
    } catch (error) {
      console.error("Error fetching event status:", error);
      res.status(500).json({ error: "فشل في جلب حالة الفعالية" });
    }
  });

  // Chat Messages - Location-based chat within 10km radius
  app.get("/api/chat", async (req, res) => {
    try {
      const latitude = parseFloat(req.query.lat as string);
      const longitude = parseFloat(req.query.lng as string);
      const radius = req.query.radius ? parseFloat(req.query.radius as string) : 10;

      if (isNaN(latitude) || isNaN(longitude)) {
        return res.status(400).json({ error: "الموقع الجغرافي مطلوب" });
      }

      const messages = await storage.getChatMessagesNearby(latitude, longitude, radius);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ error: "فشل في جلب الرسائل" });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ error: "يجب تسجيل الدخول للدردشة" });
      }

      const { content, latitude, longitude } = req.body;

      if (!content || !latitude || !longitude) {
        return res.status(400).json({ error: "المحتوى والموقع مطلوبان" });
      }

      const message = await storage.createChatMessage({
        userId: req.session.userId,
        content,
        latitude: parseFloat(latitude),
        longitude: parseFloat(longitude)
      });

      res.status(201).json(message);
    } catch (error) {
      console.error("Error creating chat message:", error);
      res.status(500).json({ error: "فشل في إرسال الرسالة" });
    }
  });

  // Prayer Times API - Using AlAdhan (free, no API key required)
  const regionCities: Record<string, { city: string; lat: number; lng: number }> = {
    "1": { city: "Riyadh", lat: 24.7136, lng: 46.6753 },
    "2": { city: "Makkah", lat: 21.4225, lng: 39.8262 },
    "3": { city: "Madinah", lat: 24.5247, lng: 39.5692 },
    "4": { city: "Buraidah", lat: 26.3267, lng: 43.9750 },
    "5": { city: "Dammam", lat: 26.4207, lng: 50.0888 },
    "6": { city: "Abha", lat: 18.2164, lng: 42.5053 },
    "7": { city: "Tabuk", lat: 28.3838, lng: 36.5550 },
    "8": { city: "Hail", lat: 27.5114, lng: 41.7208 },
    "9": { city: "Arar", lat: 30.9753, lng: 41.0381 },
    "10": { city: "Jazan", lat: 16.8892, lng: 42.5511 },
    "11": { city: "Najran", lat: 17.4933, lng: 44.1277 },
    "12": { city: "Bahah", lat: 20.0125, lng: 41.4683 },
    "13": { city: "Sakaka", lat: 29.9697, lng: 40.2064 }
  };

  app.get("/api/prayer-times/:regionId", async (req, res) => {
    try {
      const regionId = req.params.regionId;
      const region = regionCities[regionId];
      
      if (!region) {
        return res.status(400).json({ error: "المنطقة غير موجودة" });
      }

      const today = new Date();
      const dateStr = `${today.getDate().toString().padStart(2, '0')}-${(today.getMonth() + 1).toString().padStart(2, '0')}-${today.getFullYear()}`;
      
      const response = await fetch(
        `https://api.aladhan.com/v1/timings/${dateStr}?latitude=${region.lat}&longitude=${region.lng}&method=4`
      );
      
      if (!response.ok) {
        throw new Error("Failed to fetch prayer times");
      }
      
      const data = await response.json();
      const timings = data.data.timings;
      const hijri = data.data.date.hijri;
      
      res.json({
        city: region.city,
        regionId,
        date: {
          gregorian: dateStr,
          hijri: `${hijri.day} ${hijri.month.ar} ${hijri.year}`
        },
        timings: {
          fajr: timings.Fajr,
          sunrise: timings.Sunrise,
          dhuhr: timings.Dhuhr,
          asr: timings.Asr,
          maghrib: timings.Maghrib,
          isha: timings.Isha
        }
      });
    } catch (error) {
      console.error("Error fetching prayer times:", error);
      res.status(500).json({ error: "فشل في جلب مواقيت الصلاة" });
    }
  });

  // Get automated accounts (news, universities, prayer_times)
  app.get("/api/accounts/automated", async (req, res) => {
    try {
      const type = req.query.type as string | undefined;
      const regionId = req.query.regionId as string | undefined;
      const accounts = await storage.getAutomatedAccounts(type, regionId);
      res.json(accounts);
    } catch (error) {
      console.error("Error fetching automated accounts:", error);
      res.status(500).json({ error: "فشل في جلب الحسابات" });
    }
  });

  // Trigger news scraping (admin endpoint)
  app.post("/api/admin/scrape-news", async (req, res) => {
    try {
      await scrapeAndPostRegionalNews();
      res.json({ success: true, message: "تم جلب ونشر الأخبار بنجاح" });
    } catch (error) {
      console.error("Error scraping news:", error);
      res.status(500).json({ error: "فشل في جلب الأخبار" });
    }
  });

  // Post prayer times for all regions (admin endpoint)
  app.post("/api/admin/post-prayer-times", async (req, res) => {
    try {
      await postAllPrayerTimes();
      res.json({ success: true, message: "تم نشر مواقيت الصلاة لجميع المناطق" });
    } catch (error) {
      console.error("Error posting prayer times:", error);
      res.status(500).json({ error: "فشل في نشر مواقيت الصلاة" });
    }
  });

  // Admin dashboard statistics
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ error: "فشل في جلب الإحصائيات" });
    }
  });

  // Admin login
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { login, password } = req.body;
      
      if (!login || !password) {
        return res.status(400).json({ error: "اسم المستخدم وكلمة المرور مطلوبان" });
      }
      
      const user = await storage.verifyPassword(login, password);
      
      if (!user) {
        return res.status(401).json({ error: "بيانات الدخول غير صحيحة" });
      }
      
      if (!user.isAdmin) {
        return res.status(403).json({ error: "ليس لديك صلاحية الوصول للوحة التحكم" });
      }
      
      req.session.adminId = user.id;
      
      res.json({ success: true, user: { id: user.id, name: user.name, handle: user.handle } });
    } catch (error) {
      console.error("Error during admin login:", error);
      res.status(500).json({ error: "فشل في تسجيل الدخول" });
    }
  });

  // Check admin session
  app.get("/api/admin/session", async (req, res) => {
    try {
      if (!req.session.adminId) {
        return res.status(401).json({ isAdmin: false });
      }
      
      const user = await storage.getUser(req.session.adminId);
      
      if (!user || !user.isAdmin) {
        return res.status(401).json({ isAdmin: false });
      }
      
      res.json({ isAdmin: true, user: { id: user.id, name: user.name, handle: user.handle } });
    } catch (error) {
      console.error("Error checking admin session:", error);
      res.status(500).json({ error: "فشل في التحقق من الجلسة" });
    }
  });

  // Admin logout
  app.post("/api/admin/logout", (req, res) => {
    delete req.session.adminId;
    res.json({ success: true });
  });

  return httpServer;
}
