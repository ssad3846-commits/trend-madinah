import { db } from "./storage";
import { places } from "@shared/schema";
import { eq } from "drizzle-orm";

const PEXELS_API_KEY = process.env.PEXELS_API_KEY;

interface PexelsPhoto {
  id: number;
  src: {
    medium: string;
    large: string;
  };
}

interface PexelsResponse {
  photos: PexelsPhoto[];
}

async function searchPexels(query: string): Promise<string | null> {
  if (!PEXELS_API_KEY) {
    console.error("PEXELS_API_KEY not found");
    return null;
  }

  try {
    const response = await fetch(
      `https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=1&orientation=landscape`,
      {
        headers: {
          Authorization: PEXELS_API_KEY,
        },
      }
    );

    if (!response.ok) {
      console.error(`Pexels API error: ${response.status}`);
      return null;
    }

    const data: PexelsResponse = await response.json();
    if (data.photos && data.photos.length > 0) {
      return data.photos[0].src.medium;
    }
    return null;
  } catch (error) {
    console.error("Error fetching from Pexels:", error);
    return null;
  }
}

const categoryQueries: Record<string, string[]> = {
  RESTAURANT: [
    "arabic restaurant food",
    "middle eastern cuisine",
    "restaurant interior dining",
    "grilled meat kebab",
    "traditional arabic food"
  ],
  CAFE: [
    "arabic coffee cafe",
    "coffee shop interior",
    "latte art coffee",
    "modern cafe design",
    "espresso coffee beans"
  ],
  HOTEL: [
    "luxury hotel lobby",
    "hotel room interior",
    "hotel building exterior",
    "five star hotel",
    "hotel reception"
  ]
};

async function updatePlaceImages() {
  console.log("Starting to update place images...");
  
  const allPlaces = await db.select().from(places);
  console.log(`Found ${allPlaces.length} places to update`);

  for (const place of allPlaces) {
    const queries = categoryQueries[place.category] || ["restaurant food"];
    const queryIndex = place.id % queries.length;
    const query = queries[queryIndex];
    
    console.log(`Updating ${place.name} with query: ${query}`);
    
    const imageUrl = await searchPexels(query);
    
    if (imageUrl) {
      await db.update(places).set({ image: imageUrl }).where(eq(places.id, place.id));
      console.log(`Updated ${place.name} with image: ${imageUrl}`);
    } else {
      console.log(`Could not find image for ${place.name}`);
    }
    
    await new Promise(resolve => setTimeout(resolve, 200));
  }

  console.log("Finished updating place images");
}

updatePlaceImages().then(() => {
  console.log("Done!");
  process.exit(0);
}).catch(err => {
  console.error("Error:", err);
  process.exit(1);
});
