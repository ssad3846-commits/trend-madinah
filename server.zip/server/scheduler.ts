import { scrapeAndPostRegionalNews, postAllPrayerTimes, postBreakingNews } from "./news-scraper";

const PRAYER_TIMES_INTERVAL = 12 * 60 * 60 * 1000; // كل 12 ساعة
const NEWS_INTERVAL = 6 * 60 * 60 * 1000; // كل 6 ساعات
const BREAKING_NEWS_INTERVAL = 30 * 60 * 1000; // كل نصف ساعة

let prayerTimesTimer: NodeJS.Timeout | null = null;
let newsTimer: NodeJS.Timeout | null = null;
let breakingNewsTimer: NodeJS.Timeout | null = null;
let isSchedulerRunning = false;

async function runPrayerTimesTask() {
  console.log("🕌 [Scheduler] جاري نشر مواقيت الصلاة...");
  try {
    await postAllPrayerTimes();
    console.log("✅ [Scheduler] تم نشر مواقيت الصلاة بنجاح");
  } catch (error) {
    console.error("❌ [Scheduler] خطأ في نشر مواقيت الصلاة:", error);
  }
}

async function runNewsTask() {
  console.log("📰 [Scheduler] جاري جلب الأخبار...");
  try {
    await scrapeAndPostRegionalNews();
    console.log("✅ [Scheduler] تم جلب الأخبار بنجاح");
  } catch (error) {
    console.error("❌ [Scheduler] خطأ في جلب الأخبار:", error);
  }
}

async function runBreakingNewsTask() {
  console.log("🔴 [Scheduler] جاري جلب الأخبار العاجلة...");
  try {
    await postBreakingNews();
    console.log("✅ [Scheduler] تم نشر الأخبار العاجلة بنجاح");
  } catch (error) {
    console.error("❌ [Scheduler] خطأ في جلب الأخبار العاجلة:", error);
  }
}

export function startScheduler() {
  if (isSchedulerRunning) {
    console.log("⚠️ [Scheduler] المجدول يعمل بالفعل");
    return;
  }

  console.log("🚀 [Scheduler] بدء تشغيل المجدول الآلي...");
  console.log(`   📅 مواقيت الصلاة: كل 12 ساعة`);
  console.log(`   📰 الأخبار: كل 6 ساعات`);
  console.log(`   🔴 أخبار عاجلة: كل 30 دقيقة`);
  
  isSchedulerRunning = true;

  // تشغيل المهام عند البدء (بعد تأخير قصير للتأكد من جاهزية قاعدة البيانات)
  setTimeout(async () => {
    console.log("🔄 [Scheduler] تشغيل المهام الأولية...");
    
    // تشغيل مواقيت الصلاة أولاً
    await runPrayerTimesTask();
    
    // تأخير 10 ثواني ثم تشغيل الأخبار
    setTimeout(async () => {
      await runNewsTask();
      
      // تأخير 5 ثواني ثم تشغيل الأخبار العاجلة
      setTimeout(() => {
        runBreakingNewsTask();
      }, 5000);
    }, 10000);
  }, 5000);

  // جدولة مواقيت الصلاة كل 12 ساعة
  prayerTimesTimer = setInterval(runPrayerTimesTask, PRAYER_TIMES_INTERVAL);

  // جدولة الأخبار كل 6 ساعات
  newsTimer = setInterval(runNewsTask, NEWS_INTERVAL);

  // جدولة الأخبار العاجلة كل 30 دقيقة
  breakingNewsTimer = setInterval(runBreakingNewsTask, BREAKING_NEWS_INTERVAL);
}

export function stopScheduler() {
  if (prayerTimesTimer) {
    clearInterval(prayerTimesTimer);
    prayerTimesTimer = null;
  }
  if (newsTimer) {
    clearInterval(newsTimer);
    newsTimer = null;
  }
  if (breakingNewsTimer) {
    clearInterval(breakingNewsTimer);
    breakingNewsTimer = null;
  }
  isSchedulerRunning = false;
  console.log("⏹️ [Scheduler] تم إيقاف المجدول");
}

export function getSchedulerStatus() {
  return {
    isRunning: isSchedulerRunning,
    prayerTimesInterval: "كل 12 ساعة",
    newsInterval: "كل 6 ساعات",
    breakingNewsInterval: "كل 30 دقيقة",
  };
}
