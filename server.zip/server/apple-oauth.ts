import jwt from "jsonwebtoken";
import crypto from "crypto";
import * as jose from "jose";

// Generate Apple client secret JWT
export function generateAppleClientSecret(): string {
  const header = {
    alg: "ES256",
    kid: process.env.APPLE_KEY_ID,
    typ: "JWT",
  };

  const now = Math.floor(Date.now() / 1000);
  const payload = {
    iss: process.env.APPLE_TEAM_ID,
    iat: now,
    exp: now + 15777000, // 6 months
    aud: "https://appleid.apple.com",
    sub: process.env.APPLE_CLIENT_ID,
  };

  const privateKey = process.env.APPLE_PRIVATE_KEY?.replace(/\\n/g, "\n") || "";
  
  const token = jwt.sign(payload, privateKey, {
    algorithm: "ES256",
    header,
  });

  return token;
}

// Generate state for CSRF protection
export function generateState(): string {
  return crypto.randomBytes(32).toString("hex");
}

// Generate nonce for replay protection
export function generateNonce(): string {
  return crypto.randomBytes(32).toString("hex");
}

// Generate Apple OAuth authorization URL with CSRF protection
export function generateAppleAuthUrl(redirectUri: string, state: string, nonce: string): string {
  const params = new URLSearchParams({
    response_type: "code id_token",
    response_mode: "form_post",
    client_id: process.env.APPLE_CLIENT_ID || "",
    redirect_uri: redirectUri,
    scope: "openid name email",
    state: state,
    nonce: nonce,
  });

  return `https://appleid.apple.com/auth/authorize?${params.toString()}`;
}

// Exchange authorization code for tokens
export async function exchangeCodeForTokens(code: string, redirectUri: string): Promise<any> {
  const clientSecret = generateAppleClientSecret();
  
  const params = new URLSearchParams({
    client_id: process.env.APPLE_CLIENT_ID || "",
    client_secret: clientSecret,
    code: code,
    grant_type: "authorization_code",
    redirect_uri: redirectUri,
  });

  try {
    const response = await fetch("https://appleid.apple.com/auth/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params.toString(),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("Apple token exchange error:", error);
      return null;
    }

    return await response.json();
  } catch (error) {
    console.error("Error exchanging code for tokens:", error);
    return null;
  }
}

// Create JWKS client for Apple's public keys
let appleJWKS: jose.JWTVerifyGetKey | null = null;

function getAppleJWKS(): jose.JWTVerifyGetKey {
  if (!appleJWKS) {
    appleJWKS = jose.createRemoteJWKSet(new URL("https://appleid.apple.com/auth/keys"));
  }
  return appleJWKS;
}

// Verify Apple ID token with proper signature verification
export async function verifyAppleToken(idToken: string, expectedNonce?: string): Promise<any> {
  try {
    // Fail fast if APPLE_CLIENT_ID is not configured
    const clientId = process.env.APPLE_CLIENT_ID;
    if (!clientId) {
      console.error("APPLE_CLIENT_ID environment variable is not set");
      return null;
    }

    const jwks = getAppleJWKS();
    
    // Verify the JWT signature using Apple's public keys
    const { payload } = await jose.jwtVerify(idToken, jwks, {
      issuer: "https://appleid.apple.com",
      audience: clientId,
    });

    // Require nonce validation when expectedNonce is provided
    if (expectedNonce) {
      if (!payload.nonce) {
        console.error("Token missing nonce but nonce was expected");
        return null;
      }
      if (payload.nonce !== expectedNonce) {
        console.error("Nonce mismatch");
        return null;
      }
    }

    return payload;
  } catch (error) {
    console.error("Error verifying Apple token:", error);
    return null;
  }
}
