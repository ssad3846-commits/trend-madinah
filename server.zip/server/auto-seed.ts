import { db } from "./storage";
import { users, neighborhoods, tweets, questions, answers, places, trends } from "@shared/schema";
import { count } from "drizzle-orm";

export async function autoSeedIfNeeded() {
  console.log("🔍 Checking if database needs seeding...");

  try {
    const [neighborhoodCount] = await db.select({ count: count() }).from(neighborhoods);
    
    if (neighborhoodCount.count > 0) {
      console.log("✅ Database already has data, skipping seed");
      return;
    }

    console.log("🌱 Database is empty, starting auto-seed...");

    // 1. Seed neighborhoods
    console.log("📍 Seeding neighborhoods...");
    const neighborhoodData = [
      { id: "all", name: "المدينة المنورة" },
      { id: "1", name: "العزيزية" },
      { id: "2", name: "الملك فهد" },
      { id: "3", name: "الربوة" },
      { id: "4", name: "سيد الشهداء" },
      { id: "5", name: "قباء" },
      { id: "6", name: "العنابس" },
      { id: "7", name: "السحمان" },
      { id: "8", name: "المستراح" },
      { id: "9", name: "البحر" },
      { id: "10", name: "الجبور" },
      { id: "11", name: "النصر" },
      { id: "12", name: "العنبرية" },
      { id: "13", name: "العوالي" },
      { id: "14", name: "العيون" },
      { id: "15", name: "المناخة" },
      { id: "16", name: "الأغوات" },
      { id: "17", name: "الساحة" },
      { id: "18", name: "زقاق الطيار" },
      { id: "19", name: "الحرة الشرقية" },
      { id: "20", name: "التاجوري" },
      { id: "21", name: "باب المجيدي" },
      { id: "22", name: "باب الشامي" },
      { id: "23", name: "الحرة الغربية" },
      { id: "24", name: "الجرف" },
      { id: "25", name: "الدويمة" },
      { id: "26", name: "القبلتين" },
      { id: "27", name: "أبيار علي" },
      { id: "28", name: "الخالدية" },
      { id: "29", name: "الإسكان" },
      { id: "30", name: "المطار" },
      { id: "31", name: "البيداء" },
      { id: "32", name: "تلعة الهبوب" },
      { id: "33", name: "المبعوث" },
      { id: "34", name: "العاقول" },
      { id: "35", name: "الخضراء" },
      { id: "36", name: "وعيرة" },
      { id: "37", name: "الفيصل" },
      { id: "38", name: "الحرة الشمالية الشرقية" },
      { id: "39", name: "قربان" },
      { id: "40", name: "المنشية" },
      { id: "41", name: "السيح" },
      { id: "42", name: "الوبرة" },
      { id: "43", name: "عروة" },
      { id: "44", name: "الدخل المحدود" },
      { id: "45", name: "العصبة" },
      { id: "46", name: "شوران" },
      { id: "47", name: "الراية" },
      { id: "48", name: "الفتح" },
      { id: "49", name: "الحمراء" },
      { id: "50", name: "أبو مرخه" },
      { id: "51", name: "المصانع" },
    ];
    await db.insert(neighborhoods).values(neighborhoodData);

    // 2. Seed users
    console.log("👥 Seeding users...");
    const insertedUsers = await db
      .insert(users)
      .values([
        {
          name: "أحمد المدني",
          handle: "ahmed_madani",
          avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100&h=100&fit=crop",
          verified: true,
          bio: "من أهل المدينة المنورة، أحب مشاركة أخبار المدينة",
          location: "المدينة المنورة",
          following: 450,
          followers: 1240,
        },
        {
          name: "دليل المدينة",
          handle: "madinah_guide",
          avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop",
          verified: true,
          bio: "دليلك الشامل لكل ما هو جديد في المدينة المنورة",
          following: 200,
          followers: 5600,
        },
        {
          name: "سارة الحربي",
          handle: "sara_alharbi",
          avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
          bio: "أم وربة بيت، أحب الفعاليات والأنشطة العائلية",
          location: "الخالدية",
          following: 150,
          followers: 280,
        },
        {
          name: "عبدالله",
          handle: "abdullah_99",
          avatar: "https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100&h=100&fit=crop",
          following: 80,
          followers: 120,
        },
        {
          name: "أخبار المدينة",
          handle: "MadinahNews",
          avatar: "https://images.unsplash.com/photo-1589309736404-2e142a2acdf0?w=100&h=100&fit=crop",
          verified: true,
          bio: "حساب رسمي لأخبار المدينة المنورة",
          following: 50,
          followers: 12500,
        },
        {
          name: "عشاق العزيزية",
          handle: "AziziahLovers",
          avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop",
          bio: "كل ما يخص حي العزيزية الجميل",
          location: "العزيزية",
          following: 300,
          followers: 890,
        },
        {
          name: "سعد الجهني",
          handle: "saad_j",
          avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop",
          location: "القبلتين",
          following: 120,
          followers: 340,
        },
        {
          name: "كافيهات المدينة",
          handle: "MadinahCafes",
          avatar: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=100&h=100&fit=crop",
          bio: "دليلك لأفضل المقاهي في المدينة",
          following: 400,
          followers: 3200,
        },
        {
          name: "بندر الحربي",
          handle: "bandar_h",
          avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
          location: "الخالدية",
          following: 90,
          followers: 210,
        },
        {
          name: "فعاليات طيبة",
          handle: "TaibahEvents",
          avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
          bio: "نشارككم أجمل الفعاليات في المدينة المنورة",
          following: 250,
          followers: 4500,
        },
      ])
      .returning();

    // 3. Seed tweets
    console.log("🐦 Seeding tweets...");
    await db.insert(tweets).values([
      {
        userId: insertedUsers[0].id,
        content: "صباح الخير من مدينة رسول الله ﷺ. الأجواء اليوم خيالية في ممشى الهجرة! 🌧️🍃 #امطار_المدينة",
        image: "https://images.unsplash.com/photo-1565552629477-bc872752b924?w=600&h=400&fit=crop",
        likes: 1240,
        replies: 45,
        retweets: 230,
        locationId: "58",
        locationName: "الهجرة",
      },
      {
        userId: insertedUsers[1].id,
        content: "تم افتتاح الفرع الجديد لمقهى القبة في شارع سلطانة. الديكور يجمع بين التراث والحداثة. ☕✨ #مطاعم_المدينة",
        likes: 856,
        replies: 120,
        retweets: 560,
        locationId: "4",
        locationName: "سلطانة",
      },
      {
        userId: insertedUsers[2].id,
        content: "هل فيه احد يعرف متى تبدأ فعاليات حديقة الملك فهد؟ 🎡",
        likes: 45,
        replies: 12,
        retweets: 5,
        locationId: "30",
        locationName: "الحديقة",
      },
      {
        userId: insertedUsers[3].id,
        content: "زحمة مو طبيعية في الدائري الثاني اليوم 🚗🚗",
        likes: 210,
        replies: 34,
        retweets: 12,
        locationId: "18",
        locationName: "الملك فهد",
      },
      {
        userId: insertedUsers[4].id,
        content: "عاجل: افتتاح مشروع حديقة الملك فهد بعد التطوير رسمياً اليوم. #المدينة_المنورة #مشاريع_المدينة",
        image: "https://images.unsplash.com/photo-1596895111956-bf1cf0599ce5?w=600&h=400&fit=crop",
        likes: 5430,
        replies: 340,
        retweets: 1200,
        locationId: "30",
        locationName: "الحديقة",
      },
      {
        userId: insertedUsers[5].id,
        content: "أجمل غروب شمس ممكن تشوفه اليوم في العزيزية 😍 #العزيزية",
        likes: 230,
        replies: 15,
        retweets: 45,
        locationId: "1",
        locationName: "العزيزية",
      },
      {
        userId: insertedUsers[6].id,
        content: "زحمة عند دوار القبلتين يا جماعة انتبهوا 🛑",
        likes: 120,
        replies: 40,
        retweets: 30,
        locationId: "51",
        locationName: "القبلتين",
      },
      {
        userId: insertedUsers[7].id,
        content: "تجربتنا اليوم في كافيه جديد في ممشى الهجرة.. القهوة تفوز! ☕️👌 #مطاعم_المدينة",
        likes: 670,
        replies: 55,
        retweets: 110,
        locationId: "58",
        locationName: "الهجرة",
      },
      {
        userId: insertedUsers[8].id,
        content: "حي الخالدية يحتاج اهتمام أكثر بالإنارة في الشوارع الفرعية 💡",
        likes: 89,
        replies: 22,
        retweets: 10,
        locationId: "2",
        locationName: "الخالدية",
      },
      {
        userId: insertedUsers[9].id,
        content: "لا تفوتكم فعالية الرسم الحر في حديقة الملك فهد الليلة 🎨🖌️",
        likes: 340,
        replies: 28,
        retweets: 67,
        locationId: "30",
        locationName: "الحديقة",
      },
    ]);

    // 4. Seed questions and answers
    console.log("❓ Seeding questions and answers...");
    const insertedQuestions = await db
      .insert(questions)
      .values([
        {
          content: "يا أهل المدينة، وين ألقى أفضل محل يبيع تمور عجوة أصلية وبسعر معقول؟",
          locationId: "13",
          locationName: "الساحة",
          answersCount: 2,
        },
        {
          content: "أحتاج سباك شاطر وأمين في حي العزيزية، عندي تهريب موية وما عرفت له.",
          locationId: "1",
          locationName: "العزيزية",
          answersCount: 1,
        },
        {
          content: "متى مواعيد زيارة الروضة الشريفة للنساء هالأيام؟",
          locationId: "all",
          locationName: "المدينة المنورة",
          answersCount: 2,
        },
        {
          content: "وش رايكم في مدرسة المنارات الأهلية؟ تنصحون فيها لأولى ابتدائي؟",
          locationId: "4",
          locationName: "سلطانة",
          answersCount: 1,
        },
      ])
      .returning();

    await db.insert(answers).values([
      {
        questionId: insertedQuestions[0].id,
        content: "سوق التمور المركزي مليان، بس انتبه وأنا أخوك لازم تذوق قبل تشتري. فيه محل اسمه 'تمور طيبة' ممتاز.",
      },
      {
        questionId: insertedQuestions[0].id,
        content: "روحي لمزارع العالية، يبيعون لك من المزرعة مباشرة وجديد.",
      },
      {
        questionId: insertedQuestions[1].id,
        content: "فيه واحد باكستاني اسمه محمد، شغله نظيف وسعره طيب. هذا رقمه...",
      },
      {
        questionId: insertedQuestions[2].id,
        content: "لازم حجز عن طريق تطبيق نسك، المواعيد تفتح كل يوم جمعة الظهر عادة.",
      },
      {
        questionId: insertedQuestions[2].id,
        content: "صح تطبيق نسك، بس ترا الزحمة خفت هالأيام يمديك تحصلين حجز بسهولة.",
      },
      {
        questionId: insertedQuestions[3].id,
        content: "ممتازة جداً وتأسيسهم قوي، عيالي فيها.",
      },
    ]);

    // 5. Seed places (restaurants, cafes, hotels)
    console.log("🍽️ Seeding places...");
    await db.insert(places).values([
      {
        name: "مطعم التراث المديني",
        rating: 4.8,
        reviews: 1250,
        cuisine: "شعبي / سعودي",
        image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&h=400&fit=crop",
        locationId: "4",
        locationName: "سلطانة",
        priceRange: "$$",
        googleMapsUrl: "https://goo.gl/maps/example1",
        category: "RESTAURANT",
      },
      {
        name: "ستيك هاوس المدينة",
        rating: 4.5,
        reviews: 890,
        cuisine: "غربي / ستيك",
        image: "https://images.unsplash.com/photo-1544025162-d76694265947?w=600&h=400&fit=crop",
        locationId: "30",
        locationName: "الحديقة",
        priceRange: "$$$",
        category: "RESTAURANT",
      },
      {
        name: "بيتزا نابولي",
        rating: 4.2,
        reviews: 560,
        cuisine: "إيطالي",
        image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=600&h=400&fit=crop",
        locationId: "1",
        locationName: "العزيزية",
        priceRange: "$$",
        category: "RESTAURANT",
      },
      {
        name: "شاورما الطازج",
        rating: 4.7,
        reviews: 3200,
        cuisine: "وجبات سريعة",
        image: "https://images.unsplash.com/photo-1529042410759-befb1204b468?w=600&h=400&fit=crop",
        locationId: "28",
        locationName: "الخالدية",
        priceRange: "$",
        category: "RESTAURANT",
      },
      {
        name: "مطعم البحار",
        rating: 4.0,
        reviews: 430,
        cuisine: "مأكولات بحرية",
        image: "https://images.unsplash.com/photo-1565689157206-0fddef7589a2?w=600&h=400&fit=crop",
        locationId: "58",
        locationName: "الهجرة",
        priceRange: "$$$",
        category: "RESTAURANT",
      },
      {
        name: "كافيه ومحمصة القمة",
        rating: 4.9,
        reviews: 150,
        cuisine: "قهوة مختصة",
        image: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=600&h=400&fit=crop",
        locationId: "5",
        locationName: "قباء",
        priceRange: "$$",
        category: "CAFE",
      },
      {
        name: "برجر فاكتوري",
        rating: 4.4,
        reviews: 670,
        cuisine: "برجر",
        image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&h=400&fit=crop",
        locationId: "1",
        locationName: "العزيزية",
        priceRange: "$$",
        category: "RESTAURANT",
      },
      {
        name: "مطعم بخاري المدينة",
        rating: 4.6,
        reviews: 2100,
        cuisine: "شعبي / بخاري",
        image: "https://images.unsplash.com/photo-1594041680534-e8c8cdebd659?w=600&h=400&fit=crop",
        locationId: "4",
        locationName: "سيد الشهداء",
        priceRange: "$",
        category: "RESTAURANT",
      },
      {
        name: "ستاربكس - سلطانة",
        rating: 4.3,
        reviews: 5400,
        cuisine: "قهوة",
        image: "https://images.unsplash.com/photo-1559925393-8be0ec4767c8?w=600&h=400&fit=crop",
        locationId: "all",
        locationName: "المدينة المنورة",
        priceRange: "$$",
        category: "CAFE",
      },
      {
        name: "دوز كافيه",
        rating: 4.5,
        reviews: 320,
        cuisine: "قهوة مختصة",
        image: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=600&h=400&fit=crop",
        locationId: "all",
        locationName: "المدينة المنورة",
        priceRange: "$$",
        category: "CAFE",
      },
      {
        name: "كافيه روزا",
        rating: 4.6,
        reviews: 280,
        cuisine: "قهوة وحلويات",
        image: "https://images.unsplash.com/photo-1445116572660-236099ec97a0?w=600&h=400&fit=crop",
        locationId: "all",
        locationName: "المدينة المنورة",
        priceRange: "$$",
        category: "CAFE",
      },
      {
        name: "كافيه بارنز",
        rating: 4.4,
        reviews: 420,
        cuisine: "قهوة مختصة",
        image: "https://images.unsplash.com/photo-1453614512568-c4024d13c247?w=600&h=400&fit=crop",
        locationId: "all",
        locationName: "المدينة المنورة",
        priceRange: "$$",
        category: "CAFE",
      },
      {
        name: "فندق دار التقوى",
        rating: 4.9,
        reviews: 1200,
        cuisine: "فندق 5 نجوم",
        image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600&h=400&fit=crop",
        locationId: "all",
        locationName: "المدينة المنورة",
        priceRange: "$$$$",
        category: "HOTEL",
      },
      {
        name: "فندق ماريوت المدينة",
        rating: 4.6,
        reviews: 890,
        cuisine: "فندق 5 نجوم",
        image: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=600&h=400&fit=crop",
        locationId: "all",
        locationName: "المدينة المنورة",
        priceRange: "$$$",
        category: "HOTEL",
      },
      {
        name: "فندق بولمان زمزم",
        rating: 4.7,
        reviews: 2500,
        cuisine: "فندق 5 نجوم",
        image: "https://images.unsplash.com/photo-1582719508461-905c673771fd?w=600&h=400&fit=crop",
        locationId: "all",
        locationName: "المدينة المنورة",
        priceRange: "$$$$",
        category: "HOTEL",
      },
      {
        name: "فندق هيلتون المدينة",
        rating: 4.5,
        reviews: 1800,
        cuisine: "فندق 5 نجوم",
        image: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=600&h=400&fit=crop",
        locationId: "all",
        locationName: "المدينة المنورة",
        priceRange: "$$$",
        category: "HOTEL",
      },
      {
        name: "فندق أنوار المدينة موڤنبيك",
        rating: 4.8,
        reviews: 2200,
        cuisine: "فندق 5 نجوم",
        image: "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=600&h=400&fit=crop",
        locationId: "all",
        locationName: "المدينة المنورة",
        priceRange: "$$$$",
        category: "HOTEL",
      },
    ]);

    // 6. Seed trends
    console.log("📈 Seeding trends...");
    await db.insert(trends).values([
      { rank: 1, hashtag: "#امطار_المدينة", posts: "٥٠.٢ ألف", category: "طقس", locationId: "all" },
      { rank: 2, hashtag: "#المسجد_النبوي", posts: "٣٢.١ ألف", category: "ديني", locationId: "all" },
      { rank: 3, hashtag: "#فعاليات_المدينة", posts: "١٥.٤ ألف", category: "ترفيه", locationId: "all" },
      { rank: 4, hashtag: "#مطاعم_المدينة", posts: "١٠.٢ ألف", category: "لايف ستايل", locationId: "all" },
      { rank: 5, hashtag: "#الخالدية", posts: "٨.٥ ألف", category: "أحياء", locationId: "28" },
      { rank: 6, hashtag: "#العزيزية_الآن", posts: "٥.٣ ألف", category: "أحياء", locationId: "1" },
      { rank: 7, hashtag: "#زحمة_الدائري", posts: "٤.١ ألف", category: "مرور", locationId: "all" },
      { rank: 8, hashtag: "#سلطانة", posts: "٣.٩ ألف", category: "أحياء", locationId: "4" },
      { rank: 9, hashtag: "#حديقة_الملك_فهد", posts: "٣.٢ ألف", category: "أماكن", locationId: "30" },
      { rank: 10, hashtag: "#قباء", posts: "٢.٨ ألف", category: "أحياء", locationId: "5" },
      { rank: 11, hashtag: "#العوالي_بارك", posts: "٢.١ ألف", category: "أماكن", locationId: "3" },
      { rank: 12, hashtag: "#جامعة_طيبة", posts: "٢٠.٥ ألف", category: "تعليم", locationId: "27" },
    ]);

    console.log("✅ Auto-seed completed successfully!");
  } catch (error) {
    console.error("❌ Error during auto-seed:", error);
  }
}
