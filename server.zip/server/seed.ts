import { db } from "./storage";
import { users, neighborhoods, tweets, questions, answers, places, trends, liveCameras } from "@shared/schema";
import { eq } from "drizzle-orm";

async function seed() {
  console.log("🌱 Starting database seed...");

  try {
    // 1. Seed neighborhoods (Saudi cities)
    console.log("📍 Seeding Saudi cities...");
    const neighborhoodData = [
      { id: "all", name: "المملكة العربية السعودية" },
      { id: "1", name: "الرياض" },
      { id: "2", name: "جدة" },
      { id: "3", name: "مكة المكرمة" },
      { id: "4", name: "المدينة المنورة" },
      { id: "5", name: "الدمام" },
      { id: "6", name: "الخبر" },
      { id: "7", name: "الطائف" },
      { id: "8", name: "تبوك" },
      { id: "9", name: "بريدة" },
      { id: "10", name: "حائل" },
      { id: "11", name: "أبها" },
      { id: "12", name: "الأحساء" },
      { id: "13", name: "القطيف" },
      { id: "14", name: "نجران" },
      { id: "15", name: "جازان" },
      { id: "16", name: "ينبع" },
      { id: "17", name: "الجبيل" },
      { id: "18", name: "خميس مشيط" },
      { id: "19", name: "الباحة" },
      { id: "20", name: "عرعر" },
    ];
    await db.insert(neighborhoods).values(neighborhoodData);

    // 2. Seed users
    console.log("👥 Seeding users...");
    const insertedUsers = await db
      .insert(users)
      .values([
        {
          name: "أحمد المدني",
          handle: "ahmed_madani",
          avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100&h=100&fit=crop",
          verified: true,
          bio: "من أهل المدينة المنورة، أحب مشاركة أخبار المدينة",
          location: "المدينة المنورة",
          following: 450,
          followers: 1240,
        },
        {
          name: "دليل المدينة",
          handle: "madinah_guide",
          avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop",
          verified: true,
          bio: "دليلك الشامل لكل ما هو جديد في المدينة المنورة",
          following: 200,
          followers: 5600,
        },
        {
          name: "سارة الحربي",
          handle: "sara_alharbi",
          avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
          bio: "أم وربة بيت، أحب الفعاليات والأنشطة العائلية",
          location: "الخالدية",
          following: 150,
          followers: 280,
        },
        {
          name: "عبدالله",
          handle: "abdullah_99",
          avatar: "https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100&h=100&fit=crop",
          following: 80,
          followers: 120,
        },
        {
          name: "أخبار المدينة",
          handle: "MadinahNews",
          avatar: "https://images.unsplash.com/photo-1589309736404-2e142a2acdf0?w=100&h=100&fit=crop",
          verified: true,
          bio: "حساب رسمي لأخبار المدينة المنورة",
          following: 50,
          followers: 12500,
        },
        {
          name: "عشاق العزيزية",
          handle: "AziziahLovers",
          avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop",
          bio: "كل ما يخص حي العزيزية الجميل",
          location: "العزيزية",
          following: 300,
          followers: 890,
        },
        {
          name: "سعد الجهني",
          handle: "saad_j",
          avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop",
          location: "القبلتين",
          following: 120,
          followers: 340,
        },
        {
          name: "كافيهات المدينة",
          handle: "MadinahCafes",
          avatar: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=100&h=100&fit=crop",
          bio: "دليلك لأفضل المقاهي في المدينة",
          following: 400,
          followers: 3200,
        },
        {
          name: "بندر الحربي",
          handle: "bandar_h",
          avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
          location: "الخالدية",
          following: 90,
          followers: 210,
        },
        {
          name: "فعاليات طيبة",
          handle: "TaibahEvents",
          avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
          bio: "نشارككم أجمل الفعاليات في المدينة المنورة",
          following: 250,
          followers: 4500,
        },
      ])
      .returning();

    // 3. Seed tweets
    console.log("🐦 Seeding tweets...");
    await db.insert(tweets).values([
      {
        userId: insertedUsers[0].id,
        content: "صباح الخير من مدينة رسول الله ﷺ. الأجواء اليوم خيالية في ممشى الهجرة! 🌧️🍃 #امطار_المدينة",
        image: "https://images.unsplash.com/photo-1565552629477-bc872752b924?w=600&h=400&fit=crop",
        likes: 1240,
        replies: 45,
        retweets: 230,
        locationId: "58",
        locationName: "الهجرة",
      },
      {
        userId: insertedUsers[1].id,
        content: "تم افتتاح الفرع الجديد لمقهى القبة في شارع سلطانة. الديكور يجمع بين التراث والحداثة. ☕✨ #مطاعم_المدينة",
        likes: 856,
        replies: 120,
        retweets: 560,
        locationId: "4",
        locationName: "سلطانة",
      },
      {
        userId: insertedUsers[2].id,
        content: "هل فيه احد يعرف متى تبدأ فعاليات حديقة الملك فهد؟ 🎡",
        likes: 45,
        replies: 12,
        retweets: 5,
        locationId: "30",
        locationName: "الحديقة",
      },
      {
        userId: insertedUsers[3].id,
        content: "زحمة مو طبيعية في الدائري الثاني اليوم 🚗🚗",
        likes: 210,
        replies: 34,
        retweets: 12,
        locationId: "18",
        locationName: "الملك فهد",
      },
      {
        userId: insertedUsers[4].id,
        content: "عاجل: افتتاح مشروع حديقة الملك فهد بعد التطوير رسمياً اليوم. #المدينة_المنورة #مشاريع_المدينة",
        image: "https://images.unsplash.com/photo-1596895111956-bf1cf0599ce5?w=600&h=400&fit=crop",
        likes: 5430,
        replies: 340,
        retweets: 1200,
        locationId: "30",
        locationName: "الحديقة",
      },
      {
        userId: insertedUsers[5].id,
        content: "أجمل غروب شمس ممكن تشوفه اليوم في العزيزية 😍 #العزيزية",
        likes: 230,
        replies: 15,
        retweets: 45,
        locationId: "1",
        locationName: "العزيزية",
      },
      {
        userId: insertedUsers[6].id,
        content: "زحمة عند دوار القبلتين يا جماعة انتبهوا 🛑",
        likes: 120,
        replies: 40,
        retweets: 30,
        locationId: "51",
        locationName: "القبلتين",
      },
      {
        userId: insertedUsers[7].id,
        content: "تجربتنا اليوم في كافيه جديد في ممشى الهجرة.. القهوة تفوز! ☕️👌 #مطاعم_المدينة",
        likes: 670,
        replies: 55,
        retweets: 110,
        locationId: "58",
        locationName: "الهجرة",
      },
      {
        userId: insertedUsers[8].id,
        content: "حي الخالدية يحتاج اهتمام أكثر بالإنارة في الشوارع الفرعية 💡",
        likes: 89,
        replies: 22,
        retweets: 10,
        locationId: "2",
        locationName: "الخالدية",
      },
      {
        userId: insertedUsers[9].id,
        content: "لا تفوتكم فعالية الرسم الحر في حديقة الملك فهد الليلة 🎨🖌️",
        likes: 340,
        replies: 28,
        retweets: 67,
        locationId: "30",
        locationName: "الحديقة",
      },
    ]);

    // 4. Seed questions and answers
    console.log("❓ Seeding questions and answers...");
    const insertedQuestions = await db
      .insert(questions)
      .values([
        {
          content: "يا أهل المدينة، وين ألقى أفضل محل يبيع تمور عجوة أصلية وبسعر معقول؟",
          locationId: "13",
          locationName: "الساحة",
          answersCount: 2,
        },
        {
          content: "أحتاج سباك شاطر وأمين في حي العزيزية، عندي تهريب موية وما عرفت له.",
          locationId: "1",
          locationName: "العزيزية",
          answersCount: 1,
        },
        {
          content: "متى مواعيد زيارة الروضة الشريفة للنساء هالأيام؟",
          locationId: "all",
          locationName: "المدينة المنورة",
          answersCount: 2,
        },
        {
          content: "وش رايكم في مدرسة المنارات الأهلية؟ تنصحون فيها لأولى ابتدائي؟",
          locationId: "4",
          locationName: "سلطانة",
          answersCount: 1,
        },
      ])
      .returning();

    await db.insert(answers).values([
      {
        questionId: insertedQuestions[0].id,
        content: "سوق التمور المركزي مليان، بس انتبه وأنا أخوك لازم تذوق قبل تشتري. فيه محل اسمه 'تمور طيبة' ممتاز.",
      },
      {
        questionId: insertedQuestions[0].id,
        content: "روحي لمزارع العالية، يبيعون لك من المزرعة مباشرة وجديد.",
      },
      {
        questionId: insertedQuestions[1].id,
        content: "فيه واحد باكستاني اسمه محمد، شغله نظيف وسعره طيب. هذا رقمه...",
      },
      {
        questionId: insertedQuestions[2].id,
        content: "لازم حجز عن طريق تطبيق نسك، المواعيد تفتح كل يوم جمعة الظهر عادة.",
      },
      {
        questionId: insertedQuestions[2].id,
        content: "صح تطبيق نسك، بس ترا الزحمة خفت هالأيام يمديك تحصلين حجز بسهولة.",
      },
      {
        questionId: insertedQuestions[3].id,
        content: "ممتازة جداً وتأسيسهم قوي، عيالي فيها.",
      },
    ]);

    // 5. Seed places (restaurants, cafes, hotels)
    console.log("🍽️ Seeding places...");
    await db.insert(places).values([
      {
        name: "مطعم التراث المديني",
        rating: 4.8,
        reviews: 1250,
        cuisine: "شعبي / سعودي",
        image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&h=400&fit=crop",
        locationId: "4",
        locationName: "سلطانة",
        priceRange: "$$",
        googleMapsUrl: "https://goo.gl/maps/example1",
        category: "RESTAURANT",
      },
      {
        name: "ستيك هاوس المدينة",
        rating: 4.5,
        reviews: 890,
        cuisine: "غربي / ستيك",
        image: "https://images.unsplash.com/photo-1544025162-d76694265947?w=600&h=400&fit=crop",
        locationId: "30",
        locationName: "الحديقة",
        priceRange: "$$$",
        category: "RESTAURANT",
      },
      {
        name: "بيتزا نابولي",
        rating: 4.2,
        reviews: 560,
        cuisine: "إيطالي",
        image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=600&h=400&fit=crop",
        locationId: "1",
        locationName: "العزيزية",
        priceRange: "$$",
        category: "RESTAURANT",
      },
      {
        name: "شاورما الطازج",
        rating: 4.7,
        reviews: 3200,
        cuisine: "وجبات سريعة",
        image: "https://images.unsplash.com/photo-1529042410759-befb1204b468?w=600&h=400&fit=crop",
        locationId: "2",
        locationName: "الخالدية",
        priceRange: "$",
        category: "RESTAURANT",
      },
      {
        name: "مطعم البحار",
        rating: 4.0,
        reviews: 430,
        cuisine: "مأكولات بحرية",
        image: "https://images.unsplash.com/photo-1565689157206-0fddef7589a2?w=600&h=400&fit=crop",
        locationId: "58",
        locationName: "الهجرة",
        priceRange: "$$$",
        category: "RESTAURANT",
      },
      {
        name: "كافيه ومحمصة القمة",
        rating: 4.9,
        reviews: 150,
        cuisine: "قهوة مختصة",
        image: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=600&h=400&fit=crop",
        locationId: "5",
        locationName: "قباء",
        priceRange: "$$",
        category: "CAFE",
      },
      {
        name: "برجر فاكتوري",
        rating: 4.4,
        reviews: 670,
        cuisine: "برجر",
        image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&h=400&fit=crop",
        locationId: "1",
        locationName: "العزيزية",
        priceRange: "$$",
        category: "RESTAURANT",
      },
      {
        name: "مطعم بخاري المدينة",
        rating: 4.6,
        reviews: 2100,
        cuisine: "شعبي / بخاري",
        image: "https://images.unsplash.com/photo-1594041680534-e8c8cdebd659?w=600&h=400&fit=crop",
        locationId: "60",
        locationName: "سيد الشهداء",
        priceRange: "$",
        category: "RESTAURANT",
      },
      {
        name: "ستاربكس",
        rating: 4.3,
        reviews: 5400,
        cuisine: "قهوة",
        image: "https://images.unsplash.com/photo-1559925393-8be0ec4767c8?w=600&h=400&fit=crop",
        locationId: "4",
        locationName: "سلطانة",
        priceRange: "$$",
        category: "CAFE",
      },
      {
        name: "دوز كافيه",
        rating: 4.5,
        reviews: 320,
        cuisine: "قهوة مختصة",
        image: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=600&h=400&fit=crop",
        locationId: "30",
        locationName: "الحديقة",
        priceRange: "$$",
        category: "CAFE",
      },
      {
        name: "فندق دار التقوى",
        rating: 4.9,
        reviews: 1200,
        cuisine: "فندق 5 نجوم",
        image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600&h=400&fit=crop",
        locationId: "all",
        locationName: "المدينة المنورة",
        priceRange: "$$$$",
        category: "HOTEL",
      },
      {
        name: "فندق ماريوت المدينة",
        rating: 4.6,
        reviews: 890,
        cuisine: "فندق 5 نجوم",
        image: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=600&h=400&fit=crop",
        locationId: "18",
        locationName: "الملك فهد",
        priceRange: "$$$",
        category: "HOTEL",
      },
      {
        name: "فندق بولمان زمزم",
        rating: 4.7,
        reviews: 2500,
        cuisine: "فندق 5 نجوم",
        image: "https://images.unsplash.com/photo-1582719508461-905c673771fd?w=600&h=400&fit=crop",
        locationId: "all",
        locationName: "المدينة المنورة",
        priceRange: "$$$$",
        category: "HOTEL",
      },
    ]);

    // 6. Seed trends
    console.log("📈 Seeding trends...");
    await db.insert(trends).values([
      { rank: 1, hashtag: "#السعودية", posts: "٥٠.٢ ألف", category: "عام", locationId: "all" },
      { rank: 2, hashtag: "#المسجد_النبوي", posts: "٣٢.١ ألف", category: "ديني", locationId: "4" },
      { rank: 3, hashtag: "#الرياض", posts: "١٥.٤ ألف", category: "مدن", locationId: "1" },
      { rank: 4, hashtag: "#جدة", posts: "١٠.٢ ألف", category: "مدن", locationId: "2" },
      { rank: 5, hashtag: "#مكة_المكرمة", posts: "٨.٥ ألف", category: "ديني", locationId: "3" },
    ]);

    // 7. Seed live cameras
    console.log("📹 Seeding live cameras...");
    await db.insert(liveCameras).values([
      { name: "المسجد النبوي الشريف", description: "بث مباشر 24 ساعة من المسجد النبوي الشريف", category: "مسجد", locationId: "all", locationName: "المدينة المنورة", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/TpT8b8JFZ6E?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/TpT8b8JFZ6E/maxresdefault.jpg", isOfficial: true, isLive: true },
      { name: "الحرم المكي الشريف", description: "بث مباشر من المسجد الحرام بمكة المكرمة", category: "مسجد", locationId: "all", locationName: "مكة المكرمة", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/Jj0E03q6Zcw?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/Jj0E03q6Zcw/maxresdefault.jpg", isOfficial: true, isLive: true },
      { name: "تقاطع شيبويا - طوكيو", description: "أشهر تقاطع في العالم - طوكيو، اليابان", category: "ساحات", locationId: "all", locationName: "طوكيو، اليابان", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/tujkoXI8rWM?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/tujkoXI8rWM/maxresdefault.jpg", isOfficial: true, isLive: true },
      { name: "تايمز سكوير - نيويورك", description: "ميدان تايمز سكوير بجودة 4K - نيويورك", category: "ساحات", locationId: "all", locationName: "نيويورك، أمريكا", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/rnXIjl_Rzy4?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/rnXIjl_Rzy4/maxresdefault.jpg", isOfficial: true, isLive: true },
      { name: "طوكيو - أكيهابارا", description: "منطقة الإلكترونيات والأنيمي الشهيرة في طوكيو", category: "ساحات", locationId: "all", locationName: "طوكيو، اليابان", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/gFRtAAmiFbE?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/gFRtAAmiFbE/maxresdefault.jpg", isOfficial: true, isLive: true },
      { name: "سيول - شارع ميونغدونغ", description: "منطقة التسوق الشهيرة في سيول - كوريا", category: "ساحات", locationId: "all", locationName: "سيول، كوريا", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/V8-dA5P-IeI?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/V8-dA5P-IeI/maxresdefault.jpg", isOfficial: true, isLive: true },
      { name: "براغ - ساحة البلدة القديمة", description: "الساعة الفلكية التاريخية في براغ", category: "ساحات", locationId: "all", locationName: "براغ، التشيك", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/Af3TfXJ1ehs?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/Af3TfXJ1ehs/maxresdefault.jpg", isOfficial: true, isLive: true },
      { name: "دبي - برج خليفة", description: "أطول برج في العالم مباشرة من دبي", category: "ساحات", locationId: "all", locationName: "دبي، الإمارات", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/RDWxdj7h_b4?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/RDWxdj7h_b4/maxresdefault.jpg", isOfficial: true, isLive: true },
      { name: "قناة السعودية - بث مباشر", description: "البث المباشر من القناة السعودية الرسمية", category: "مسجد", locationId: "all", locationName: "السعودية", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/6Mn1VlmJ7Ac?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/6Mn1VlmJ7Ac/maxresdefault.jpg", isOfficial: true, isLive: true },
      { name: "إسطنبول - مسجد أيا صوفيا", description: "المعلم التاريخي الأشهر في تركيا", category: "مسجد", locationId: "all", locationName: "إسطنبول، تركيا", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/Rje7A5VW-Bc?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/Rje7A5VW-Bc/maxresdefault.jpg", isOfficial: true, isLive: true },
    ]);

    console.log("✅ Database seeding completed successfully!");
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

seed()
  .then(() => {
    console.log("🎉 Seed script finished");
    process.exit(0);
  })
  .catch((error) => {
    console.error("💥 Seed script failed:", error);
    process.exit(1);
  });
