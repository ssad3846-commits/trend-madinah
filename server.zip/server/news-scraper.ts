import { db } from "./storage";
import { tweets, users } from "@shared/schema";
import { eq } from "drizzle-orm";

const SCRAPINGDOG_API_KEY = process.env.SCRAPINGDOG_API_KEY;

interface NewsSource {
  regionId: string;
  regionName: string;
  newsAccountHandle: string;
  searchQuery: string;
}

const NEWS_SOURCES: NewsSource[] = [
  { regionId: "1", regionName: "منطقة الرياض", newsAccountHandle: "RiyadhNews", searchQuery: "site:alriyadh.com OR site:al-jazirah.com الرياض" },
  { regionId: "2", regionName: "منطقة مكة المكرمة", newsAccountHandle: "MakkahNews", searchQuery: "site:makkahnewspaper.com OR site:okaz.com.sa مكة جدة" },
  { regionId: "3", regionName: "منطقة المدينة المنورة", newsAccountHandle: "MadinahNews", searchQuery: "site:al-madina.com المدينة المنورة" },
  { regionId: "4", regionName: "منطقة القصيم", newsAccountHandle: "QassimNews", searchQuery: "site:sabq.org OR site:alriyadh.com القصيم بريدة" },
  { regionId: "5", regionName: "المنطقة الشرقية", newsAccountHandle: "EasternNews", searchQuery: "site:alyaum.com الدمام الشرقية" },
  { regionId: "6", regionName: "منطقة عسير", newsAccountHandle: "AsirNews", searchQuery: "site:sabq.org OR site:okaz.com.sa عسير أبها" },
  { regionId: "7", regionName: "منطقة تبوك", newsAccountHandle: "TabukNews", searchQuery: "site:sabq.org OR site:alriyadh.com تبوك" },
  { regionId: "8", regionName: "منطقة حائل", newsAccountHandle: "HailNews", searchQuery: "site:sabq.org OR site:alriyadh.com حائل" },
  { regionId: "9", regionName: "منطقة الحدود الشمالية", newsAccountHandle: "NorthernBorderNews", searchQuery: "site:sabq.org الحدود الشمالية عرعر" },
  { regionId: "10", regionName: "منطقة جازان", newsAccountHandle: "JazanNews", searchQuery: "site:sabq.org OR site:okaz.com.sa جازان" },
  { regionId: "11", regionName: "منطقة نجران", newsAccountHandle: "NajranNews", searchQuery: "site:sabq.org نجران" },
  { regionId: "12", regionName: "منطقة الباحة", newsAccountHandle: "BahahNews", searchQuery: "site:sabq.org OR site:okaz.com.sa الباحة" },
  { regionId: "13", regionName: "منطقة الجوف", newsAccountHandle: "JoufNews", searchQuery: "site:sabq.org الجوف سكاكا" },
];

// Keywords to detect region from news content
const REGION_KEYWORDS: { regionId: string; regionName: string; handle: string; keywords: string[] }[] = [
  { regionId: "1", regionName: "منطقة الرياض", handle: "RiyadhNews", keywords: ["الرياض", "رياض", "الدرعية", "الخرج", "الدوادمي", "المجمعة", "وادي الدواسر", "الأفلاج", "الزلفي", "شقراء", "حوطة بني تميم", "عفيف", "السليل", "ضرما", "المزاحمية", "رماح", "ثادق", "حريملاء", "الحريق", "الغاط", "مرات", "الدلم"] },
  { regionId: "2", regionName: "منطقة مكة المكرمة", handle: "MakkahNews", keywords: ["مكة", "جدة", "الطائف", "القنفذة", "الليث", "رابغ", "خليص", "الكامل", "العرضيات", "الخرمة", "رنية", "تربة", "الجموم", "بحرة", "ميسان", "أضم", "الموية"] },
  { regionId: "3", regionName: "منطقة المدينة المنورة", handle: "MadinahNews", keywords: ["المدينة المنورة", "المدينة", "ينبع", "العلا", "مهد الذهب", "الحناكية", "بدر", "خيبر", "وادي الفرع"] },
  { regionId: "4", regionName: "منطقة القصيم", handle: "QassimNews", keywords: ["القصيم", "بريدة", "عنيزة", "الرس", "المذنب", "البكيرية", "البدائع", "الأسياح", "النبهانية", "الشماسية", "عيون الجواء", "رياض الخبراء", "عقلة الصقور", "ضرية"] },
  { regionId: "5", regionName: "المنطقة الشرقية", handle: "EasternNews", keywords: ["الشرقية", "الدمام", "الظهران", "الخبر", "الأحساء", "حفر الباطن", "الجبيل", "القطيف", "الخفجي", "رأس تنورة", "بقيق", "النعيرية", "قرية العليا"] },
  { regionId: "6", regionName: "منطقة عسير", handle: "AsirNews", keywords: ["عسير", "أبها", "خميس مشيط", "بيشة", "النماص", "محايل", "ظهران الجنوب", "تثليث", "سراة عبيدة", "رجال ألمع", "أحد رفيدة", "المجاردة", "البرك", "بلقرن", "تنومة"] },
  { regionId: "7", regionName: "منطقة تبوك", handle: "TabukNews", keywords: ["تبوك", "الوجه", "ضباء", "تيماء", "أملج", "حقل", "البدع"] },
  { regionId: "8", regionName: "منطقة حائل", handle: "HailNews", keywords: ["حائل", "بقعاء", "الغزالة", "الشنان", "الحائط", "السليمي", "الشملي", "موقق"] },
  { regionId: "9", regionName: "منطقة الحدود الشمالية", handle: "NorthernBorderNews", keywords: ["الحدود الشمالية", "عرعر", "رفحاء", "طريف", "العويقيلة"] },
  { regionId: "10", regionName: "منطقة جازان", handle: "JazanNews", keywords: ["جازان", "جيزان", "صبيا", "أبو عريش", "صامطة", "الدرب", "الحرث", "ضمد", "الريث", "بيش", "فرسان", "الدائر", "العيدابي", "فيفا", "الطوال", "العارضة", "أحد المسارحة", "هروب"] },
  { regionId: "11", regionName: "منطقة نجران", handle: "NajranNews", keywords: ["نجران", "شرورة", "حبونا", "بدر الجنوب", "يدمة", "ثار", "خباش"] },
  { regionId: "12", regionName: "منطقة الباحة", handle: "BahahNews", keywords: ["الباحة", "بلجرشي", "المندق", "المخواة", "قلوة", "العقيق", "غامد الزناد", "الحجرة"] },
  { regionId: "13", regionName: "منطقة الجوف", handle: "JoufNews", keywords: ["الجوف", "سكاكا", "دومة الجندل", "القريات", "طبرجل"] },
];

function detectRegionFromContent(title: string, snippet?: string): { regionId: string; regionName: string; handle: string } | null {
  const content = `${title} ${snippet || ""}`.toLowerCase();
  
  for (const region of REGION_KEYWORDS) {
    for (const keyword of region.keywords) {
      if (content.includes(keyword.toLowerCase()) || content.includes(keyword)) {
        return { regionId: region.regionId, regionName: region.regionName, handle: region.handle };
      }
    }
  }
  
  return null;
}

interface GoogleNewsResult {
  title: string;
  snippet?: string;
  source: string;
  lastUpdated?: string;
  url: string;
  imgSrc?: string;
}

async function fetchNewsFromScrapingdog(query: string): Promise<GoogleNewsResult[]> {
  if (!SCRAPINGDOG_API_KEY) {
    console.log("⚠️ SCRAPINGDOG_API_KEY not set, skipping news scraping");
    return [];
  }

  try {
    const apiUrl = `https://api.scrapingdog.com/google_news/v2?api_key=${SCRAPINGDOG_API_KEY}&query=${encodeURIComponent(query)}&country=sa&language=ar`;
    
    console.log(`📰 Fetching news for: ${query}`);
    const response = await fetch(apiUrl);
    
    if (!response.ok) {
      console.error(`Scrapingdog error: ${response.status}`);
      return [];
    }

    const data = await response.json();
    return data.news_results || [];
  } catch (error) {
    console.error("Error fetching news:", error);
    return [];
  }
}

async function getNewsAccountId(handle: string): Promise<number | null> {
  const result = await db.select().from(users).where(eq(users.handle, handle));
  return result[0]?.id || null;
}

async function postNewsAsTweet(
  userId: number,
  content: string,
  regionId: string,
  regionName: string
): Promise<void> {
  await db.insert(tweets).values({
    userId,
    content,
    locationId: regionId,
    locationName: regionName,
  });
}

export async function scrapeAndPostRegionalNews(): Promise<void> {
  console.log("🗞️ Starting regional news scraping with Scrapingdog Google News API...");

  for (const source of NEWS_SOURCES) {
    try {
      const newsResults = await fetchNewsFromScrapingdog(source.searchQuery);
      
      for (const item of newsResults.slice(0, 3)) {
        // Detect the actual region from the news content
        const detectedRegion = detectRegionFromContent(item.title, item.snippet);
        
        // Use detected region if found, otherwise use the source's default region
        const targetRegion = detectedRegion || { 
          regionId: source.regionId, 
          regionName: source.regionName, 
          handle: source.newsAccountHandle 
        };
        
        const accountId = await getNewsAccountId(targetRegion.handle);
        
        if (!accountId) {
          console.log(`⚠️ News account not found: ${targetRegion.handle}`);
          continue;
        }

        const hashtag = targetRegion.regionName.replace(/منطقة /g, '').replace(/ /g, '_');
        const tweetContent = `📰 ${item.title}\n\nالمصدر: ${item.source}${item.lastUpdated ? ` | ${item.lastUpdated}` : ''}\n\n#أخبار_${hashtag} #${hashtag}`;
        
        await postNewsAsTweet(accountId, tweetContent, targetRegion.regionId, targetRegion.regionName);
        
        if (detectedRegion && detectedRegion.regionId !== source.regionId) {
          console.log(`✅ Posted news for ${targetRegion.regionName} (detected from ${source.regionName}): ${item.title.substring(0, 50)}...`);
        } else {
          console.log(`✅ Posted news for ${targetRegion.regionName}: ${item.title.substring(0, 50)}...`);
        }
      }

      await new Promise(resolve => setTimeout(resolve, 500));
    } catch (error) {
      console.error(`Error fetching news for ${source.regionName}:`, error);
    }
  }

  console.log("✅ Regional news scraping completed");
}

export async function postPrayerTimesTweet(regionId: string): Promise<void> {
  const regionCities: Record<string, { city: string; cityAr: string; lat: number; lng: number; handle: string }> = {
    "1": { city: "Riyadh", cityAr: "الرياض", lat: 24.7136, lng: 46.6753, handle: "SalatRiyadh" },
    "2": { city: "Makkah", cityAr: "مكة المكرمة", lat: 21.4225, lng: 39.8262, handle: "SalatMakkah" },
    "3": { city: "Madinah", cityAr: "المدينة المنورة", lat: 24.5247, lng: 39.5692, handle: "SalatMadinah" },
    "4": { city: "Buraidah", cityAr: "القصيم", lat: 26.3267, lng: 43.9750, handle: "SalatQassim" },
    "5": { city: "Dammam", cityAr: "الشرقية", lat: 26.4207, lng: 50.0888, handle: "SalatEastern" },
    "6": { city: "Abha", cityAr: "عسير", lat: 18.2164, lng: 42.5053, handle: "SalatAsir" },
    "7": { city: "Tabuk", cityAr: "تبوك", lat: 28.3838, lng: 36.5550, handle: "SalatTabuk" },
    "8": { city: "Hail", cityAr: "حائل", lat: 27.5114, lng: 41.7208, handle: "SalatHail" },
    "9": { city: "Arar", cityAr: "الحدود الشمالية", lat: 30.9753, lng: 41.0381, handle: "SalatNBorder" },
    "10": { city: "Jazan", cityAr: "جازان", lat: 16.8892, lng: 42.5511, handle: "SalatJazan" },
    "11": { city: "Najran", cityAr: "نجران", lat: 17.4933, lng: 44.1277, handle: "SalatNajran" },
    "12": { city: "Bahah", cityAr: "الباحة", lat: 20.0125, lng: 41.4683, handle: "SalatBahah" },
    "13": { city: "Sakaka", cityAr: "الجوف", lat: 29.9697, lng: 40.2064, handle: "SalatJouf" }
  };

  const region = regionCities[regionId];
  if (!region) return;

  try {
    const accountId = await getNewsAccountId(region.handle);
    if (!accountId) {
      console.log(`⚠️ Prayer times account not found: ${region.handle}`);
      return;
    }

    const today = new Date();
    const dateStr = `${today.getDate().toString().padStart(2, '0')}-${(today.getMonth() + 1).toString().padStart(2, '0')}-${today.getFullYear()}`;
    
    const response = await fetch(
      `https://api.aladhan.com/v1/timings/${dateStr}?latitude=${region.lat}&longitude=${region.lng}&method=4`
    );
    
    if (!response.ok) throw new Error("Failed to fetch prayer times");
    
    const data = await response.json();
    const timings = data.data.timings;
    const hijri = data.data.date.hijri;

    const tweetContent = `🕌 مواقيت الصلاة في ${region.cityAr}
📅 ${hijri.day} ${hijri.month.ar} ${hijri.year}

🌙 الفجر: ${timings.Fajr}
☀️ الشروق: ${timings.Sunrise}
🌤️ الظهر: ${timings.Dhuhr}
🌅 العصر: ${timings.Asr}
🌆 المغرب: ${timings.Maghrib}
🌙 العشاء: ${timings.Isha}

#مواقيت_الصلاة #${region.cityAr.replace(/ /g, '_')}`;

    await postNewsAsTweet(accountId, tweetContent, regionId, `منطقة ${region.cityAr}`);
    console.log(`✅ Posted prayer times for ${region.cityAr}`);
  } catch (error) {
    console.error(`Error posting prayer times for region ${regionId}:`, error);
  }
}

export async function postBreakingNews(): Promise<void> {
  console.log("🔴 Fetching breaking news...");
  
  const accountId = await getNewsAccountId("BreakingNewsSA");
  if (!accountId) {
    console.log("⚠️ Breaking news account not found");
    return;
  }

  try {
    const newsResults = await fetchNewsFromScrapingdog("أخبار عاجلة السعودية");
    
    for (const item of newsResults.slice(0, 2)) {
      const tweetContent = `🔴 عاجل | ${item.title}\n\nالمصدر: ${item.source}${item.lastUpdated ? ` | ${item.lastUpdated}` : ''}\n\n#أخبار_عاجلة #السعودية`;
      
      await postNewsAsTweet(accountId, tweetContent, "all", "المملكة العربية السعودية");
      console.log(`✅ Posted breaking news: ${item.title.substring(0, 50)}...`);
    }
    
    console.log("✅ Breaking news posted");
  } catch (error) {
    console.error("Error fetching breaking news:", error);
  }
}

export async function postAllPrayerTimes(): Promise<void> {
  console.log("🕌 Posting prayer times for all regions...");
  
  for (let i = 1; i <= 13; i++) {
    await postPrayerTimesTweet(i.toString());
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  
  console.log("✅ All prayer times posted");
}
