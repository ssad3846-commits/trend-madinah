const BEARER_TOKEN = process.env.TWITTER_BEARER_TOKEN;

export interface FormattedTrend {
  hashtag: string;
  posts: string;
  rank: number;
}

interface Tweet {
  id: string;
  text: string;
  public_metrics?: {
    retweet_count: number;
    reply_count: number;
    like_count: number;
    quote_count: number;
  };
  created_at?: string;
}

interface SearchResponse {
  data?: Tweet[];
  meta?: {
    result_count: number;
    newest_id?: string;
    oldest_id?: string;
    next_token?: string;
  };
}

const MADINAH_KEYWORDS = [
  "المدينة_المنورة",
  "المدينة",
  "طيبة",
  "المسجد_النبوي",
  "قباء",
  "الحرم_النبوي",
];

export async function fetchTwitterTrends(): Promise<FormattedTrend[]> {
  if (!BEARER_TOKEN) {
    console.error("Twitter Bearer Token not configured");
    return getStaticMadinahTrends();
  }

  try {
    const query = encodeURIComponent(`(${MADINAH_KEYWORDS.join(" OR ")}) lang:ar -is:retweet`);
    const response = await fetch(
      `https://api.twitter.com/2/tweets/search/recent?query=${query}&max_results=100&tweet.fields=public_metrics,created_at`,
      {
        headers: {
          Authorization: `Bearer ${BEARER_TOKEN}`,
        },
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Twitter API error:", response.status, errorText);
      return getStaticMadinahTrends();
    }

    const data: SearchResponse = await response.json();
    
    if (!data || !data.data || data.data.length === 0) {
      console.log("No tweets found, using static trends");
      return getStaticMadinahTrends();
    }

    const hashtagCounts: Map<string, number> = new Map();
    
    for (const tweet of data.data) {
      const hashtags = tweet.text.match(/#[\u0600-\u06FFa-zA-Z0-9_]+/g);
      if (hashtags) {
        for (const tag of hashtags) {
          const count = hashtagCounts.get(tag) || 0;
          hashtagCounts.set(tag, count + 1);
        }
      }
    }

    const sortedHashtags = Array.from(hashtagCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 15);

    if (sortedHashtags.length === 0) {
      return getStaticMadinahTrends();
    }

    return sortedHashtags.map(([hashtag, count], index) => ({
      hashtag,
      posts: formatNumber(count * 100),
      rank: index + 1,
    }));
  } catch (error) {
    console.error("Error fetching Twitter trends:", error);
    return getStaticMadinahTrends();
  }
}

function getStaticMadinahTrends(): FormattedTrend[] {
  return [
    { hashtag: "#المدينة_المنورة", posts: "15.2K", rank: 1 },
    { hashtag: "#المسجد_النبوي", posts: "12.8K", rank: 2 },
    { hashtag: "#طيبة_الطيبة", posts: "9.5K", rank: 3 },
    { hashtag: "#قباء", posts: "7.3K", rank: 4 },
    { hashtag: "#الحرم_النبوي", posts: "6.8K", rank: 5 },
    { hashtag: "#زيارة_المدينة", posts: "5.4K", rank: 6 },
    { hashtag: "#السعودية", posts: "4.9K", rank: 7 },
    { hashtag: "#الروضة_الشريفة", posts: "4.2K", rank: 8 },
    { hashtag: "#العمرة", posts: "3.8K", rank: 9 },
    { hashtag: "#الحج", posts: "3.5K", rank: 10 },
  ];
}

function formatNumber(num: number): string {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + "M";
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + "K";
  }
  return num.toString();
}

export interface UserTweet {
  id: string;
  text: string;
  likes: number;
  retweets: number;
  replies: number;
  createdAt: string;
}

interface UserResponse {
  data?: {
    id: string;
    name: string;
    username: string;
  };
}

interface UserTweetsResponse {
  data?: Tweet[];
  includes?: {
    users?: Array<{ id: string; name: string; username: string }>;
  };
  meta?: {
    result_count: number;
    next_token?: string;
  };
}

export async function fetchUserTweets(username: string, maxResults: number = 10): Promise<UserTweet[]> {
  if (!BEARER_TOKEN) {
    console.error("Twitter Bearer Token not configured");
    return [];
  }

  try {
    const userResponse = await fetch(
      `https://api.twitter.com/2/users/by/username/${username}`,
      {
        headers: {
          Authorization: `Bearer ${BEARER_TOKEN}`,
        },
      }
    );

    if (!userResponse.ok) {
      console.error("Twitter User API error:", userResponse.status);
      return [];
    }

    const userData: UserResponse = await userResponse.json();
    if (!userData.data) {
      console.error("User not found:", username);
      return [];
    }

    const userId = userData.data.id;

    const tweetsResponse = await fetch(
      `https://api.twitter.com/2/users/${userId}/tweets?max_results=${maxResults}&tweet.fields=created_at,public_metrics&exclude=retweets,replies`,
      {
        headers: {
          Authorization: `Bearer ${BEARER_TOKEN}`,
        },
      }
    );

    if (!tweetsResponse.ok) {
      console.error("Twitter Tweets API error:", tweetsResponse.status);
      return [];
    }

    const tweetsData: UserTweetsResponse = await tweetsResponse.json();
    
    if (!tweetsData.data || tweetsData.data.length === 0) {
      return [];
    }

    return tweetsData.data.map(tweet => ({
      id: tweet.id,
      text: tweet.text,
      likes: tweet.public_metrics?.like_count || 0,
      retweets: tweet.public_metrics?.retweet_count || 0,
      replies: tweet.public_metrics?.reply_count || 0,
      createdAt: tweet.created_at || new Date().toISOString(),
    }));
  } catch (error) {
    console.error("Error fetching user tweets:", error);
    return [];
  }
}

export async function searchTwitter(query: string, maxResults: number = 10): Promise<Tweet[]> {
  if (!BEARER_TOKEN) {
    console.error("Twitter Bearer Token not configured");
    return [];
  }

  try {
    const encodedQuery = encodeURIComponent(query);
    const response = await fetch(
      `https://api.twitter.com/2/tweets/search/recent?query=${encodedQuery}&max_results=${maxResults}&tweet.fields=created_at,public_metrics`,
      {
        headers: {
          Authorization: `Bearer ${BEARER_TOKEN}`,
        },
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Twitter Search API error:", response.status, errorText);
      return [];
    }

    const data: SearchResponse = await response.json();
    return data.data || [];
  } catch (error) {
    console.error("Error searching Twitter:", error);
    return [];
  }
}
