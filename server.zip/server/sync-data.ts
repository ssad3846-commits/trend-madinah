import { db } from "./storage";
import { neighborhoods, liveCameras } from "@shared/schema";
import { eq, sql } from "drizzle-orm";

const SAUDI_REGIONS = [
  { id: "all", name: "المملكة العربية السعودية" },
  { id: "1", name: "منطقة الرياض" },
  { id: "2", name: "منطقة مكة المكرمة" },
  { id: "3", name: "منطقة المدينة المنورة" },
  { id: "4", name: "منطقة القصيم" },
  { id: "5", name: "المنطقة الشرقية" },
  { id: "6", name: "منطقة عسير" },
  { id: "7", name: "منطقة تبوك" },
  { id: "8", name: "منطقة حائل" },
  { id: "9", name: "منطقة الحدود الشمالية" },
  { id: "10", name: "منطقة جازان" },
  { id: "11", name: "منطقة نجران" },
  { id: "12", name: "منطقة الباحة" },
  { id: "13", name: "منطقة الجوف" },
];

const LIVE_CAMERAS = [
  { name: "المسجد النبوي الشريف", description: "بث مباشر 24 ساعة من المسجد النبوي الشريف", category: "مسجد", locationId: "all", locationName: "المدينة المنورة", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/TpT8b8JFZ6E?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/TpT8b8JFZ6E/maxresdefault.jpg", isOfficial: true, isLive: true },
  { name: "الحرم المكي الشريف", description: "بث مباشر من المسجد الحرام بمكة المكرمة", category: "مسجد", locationId: "all", locationName: "مكة المكرمة", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/Jj0E03q6Zcw?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/Jj0E03q6Zcw/maxresdefault.jpg", isOfficial: true, isLive: true },
  { name: "تقاطع شيبويا - طوكيو", description: "أشهر تقاطع في العالم - طوكيو، اليابان", category: "ساحات", locationId: "all", locationName: "طوكيو، اليابان", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/tujkoXI8rWM?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/tujkoXI8rWM/maxresdefault.jpg", isOfficial: true, isLive: true },
  { name: "تايمز سكوير - نيويورك", description: "ميدان تايمز سكوير بجودة 4K - نيويورك", category: "ساحات", locationId: "all", locationName: "نيويورك، أمريكا", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/rnXIjl_Rzy4?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/rnXIjl_Rzy4/maxresdefault.jpg", isOfficial: true, isLive: true },
  { name: "طوكيو - أكيهابارا", description: "منطقة الإلكترونيات والأنيمي الشهيرة في طوكيو", category: "ساحات", locationId: "all", locationName: "طوكيو، اليابان", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/gFRtAAmiFbE?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/gFRtAAmiFbE/maxresdefault.jpg", isOfficial: true, isLive: true },
  { name: "سيول - شارع ميونغدونغ", description: "منطقة التسوق الشهيرة في سيول - كوريا", category: "ساحات", locationId: "all", locationName: "سيول، كوريا", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/V8-dA5P-IeI?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/V8-dA5P-IeI/maxresdefault.jpg", isOfficial: true, isLive: true },
  { name: "براغ - ساحة البلدة القديمة", description: "الساعة الفلكية التاريخية في براغ", category: "ساحات", locationId: "all", locationName: "براغ، التشيك", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/Af3TfXJ1ehs?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/Af3TfXJ1ehs/maxresdefault.jpg", isOfficial: true, isLive: true },
  { name: "دبي - برج خليفة", description: "أطول برج في العالم مباشرة من دبي", category: "ساحات", locationId: "all", locationName: "دبي، الإمارات", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/RDWxdj7h_b4?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/RDWxdj7h_b4/maxresdefault.jpg", isOfficial: true, isLive: true },
  { name: "قناة الجزيرة", description: "البث المباشر لقناة الجزيرة الإخبارية", category: "أخبار", locationId: "all", locationName: "قطر", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/bNyUyrR0PHo?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/bNyUyrR0PHo/maxresdefault.jpg", isOfficial: true, isLive: true },
  { name: "قناة الإخبارية السعودية", description: "البث المباشر لقناة الإخبارية السعودية", category: "أخبار", locationId: "all", locationName: "السعودية", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/FMwgPHBj5_A?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/FMwgPHBj5_A/maxresdefault.jpg", isOfficial: true, isLive: true },
  { name: "قناة العربية", description: "البث المباشر لقناة العربية الإخبارية", category: "أخبار", locationId: "all", locationName: "الإمارات", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/1Mg9sxWljDc?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/1Mg9sxWljDc/maxresdefault.jpg", isOfficial: true, isLive: true },
  { name: "قناة السعودية", description: "البث المباشر من القناة السعودية الرسمية", category: "أخبار", locationId: "all", locationName: "السعودية", sourceType: "youtube", embedUrl: "https://www.youtube.com/embed/6Mn1VlmJ7Ac?autoplay=1", thumbnailUrl: "https://i.ytimg.com/vi/6Mn1VlmJ7Ac/maxresdefault.jpg", isOfficial: true, isLive: true },
];

export async function syncData() {
  console.log("🔄 Syncing data...");

  try {
    for (const region of SAUDI_REGIONS) {
      await db.insert(neighborhoods).values(region).onConflictDoUpdate({
        target: neighborhoods.id,
        set: { name: region.name }
      });
    }
    console.log("✅ Regions synced");

    const existingCameras = await db.select().from(liveCameras);
    
    if (existingCameras.length === 0) {
      await db.insert(liveCameras).values(LIVE_CAMERAS);
      console.log("✅ Cameras seeded");
    } else {
      await db.delete(liveCameras);
      await db.insert(liveCameras).values(LIVE_CAMERAS);
      console.log("✅ Cameras refreshed");
    }

    console.log("🎉 Data sync completed!");
  } catch (error) {
    console.error("❌ Error syncing data:", error);
  }
}
