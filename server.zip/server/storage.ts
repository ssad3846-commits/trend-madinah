import { drizzle } from "drizzle-orm/node-postgres";
import { eq, desc, and, sql, or } from "drizzle-orm";
import pg from "pg";
import bcrypt from "bcrypt";
import {
  users,
  tweets,
  questions,
  answers,
  places,
  neighborhoods,
  trends,
  userLikes,
  userRetweets,
  userFollows,
  tweetReplies,
  events,
  eventAttendees,
  liveCameras,
  chatMessages,
  hiddenAccounts,
  passwordResetCodes,
  type User,
  type InsertUser,
  type Tweet,
  type InsertTweet,
  type Question,
  type InsertQuestion,
  type Answer,
  type InsertAnswer,
  type Place,
  type InsertPlace,
  type Neighborhood,
  type InsertNeighborhood,
  type Trend,
  type InsertTrend,
  type RegisterUser,
  type UserLike,
  type UserRetweet,
  type UserFollow,
  type TweetReply,
  type Event,
  type InsertEvent,
  type EventAttendee,
  type LiveCamera,
  type ChatMessage,
  type InsertChatMessage,
  type PasswordResetCode,
} from "@shared/schema";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL environment variable is required");
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

export const db = drizzle(pool);

export interface DynamicTrend {
  hashtag: string;
  count: number;
  locationId: string | null;
  locationName: string | null;
}

export interface IStorage {
  // Auth
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByHandle(handle: string): Promise<User | undefined>;
  checkHandleOrEmailExists(handle: string, email: string): Promise<{ handleExists: boolean; emailExists: boolean }>;
  createUserWithPassword(data: RegisterUser): Promise<User>;
  verifyPassword(email: string, password: string): Promise<User | null>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;

  // Users
  getUser(id: number): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  searchUsers(query: string): Promise<User[]>;

  // Tweets
  getTweets(locationId?: string, limit?: number, offset?: number): Promise<(Tweet & { user: User })[]>;
  getTweetById(id: number): Promise<(Tweet & { user: User }) | undefined>;
  getTweetsByUser(userId: number): Promise<(Tweet & { user: User })[]>;
  createTweet(tweet: InsertTweet): Promise<Tweet>;
  likeTweet(id: number, userId: number): Promise<{ tweet: Tweet; liked: boolean } | undefined>;
  retweetTweet(id: number, userId: number): Promise<{ tweet: Tweet; retweeted: boolean } | undefined>;
  getUserLikedTweets(userId: number): Promise<(Tweet & { user: User })[]>;
  getUserRetweetedTweets(userId: number): Promise<(Tweet & { user: User })[]>;
  getUserLikeStatus(userId: number, tweetIds: number[]): Promise<{ tweetId: number; liked: boolean }[]>;
  getUserRetweetStatus(userId: number, tweetIds: number[]): Promise<{ tweetId: number; retweeted: boolean }[]>;

  // Follows
  followUser(followerId: number, followingId: number): Promise<{ following: boolean }>;
  isFollowing(followerId: number, followingId: number): Promise<boolean>;
  getFollowers(userId: number): Promise<User[]>;
  getFollowing(userId: number): Promise<User[]>;

  // Replies
  createReply(tweetId: number, userId: number, content: string): Promise<TweetReply & { user: User }>;
  getReplies(tweetId: number): Promise<(TweetReply & { user: User })[]>;

  // Questions
  getQuestions(locationId?: string): Promise<Question[]>;
  getQuestionById(id: number): Promise<Question | undefined>;
  createQuestion(question: InsertQuestion): Promise<Question>;
  getAnswersByQuestion(questionId: number): Promise<Answer[]>;
  createAnswer(answer: InsertAnswer): Promise<Answer>;

  // Places
  getPlaces(locationId?: string, category?: string): Promise<Place[]>;
  getPlaceById(id: number): Promise<Place | undefined>;
  createPlace(place: InsertPlace): Promise<Place>;

  // Neighborhoods
  getNeighborhoods(): Promise<Neighborhood[]>;
  createNeighborhood(neighborhood: InsertNeighborhood): Promise<Neighborhood>;

  // Trends
  getTrends(locationId?: string, limit?: number): Promise<Trend[]>;
  createTrend(trend: InsertTrend): Promise<Trend>;
  getDynamicTrends(locationId?: string, limit?: number): Promise<DynamicTrend[]>;
  getNeighborhoodEngagement(): Promise<{ locationId: string; engagement: number }[]>;

  // Events
  getEvents(locationId?: string): Promise<Event[]>;
  getEventById(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  toggleEventAttendance(eventId: number, userId: number, status: "attending" | "interested"): Promise<{ event: Event; status: string | null }>;
  getUserEventStatus(userId: number, eventId: number): Promise<string | null>;

  // Live Cameras
  getLiveCameras(locationId?: string, category?: string): Promise<LiveCamera[]>;
  getLiveCameraById(id: number): Promise<LiveCamera | undefined>;

  // Chat Messages
  getChatMessagesNearby(latitude: number, longitude: number, radiusKm?: number): Promise<(ChatMessage & { user: User })[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;

  // Automated Accounts
  getAutomatedAccounts(type?: string, regionId?: string): Promise<User[]>;

  // Hidden Accounts
  hideAccount(userId: number, hiddenUserId: number): Promise<boolean>;
  unhideAccount(userId: number, hiddenUserId: number): Promise<boolean>;
  isAccountHidden(userId: number, hiddenUserId: number): Promise<boolean>;
  getHiddenAccounts(userId: number): Promise<User[]>;

  // Password Reset
  createPasswordResetCode(email: string): Promise<string>;
  verifyPasswordResetCode(email: string, code: string): Promise<boolean>;
  resetPassword(email: string, newPassword: string): Promise<boolean>;

  // Admin Statistics
  getAdminStats(): Promise<{
    totalUsers: number;
    totalTweets: number;
    totalQuestions: number;
    totalPlaces: number;
    tweetsPerRegion: { regionId: string; regionName: string; count: number }[];
    usersPerDay: { date: string; count: number }[];
    tweetsPerDay: { date: string; count: number }[];
  }>;
}

export class PostgresStorage implements IStorage {
  // Auth
  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async getUserByHandle(handle: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.handle, handle));
    return result[0];
  }

  async checkHandleOrEmailExists(handle: string, email: string): Promise<{ handleExists: boolean; emailExists: boolean }> {
    const result = await db.select().from(users).where(
      or(eq(users.handle, handle), eq(users.email, email))
    );
    
    let handleExists = false;
    let emailExists = false;
    
    for (const user of result) {
      if (user.handle === handle) handleExists = true;
      if (user.email === email) emailExists = true;
    }
    
    return { handleExists, emailExists };
  }

  async createUserWithPassword(data: RegisterUser): Promise<User> {
    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(data.password, saltRounds);
    
    const result = await db.insert(users).values({
      name: data.name,
      handle: data.handle,
      email: data.email,
      passwordHash: passwordHash,
      avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(data.name)}`,
      verified: false,
    }).returning();
    
    return result[0];
  }

  async verifyPassword(emailOrHandle: string, password: string): Promise<User | null> {
    let user = await this.getUserByEmail(emailOrHandle);
    if (!user) {
      user = await this.getUserByHandle(emailOrHandle);
    }
    if (!user || !user.passwordHash) return null;
    
    const isValid = await bcrypt.compare(password, user.passwordHash);
    return isValid ? user : null;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const result = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async searchUsers(query: string): Promise<User[]> {
    const searchPattern = `%${query}%`;
    return await db
      .select()
      .from(users)
      .where(
        or(
          sql`${users.name} ILIKE ${searchPattern}`,
          sql`${users.handle} ILIKE ${searchPattern}`
        )
      )
      .limit(20);
  }

  // Tweets
  async getTweets(locationId?: string, limit: number = 30, offset: number = 0): Promise<(Tweet & { user: User })[]> {
    let baseQuery = db
      .select({
        tweet: tweets,
        user: users,
      })
      .from(tweets)
      .leftJoin(users, eq(tweets.userId, users.id))
      .orderBy(desc(tweets.createdAt))
      .limit(limit)
      .offset(offset);

    let result;
    if (locationId && locationId !== "all") {
      result = await db
        .select({
          tweet: tweets,
          user: users,
        })
        .from(tweets)
        .leftJoin(users, eq(tweets.userId, users.id))
        .where(eq(tweets.locationId, locationId))
        .orderBy(desc(tweets.createdAt))
        .limit(limit)
        .offset(offset);
    } else {
      result = await baseQuery;
    }

    return result.map(r => ({ ...r.tweet, user: r.user! }));
  }

  async getTweetById(id: number): Promise<(Tweet & { user: User }) | undefined> {
    const result = await db
      .select({
        tweet: tweets,
        user: users,
      })
      .from(tweets)
      .leftJoin(users, eq(tweets.userId, users.id))
      .where(eq(tweets.id, id));

    if (result.length === 0) return undefined;
    return { ...result[0].tweet, user: result[0].user! };
  }

  async getTweetsByUser(userId: number): Promise<(Tweet & { user: User })[]> {
    const result = await db
      .select({
        tweet: tweets,
        user: users,
      })
      .from(tweets)
      .leftJoin(users, eq(tweets.userId, users.id))
      .where(eq(tweets.userId, userId))
      .orderBy(desc(tweets.createdAt));
    
    return result.map(r => ({ ...r.tweet, user: r.user! }));
  }

  async createTweet(tweet: InsertTweet): Promise<Tweet> {
    const result = await db.insert(tweets).values(tweet).returning();
    return result[0];
  }

  async likeTweet(id: number, userId: number): Promise<{ tweet: Tweet; liked: boolean } | undefined> {
    const existingLike = await db
      .select()
      .from(userLikes)
      .where(and(eq(userLikes.userId, userId), eq(userLikes.tweetId, id)));
    
    if (existingLike.length > 0) {
      await db.delete(userLikes).where(and(eq(userLikes.userId, userId), eq(userLikes.tweetId, id)));
      const result = await db
        .update(tweets)
        .set({ likes: sql`GREATEST(${tweets.likes} - 1, 0)` })
        .where(eq(tweets.id, id))
        .returning();
      return result[0] ? { tweet: result[0], liked: false } : undefined;
    } else {
      await db.insert(userLikes).values({ userId, tweetId: id });
      const result = await db
        .update(tweets)
        .set({ likes: sql`${tweets.likes} + 1` })
        .where(eq(tweets.id, id))
        .returning();
      return result[0] ? { tweet: result[0], liked: true } : undefined;
    }
  }

  async retweetTweet(id: number, userId: number): Promise<{ tweet: Tweet; retweeted: boolean } | undefined> {
    const existingRetweet = await db
      .select()
      .from(userRetweets)
      .where(and(eq(userRetweets.userId, userId), eq(userRetweets.tweetId, id)));
    
    if (existingRetweet.length > 0) {
      await db.delete(userRetweets).where(and(eq(userRetweets.userId, userId), eq(userRetweets.tweetId, id)));
      const result = await db
        .update(tweets)
        .set({ retweets: sql`GREATEST(${tweets.retweets} - 1, 0)` })
        .where(eq(tweets.id, id))
        .returning();
      return result[0] ? { tweet: result[0], retweeted: false } : undefined;
    } else {
      await db.insert(userRetweets).values({ userId, tweetId: id });
      const result = await db
        .update(tweets)
        .set({ retweets: sql`${tweets.retweets} + 1` })
        .where(eq(tweets.id, id))
        .returning();
      return result[0] ? { tweet: result[0], retweeted: true } : undefined;
    }
  }

  async getUserLikedTweets(userId: number): Promise<(Tweet & { user: User })[]> {
    const result = await db
      .select({
        tweet: tweets,
        user: users,
      })
      .from(userLikes)
      .innerJoin(tweets, eq(userLikes.tweetId, tweets.id))
      .leftJoin(users, eq(tweets.userId, users.id))
      .where(eq(userLikes.userId, userId))
      .orderBy(desc(userLikes.createdAt));
    
    return result.map(r => ({ ...r.tweet, user: r.user! }));
  }

  async getUserRetweetedTweets(userId: number): Promise<(Tweet & { user: User })[]> {
    const result = await db
      .select({
        tweet: tweets,
        user: users,
      })
      .from(userRetweets)
      .innerJoin(tweets, eq(userRetweets.tweetId, tweets.id))
      .leftJoin(users, eq(tweets.userId, users.id))
      .where(eq(userRetweets.userId, userId))
      .orderBy(desc(userRetweets.createdAt));
    
    return result.map(r => ({ ...r.tweet, user: r.user! }));
  }

  async getUserLikeStatus(userId: number, tweetIds: number[]): Promise<{ tweetId: number; liked: boolean }[]> {
    if (tweetIds.length === 0) return [];
    
    const likes = await db
      .select()
      .from(userLikes)
      .where(eq(userLikes.userId, userId));
    
    const likedTweetIds = new Set(likes.map(l => l.tweetId));
    return tweetIds.map(tweetId => ({ tweetId, liked: likedTweetIds.has(tweetId) }));
  }

  async getUserRetweetStatus(userId: number, tweetIds: number[]): Promise<{ tweetId: number; retweeted: boolean }[]> {
    if (tweetIds.length === 0) return [];
    
    const retweets = await db
      .select()
      .from(userRetweets)
      .where(eq(userRetweets.userId, userId));
    
    const retweetedTweetIds = new Set(retweets.map(r => r.tweetId));
    return tweetIds.map(tweetId => ({ tweetId, retweeted: retweetedTweetIds.has(tweetId) }));
  }

  // Follows
  async followUser(followerId: number, followingId: number): Promise<{ following: boolean }> {
    if (followerId === followingId) {
      throw new Error("Cannot follow yourself");
    }

    const existingFollow = await db
      .select()
      .from(userFollows)
      .where(and(eq(userFollows.followerId, followerId), eq(userFollows.followingId, followingId)));
    
    if (existingFollow.length > 0) {
      // Unfollow
      await db.delete(userFollows).where(and(eq(userFollows.followerId, followerId), eq(userFollows.followingId, followingId)));
      await db.update(users).set({ following: sql`GREATEST(${users.following} - 1, 0)` }).where(eq(users.id, followerId));
      await db.update(users).set({ followers: sql`GREATEST(${users.followers} - 1, 0)` }).where(eq(users.id, followingId));
      return { following: false };
    } else {
      // Follow
      await db.insert(userFollows).values({ followerId, followingId });
      await db.update(users).set({ following: sql`${users.following} + 1` }).where(eq(users.id, followerId));
      await db.update(users).set({ followers: sql`${users.followers} + 1` }).where(eq(users.id, followingId));
      return { following: true };
    }
  }

  async isFollowing(followerId: number, followingId: number): Promise<boolean> {
    const result = await db
      .select()
      .from(userFollows)
      .where(and(eq(userFollows.followerId, followerId), eq(userFollows.followingId, followingId)));
    return result.length > 0;
  }

  async getFollowers(userId: number): Promise<User[]> {
    const result = await db
      .select({ user: users })
      .from(userFollows)
      .innerJoin(users, eq(userFollows.followerId, users.id))
      .where(eq(userFollows.followingId, userId));
    return result.map(r => r.user);
  }

  async getFollowing(userId: number): Promise<User[]> {
    const result = await db
      .select({ user: users })
      .from(userFollows)
      .innerJoin(users, eq(userFollows.followingId, users.id))
      .where(eq(userFollows.followerId, userId));
    return result.map(r => r.user);
  }

  // Replies
  async createReply(tweetId: number, userId: number, content: string): Promise<TweetReply & { user: User }> {
    const [reply] = await db.insert(tweetReplies).values({
      tweetId,
      userId,
      content,
    }).returning();

    await db.update(tweets).set({
      replies: sql`${tweets.replies} + 1`
    }).where(eq(tweets.id, tweetId));

    const [user] = await db.select().from(users).where(eq(users.id, userId));
    return { ...reply, user };
  }

  async getReplies(tweetId: number): Promise<(TweetReply & { user: User })[]> {
    const repliesWithUsers = await db
      .select()
      .from(tweetReplies)
      .innerJoin(users, eq(tweetReplies.userId, users.id))
      .where(eq(tweetReplies.tweetId, tweetId))
      .orderBy(desc(tweetReplies.createdAt));

    return repliesWithUsers.map(r => ({
      ...r.tweet_replies,
      user: r.users,
    }));
  }

  // Questions
  async getQuestions(locationId?: string): Promise<Question[]> {
    let query = db.select().from(questions).orderBy(desc(questions.createdAt));

    if (locationId && locationId !== "all") {
      query = query.where(eq(questions.locationId, locationId)) as any;
    }

    return await query;
  }

  async getQuestionById(id: number): Promise<Question | undefined> {
    const result = await db.select().from(questions).where(eq(questions.id, id));
    return result[0];
  }

  async createQuestion(question: InsertQuestion): Promise<Question> {
    const result = await db.insert(questions).values(question).returning();
    return result[0];
  }

  async getAnswersByQuestion(questionId: number): Promise<Answer[]> {
    return await db
      .select()
      .from(answers)
      .where(eq(answers.questionId, questionId))
      .orderBy(desc(answers.createdAt));
  }

  async createAnswer(answer: InsertAnswer): Promise<Answer> {
    const result = await db.insert(answers).values(answer).returning();
    
    // Increment answers count on question
    await db
      .update(questions)
      .set({ answersCount: sql`${questions.answersCount} + 1` })
      .where(eq(questions.id, answer.questionId));
    
    return result[0];
  }

  // Places
  async getPlaces(locationId?: string, category?: string): Promise<Place[]> {
    let query = db.select().from(places);

    const conditions = [];
    
    // Show only places from the selected region
    if (locationId && locationId !== "all") {
      conditions.push(eq(places.locationId, locationId));
    }
    
    if (category && category !== "all") {
      conditions.push(eq(places.category, category.toUpperCase()));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }

    return await query;
  }

  async getPlaceById(id: number): Promise<Place | undefined> {
    const result = await db.select().from(places).where(eq(places.id, id));
    return result[0];
  }

  async createPlace(place: InsertPlace): Promise<Place> {
    const result = await db.insert(places).values(place).returning();
    return result[0];
  }

  // Neighborhoods
  async getNeighborhoods(): Promise<Neighborhood[]> {
    return await db.select().from(neighborhoods);
  }

  async createNeighborhood(neighborhood: InsertNeighborhood): Promise<Neighborhood> {
    const result = await db.insert(neighborhoods).values(neighborhood).returning();
    return result[0];
  }

  // Trends
  async getTrends(locationId?: string, limit: number = 5): Promise<Trend[]> {
    let query = db.select().from(trends).orderBy(trends.rank).limit(limit);

    if (locationId && locationId !== "all") {
      query = query.where(eq(trends.locationId, locationId)) as any;
    }

    return await query;
  }

  async createTrend(trend: InsertTrend): Promise<Trend> {
    const result = await db.insert(trends).values(trend).returning();
    return result[0];
  }

  async getDynamicTrends(locationId?: string, limit: number = 10): Promise<DynamicTrend[]> {
    const allTweets = await db.select().from(tweets);
    
    const hashtagCounts: Map<string, { count: number; locationId: string | null; locationName: string | null }> = new Map();
    
    const hashtagRegex = /#[\u0600-\u06FF\w]+/g;
    
    for (const tweet of allTweets) {
      if (locationId && locationId !== "all" && tweet.locationId !== locationId) {
        continue;
      }
      
      const hashtags = tweet.content.match(hashtagRegex);
      if (hashtags) {
        for (const hashtag of hashtags) {
          const existing = hashtagCounts.get(hashtag);
          if (existing) {
            existing.count++;
          } else {
            hashtagCounts.set(hashtag, {
              count: 1,
              locationId: tweet.locationId,
              locationName: tweet.locationName
            });
          }
        }
      }
    }
    
    const sortedTrends = Array.from(hashtagCounts.entries())
      .map(([hashtag, data]) => ({
        hashtag,
        count: data.count,
        locationId: data.locationId,
        locationName: data.locationName
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, limit);
    
    return sortedTrends;
  }

  async getNeighborhoodEngagement(): Promise<{ locationId: string; engagement: number }[]> {
    const allTweets = await db.select().from(tweets);
    
    const engagement: Record<string, number> = {};
    
    for (const tweet of allTweets) {
      const locId = tweet.locationId || 'all';
      if (!engagement[locId]) engagement[locId] = 0;
      engagement[locId] += (tweet.likes || 0) + (tweet.retweets || 0) * 2 + (tweet.replies || 0);
    }
    
    return Object.entries(engagement).map(([locationId, engagementValue]) => ({
      locationId,
      engagement: engagementValue
    }));
  }

  // Events
  async getEvents(locationId?: string): Promise<Event[]> {
    let query = db.select().from(events).orderBy(events.eventDate);

    if (locationId && locationId !== "all") {
      query = query.where(eq(events.locationId, locationId)) as any;
    }

    return await query;
  }

  async getEventById(id: number): Promise<Event | undefined> {
    const result = await db.select().from(events).where(eq(events.id, id));
    return result[0];
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const result = await db.insert(events).values(event).returning();
    return result[0];
  }

  async toggleEventAttendance(eventId: number, userId: number, status: "attending" | "interested"): Promise<{ event: Event; status: string | null }> {
    const existing = await db
      .select()
      .from(eventAttendees)
      .where(and(eq(eventAttendees.eventId, eventId), eq(eventAttendees.userId, userId)));

    if (existing.length > 0) {
      if (existing[0].status === status) {
        // Remove attendance
        await db.delete(eventAttendees).where(and(eq(eventAttendees.eventId, eventId), eq(eventAttendees.userId, userId)));
        
        const field = status === "attending" ? events.attendees : events.interested;
        await db.update(events).set({ [status === "attending" ? "attendees" : "interested"]: sql`GREATEST(${field} - 1, 0)` }).where(eq(events.id, eventId));
        
        const [event] = await db.select().from(events).where(eq(events.id, eventId));
        return { event, status: null };
      } else {
        // Change status
        await db.update(eventAttendees).set({ status }).where(and(eq(eventAttendees.eventId, eventId), eq(eventAttendees.userId, userId)));
        
        const oldStatus = existing[0].status;
        const oldField = oldStatus === "attending" ? events.attendees : events.interested;
        const newField = status === "attending" ? events.attendees : events.interested;
        
        await db.update(events).set({ [oldStatus === "attending" ? "attendees" : "interested"]: sql`GREATEST(${oldField} - 1, 0)` }).where(eq(events.id, eventId));
        await db.update(events).set({ [status === "attending" ? "attendees" : "interested"]: sql`${newField} + 1` }).where(eq(events.id, eventId));
        
        const [event] = await db.select().from(events).where(eq(events.id, eventId));
        return { event, status };
      }
    } else {
      // Add new attendance
      await db.insert(eventAttendees).values({ eventId, userId, status });
      
      const field = status === "attending" ? events.attendees : events.interested;
      await db.update(events).set({ [status === "attending" ? "attendees" : "interested"]: sql`${field} + 1` }).where(eq(events.id, eventId));
      
      const [event] = await db.select().from(events).where(eq(events.id, eventId));
      return { event, status };
    }
  }

  async getUserEventStatus(userId: number, eventId: number): Promise<string | null> {
    const result = await db
      .select()
      .from(eventAttendees)
      .where(and(eq(eventAttendees.eventId, eventId), eq(eventAttendees.userId, userId)));
    
    return result.length > 0 ? result[0].status : null;
  }

  // Live Cameras
  async getLiveCameras(locationId?: string, category?: string): Promise<LiveCamera[]> {
    let query = db.select().from(liveCameras).orderBy(desc(liveCameras.isOfficial));

    if (locationId && locationId !== "all") {
      query = query.where(or(eq(liveCameras.locationId, locationId), eq(liveCameras.locationId, "all"))) as any;
    }

    const result = await query;
    
    if (category) {
      return result.filter(cam => cam.category === category);
    }
    
    return result;
  }

  async getLiveCameraById(id: number): Promise<LiveCamera | undefined> {
    const result = await db.select().from(liveCameras).where(eq(liveCameras.id, id));
    return result[0];
  }

  // Chat Messages - location-based within radius
  async getChatMessagesNearby(latitude: number, longitude: number, radiusKm: number = 10): Promise<(ChatMessage & { user: User })[]> {
    const result = await db
      .select()
      .from(chatMessages)
      .innerJoin(users, eq(chatMessages.userId, users.id))
      .orderBy(desc(chatMessages.createdAt));

    return result
      .filter(row => {
        const distance = this.calculateDistance(
          latitude,
          longitude,
          row.chat_messages.latitude,
          row.chat_messages.longitude
        );
        return distance <= radiusKm;
      })
      .map(row => ({
        ...row.chat_messages,
        user: row.users
      }));
  }

  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371;
    const dLat = this.toRad(lat2 - lat1);
    const dLon = this.toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private toRad(deg: number): number {
    return deg * (Math.PI / 180);
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const result = await db.insert(chatMessages).values(message).returning();
    return result[0];
  }

  async getAutomatedAccounts(type?: string, regionId?: string): Promise<User[]> {
    let query = db.select().from(users).where(
      sql`${users.accountType} != 'user'`
    );
    
    if (type) {
      query = db.select().from(users).where(
        and(
          sql`${users.accountType} = ${type}`,
          regionId ? sql`${users.regionId} = ${regionId}` : sql`1=1`
        )
      );
    } else if (regionId) {
      query = db.select().from(users).where(
        and(
          sql`${users.accountType} != 'user'`,
          sql`${users.regionId} = ${regionId}`
        )
      );
    }
    
    return await query;
  }

  // Hidden Accounts
  async hideAccount(userId: number, hiddenUserId: number): Promise<boolean> {
    const existing = await db.select().from(hiddenAccounts).where(
      and(
        eq(hiddenAccounts.userId, userId),
        eq(hiddenAccounts.hiddenUserId, hiddenUserId)
      )
    );
    
    if (existing.length > 0) {
      return false;
    }
    
    await db.insert(hiddenAccounts).values({ userId, hiddenUserId });
    return true;
  }

  async unhideAccount(userId: number, hiddenUserId: number): Promise<boolean> {
    const result = await db.delete(hiddenAccounts).where(
      and(
        eq(hiddenAccounts.userId, userId),
        eq(hiddenAccounts.hiddenUserId, hiddenUserId)
      )
    ).returning();
    
    return result.length > 0;
  }

  async isAccountHidden(userId: number, hiddenUserId: number): Promise<boolean> {
    const result = await db.select().from(hiddenAccounts).where(
      and(
        eq(hiddenAccounts.userId, userId),
        eq(hiddenAccounts.hiddenUserId, hiddenUserId)
      )
    );
    return result.length > 0;
  }

  async getHiddenAccounts(userId: number): Promise<User[]> {
    const result = await db
      .select({ user: users })
      .from(hiddenAccounts)
      .innerJoin(users, eq(hiddenAccounts.hiddenUserId, users.id))
      .where(eq(hiddenAccounts.userId, userId));
    
    return result.map(r => r.user);
  }

  // Password Reset
  async createPasswordResetCode(email: string): Promise<string> {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes
    
    await db.update(passwordResetCodes).set({ used: true }).where(
      and(eq(passwordResetCodes.email, email), eq(passwordResetCodes.used, false))
    );
    
    await db.insert(passwordResetCodes).values({
      email,
      code,
      expiresAt,
    });
    
    return code;
  }

  async verifyPasswordResetCode(email: string, code: string): Promise<boolean> {
    const result = await db.select().from(passwordResetCodes).where(
      and(
        eq(passwordResetCodes.email, email),
        eq(passwordResetCodes.code, code),
        eq(passwordResetCodes.used, false),
        sql`${passwordResetCodes.expiresAt} > NOW()`
      )
    );
    
    return result.length > 0;
  }

  async resetPassword(email: string, newPassword: string): Promise<boolean> {
    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(newPassword, saltRounds);
    
    const result = await db.update(users).set({ passwordHash }).where(eq(users.email, email)).returning();
    
    if (result.length > 0) {
      await db.update(passwordResetCodes).set({ used: true }).where(
        and(eq(passwordResetCodes.email, email), eq(passwordResetCodes.used, false))
      );
      return true;
    }
    
    return false;
  }

  // Admin Statistics
  async getAdminStats() {
    const [totalUsersResult] = await db.select({ count: sql<number>`count(*)` }).from(users);
    const [totalTweetsResult] = await db.select({ count: sql<number>`count(*)` }).from(tweets);
    const [totalQuestionsResult] = await db.select({ count: sql<number>`count(*)` }).from(questions);
    const [totalPlacesResult] = await db.select({ count: sql<number>`count(*)` }).from(places);

    const tweetsPerRegionResult = await db
      .select({
        regionId: tweets.locationId,
        count: sql<number>`count(*)`,
      })
      .from(tweets)
      .groupBy(tweets.locationId);

    const regionsData = await db.select().from(neighborhoods);
    const regionsMap = new Map(regionsData.map(r => [r.id, r.name]));

    const tweetsPerRegion = tweetsPerRegionResult.map(r => ({
      regionId: r.regionId || "unknown",
      regionName: regionsMap.get(r.regionId || "") || "غير محدد",
      count: Number(r.count),
    }));

    const usersPerDayResult = await db
      .select({
        date: sql<string>`DATE(${users.createdAt})`,
        count: sql<number>`count(*)`,
      })
      .from(users)
      .groupBy(sql`DATE(${users.createdAt})`)
      .orderBy(sql`DATE(${users.createdAt})`)
      .limit(30);

    const tweetsPerDayResult = await db
      .select({
        date: sql<string>`DATE(${tweets.createdAt})`,
        count: sql<number>`count(*)`,
      })
      .from(tweets)
      .groupBy(sql`DATE(${tweets.createdAt})`)
      .orderBy(sql`DATE(${tweets.createdAt})`)
      .limit(30);

    const recentUsersResult = await db
      .select({
        id: users.id,
        name: users.name,
        handle: users.handle,
        email: users.email,
        avatar: users.avatar,
        verified: users.verified,
        createdAt: users.createdAt,
      })
      .from(users)
      .orderBy(desc(users.createdAt))
      .limit(20);

    return {
      totalUsers: Number(totalUsersResult.count),
      totalTweets: Number(totalTweetsResult.count),
      totalQuestions: Number(totalQuestionsResult.count),
      totalPlaces: Number(totalPlacesResult.count),
      tweetsPerRegion,
      usersPerDay: usersPerDayResult.map(r => ({ date: String(r.date), count: Number(r.count) })),
      tweetsPerDay: tweetsPerDayResult.map(r => ({ date: String(r.date), count: Number(r.count) })),
      recentUsers: recentUsersResult.map(u => ({
        id: u.id,
        name: u.name,
        handle: u.handle,
        email: u.email,
        avatar: u.avatar,
        verified: u.verified,
        createdAt: u.createdAt?.toISOString() || new Date().toISOString(),
      })),
    };
  }
}

export const storage = new PostgresStorage();
