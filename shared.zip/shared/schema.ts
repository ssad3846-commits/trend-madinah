import { pgTable, text, serial, integer, timestamp, boolean, real, varchar, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Sessions table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  handle: text("handle").unique().notNull(),
  email: text("email").unique(),
  passwordHash: text("password_hash"),
  avatar: text("avatar").notNull(),
  cover: text("cover"),
  bio: text("bio"),
  location: text("location"),
  website: text("website"),
  twitter: text("twitter"),
  snapchat: text("snapchat"),
  tiktok: text("tiktok"),
  linkedin: text("linkedin"),
  verified: boolean("verified").default(false),
  following: integer("following").default(0),
  followers: integer("followers").default(0),
  accountType: text("account_type").default("user"), // user, news, university, prayer_times
  regionId: text("region_id").references(() => neighborhoods.id), // For automated accounts linked to a region
  isAdmin: boolean("is_admin").default(false),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  joinedAt: true,
  following: true,
  followers: true,
  passwordHash: true
});

export const registerUserSchema = z.object({
  name: z.string().min(2, "الاسم يجب أن يكون حرفين على الأقل"),
  handle: z.string().min(3, "اسم المستخدم يجب أن يكون 3 أحرف على الأقل").regex(/^[a-zA-Z0-9_]+$/, "اسم المستخدم يجب أن يحتوي على أحرف إنجليزية وأرقام فقط"),
  email: z.string().email("البريد الإلكتروني غير صالح"),
  password: z.string().min(6, "كلمة المرور يجب أن تكون 6 أحرف على الأقل"),
});

export const loginUserSchema = z.object({
  email: z.string().email("البريد الإلكتروني غير صالح"),
  password: z.string().min(1, "كلمة المرور مطلوبة"),
});

export const forgotPasswordSchema = z.object({
  email: z.string().email("البريد الإلكتروني غير صالح"),
});

export const resetPasswordSchema = z.object({
  email: z.string().email("البريد الإلكتروني غير صالح"),
  code: z.string().length(6, "رمز التحقق يجب أن يكون 6 أرقام"),
  newPassword: z.string().min(6, "كلمة المرور يجب أن تكون 6 أحرف على الأقل"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type RegisterUser = z.infer<typeof registerUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;
export type ForgotPassword = z.infer<typeof forgotPasswordSchema>;
export type ResetPassword = z.infer<typeof resetPasswordSchema>;

// Password reset codes table
export const passwordResetCodes = pgTable("password_reset_codes", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  code: text("code").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export type PasswordResetCode = typeof passwordResetCodes.$inferSelect;

// Neighborhoods table
export const neighborhoods = pgTable("neighborhoods", {
  id: text("id").primaryKey(),
  name: text("name").notNull()
});

export const insertNeighborhoodSchema = createInsertSchema(neighborhoods);
export type InsertNeighborhood = z.infer<typeof insertNeighborhoodSchema>;
export type Neighborhood = typeof neighborhoods.$inferSelect;

// Tweets table
export const tweets = pgTable("tweets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  image: text("image"),
  likes: integer("likes").default(0),
  replies: integer("replies").default(0),
  retweets: integer("retweets").default(0),
  locationId: text("location_id").references(() => neighborhoods.id),
  locationName: text("location_name"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertTweetSchema = createInsertSchema(tweets).omit({
  id: true,
  createdAt: true,
  likes: true,
  replies: true,
  retweets: true
});

export type InsertTweet = z.infer<typeof insertTweetSchema>;
export type Tweet = typeof tweets.$inferSelect;

// Questions table
export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  locationId: text("location_id").references(() => neighborhoods.id),
  locationName: text("location_name"),
  answersCount: integer("answers_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertQuestionSchema = createInsertSchema(questions).omit({
  id: true,
  createdAt: true,
  answersCount: true
});

export type InsertQuestion = z.infer<typeof insertQuestionSchema>;
export type Question = typeof questions.$inferSelect;

// Answers table
export const answers = pgTable("answers", {
  id: serial("id").primaryKey(),
  questionId: integer("question_id").notNull().references(() => questions.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertAnswerSchema = createInsertSchema(answers).omit({
  id: true,
  createdAt: true
});

export type InsertAnswer = z.infer<typeof insertAnswerSchema>;
export type Answer = typeof answers.$inferSelect;

// Places table (restaurants, cafes, hotels)
export const places = pgTable("places", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rating: real("rating").notNull(), // decimal rating like 4.8
  reviews: integer("reviews").default(0),
  cuisine: text("cuisine").notNull(),
  image: text("image").notNull(),
  locationId: text("location_id").references(() => neighborhoods.id),
  locationName: text("location_name"),
  priceRange: text("price_range").notNull(),
  googleMapsUrl: text("google_maps_url"),
  category: text("category").notNull(), // RESTAURANT, CAFE, HOTEL
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertPlaceSchema = createInsertSchema(places).omit({
  id: true,
  createdAt: true,
  reviews: true
});

export type InsertPlace = z.infer<typeof insertPlaceSchema>;
export type Place = typeof places.$inferSelect;

// Trends table
export const trends = pgTable("trends", {
  id: serial("id").primaryKey(),
  rank: integer("rank").notNull(),
  hashtag: text("hashtag").notNull(),
  posts: text("posts").notNull(), // Store as text like "٥٠.٢ ألف"
  category: text("category"),
  locationId: text("location_id").references(() => neighborhoods.id),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertTrendSchema = createInsertSchema(trends).omit({
  id: true,
  createdAt: true
});

export type InsertTrend = z.infer<typeof insertTrendSchema>;
export type Trend = typeof trends.$inferSelect;

// User Likes table - tracks which tweets a user has liked
export const userLikes = pgTable("user_likes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  tweetId: integer("tweet_id").notNull().references(() => tweets.id),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export type UserLike = typeof userLikes.$inferSelect;

// User Retweets table - tracks which tweets a user has retweeted
export const userRetweets = pgTable("user_retweets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  tweetId: integer("tweet_id").notNull().references(() => tweets.id),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export type UserRetweet = typeof userRetweets.$inferSelect;

// User Follows table - tracks who follows whom
export const userFollows = pgTable("user_follows", {
  id: serial("id").primaryKey(),
  followerId: integer("follower_id").notNull().references(() => users.id),
  followingId: integer("following_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export type UserFollow = typeof userFollows.$inferSelect;

// Tweet Replies table - stores replies to tweets
export const tweetReplies = pgTable("tweet_replies", {
  id: serial("id").primaryKey(),
  tweetId: integer("tweet_id").notNull().references(() => tweets.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertTweetReplySchema = createInsertSchema(tweetReplies).omit({
  id: true,
  createdAt: true
});

export type InsertTweetReply = z.infer<typeof insertTweetReplySchema>;
export type TweetReply = typeof tweetReplies.$inferSelect;

// Events table - neighborhood events and activities
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  image: text("image"),
  locationId: text("location_id").references(() => neighborhoods.id),
  locationName: text("location_name"),
  address: text("address"),
  eventDate: timestamp("event_date").notNull(),
  eventTime: text("event_time"),
  category: text("category").notNull(), // حفلة، ورشة عمل، رياضة، تعليم، ترفيه، دينية، إلخ
  organizer: text("organizer"),
  userId: integer("user_id").references(() => users.id),
  attendees: integer("attendees").default(0),
  interested: integer("interested").default(0),
  isApproved: boolean("is_approved").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  createdAt: true,
  attendees: true,
  interested: true,
  isApproved: true
});

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

// Event Attendees table - tracks who is attending/interested in events
export const eventAttendees = pgTable("event_attendees", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id),
  status: text("status").notNull(), // "attending" or "interested"
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export type EventAttendee = typeof eventAttendees.$inferSelect;

// Live Cameras table - stores live camera streams for Madinah
export const liveCameras = pgTable("live_cameras", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(), // مسجد، طرق، ساحات، عامة
  locationId: text("location_id").references(() => neighborhoods.id),
  locationName: text("location_name"),
  sourceType: text("source_type").notNull(), // youtube, iframe, hls
  embedUrl: text("embed_url").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  isOfficial: boolean("is_official").default(false),
  isLive: boolean("is_live").default(true),
  viewerCount: integer("viewer_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertLiveCameraSchema = createInsertSchema(liveCameras).omit({
  id: true,
  createdAt: true,
  viewerCount: true
});

export type InsertLiveCamera = z.infer<typeof insertLiveCameraSchema>;
export type LiveCamera = typeof liveCameras.$inferSelect;

// Local Chat Messages table - location-based chat within 10km radius
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true
});

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

// Hidden Accounts table - allows users to hide accounts from their feed
export const hiddenAccounts = pgTable("hidden_accounts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  hiddenUserId: integer("hidden_user_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export type HiddenAccount = typeof hiddenAccounts.$inferSelect;
