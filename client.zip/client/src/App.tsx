import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { LocationProvider } from "@/lib/location-context";
import { AuthProvider } from "@/lib/auth-context";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import CamerasPage from "@/pages/cameras";
import RestaurantsPage from "@/pages/restaurants";
import QuestionsPage from "@/pages/questions";
import EventsPage from "@/pages/events";
import AuthPage from "@/pages/auth";
import ProfilePage from "@/pages/profile";
import UserProfilePage from "@/pages/user-profile";
import TweetDetailPage from "@/pages/tweet-detail";
import LocationPage from "@/pages/location";
import ViralPage from "@/pages/viral";
import ChatPage from "@/pages/chat";
import RadioPage from "@/pages/radio";
import AdminPage from "@/pages/admin";
import DownloadPage from "@/pages/download";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/download" component={DownloadPage} />
      <Route path="/cameras" component={CamerasPage} />
      <Route path="/explore" component={CamerasPage} /> 
      <Route path="/restaurants" component={RestaurantsPage} />
      <Route path="/questions" component={QuestionsPage} />
      <Route path="/events" component={EventsPage} />
      <Route path="/viral" component={ViralPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/login" component={AuthPage} />
      <Route path="/signup" component={AuthPage} />
      <Route path="/user/:handle" component={UserProfilePage} />
      <Route path="/tweet/:id" component={TweetDetailPage} />
      <Route path="/location/:id" component={LocationPage} />
      <Route path="/chat" component={ChatPage} />
      <Route path="/radio" component={RadioPage} />
      <Route path="/profile" component={ProfilePage} />
      <Route path="/admin" component={AdminPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <LocationProvider>
            <Toaster />
            <Router />
          </LocationProvider>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
