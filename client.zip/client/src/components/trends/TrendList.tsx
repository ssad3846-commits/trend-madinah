import { createPortal } from "react-dom";
import { useEffect, useState } from "react";
import { trendsApi } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { useLocationContext } from "@/lib/location-context";
import { Loader2 } from "lucide-react";
import { useLocation } from "wouter";

export default function TrendList() {
  const [mounted, setMounted] = useState(false);
  const [container, setContainer] = useState<HTMLElement | null>(null);
  const [activeTab, setActiveTab] = useState<"twitter" | "local">("twitter");
  const { selectedLocation, locationId } = useLocationContext();
  const [, setLocationPath] = useLocation();

  const { data: localTrends = [], isLoading: localLoading } = useQuery({
    queryKey: ['trends', selectedLocation?.id],
    queryFn: () => trendsApi.getTrends(selectedLocation?.id, 10),
  });

  const { data: twitterTrends = [], isLoading: twitterLoading } = useQuery({
    queryKey: ['twitter-trends'],
    queryFn: () => trendsApi.getTwitterTrends(),
    staleTime: 5 * 60 * 1000,
    refetchInterval: 5 * 60 * 1000,
  });

  useEffect(() => {
    setMounted(true);
    setContainer(document.getElementById('sidebar-trends-portal'));
  }, []);

  const regionName = selectedLocation?.name || "المملكة العربية السعودية";

  const renderTrends = (trends: typeof localTrends, loading: boolean, isTwitter: boolean = false) => (
    <div className="space-y-3">
      {loading ? (
        <div className="flex justify-center py-4">
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
        </div>
      ) : trends.length > 0 ? (
        trends.slice(0, 10).map((trend) => (
          <div 
            key={trend.id} 
            className="flex flex-col cursor-pointer hover:bg-background/50 p-2 -mx-2 rounded-lg transition-colors"
            data-testid={`trend-item-${trend.id}`}
            onClick={() => {
              const locationParam = locationId && locationId !== 'all' ? `&locationId=${locationId}` : '';
              setLocationPath(`/explore?q=${encodeURIComponent(trend.hashtag)}${locationParam}`);
            }}
          >
            <div className="flex justify-between items-center text-xs text-muted-foreground">
              <span>{trend.rank}. {isTwitter ? "السعودية" : regionName} · متداول</span>
            </div>
            <span className="font-bold text-foreground dir-ltr text-right mt-0.5">{trend.hashtag}</span>
            <span className="text-xs text-muted-foreground mt-0.5">{trend.posts} تغريدة</span>
          </div>
        ))
      ) : (
        <div className="text-center text-muted-foreground py-4 text-sm">
          {isTwitter ? "تعذر جلب الترندات" : "لا توجد ترندات حالياً"}
        </div>
      )}
    </div>
  );

  const content = (
    <div className="space-y-3">
      <div className="flex bg-muted rounded-lg p-1 gap-1">
        <button
          onClick={() => setActiveTab("twitter")}
          className={`flex-1 py-1.5 px-3 rounded-md text-sm font-medium transition-colors ${
            activeTab === "twitter" 
              ? "bg-background text-foreground shadow-sm" 
              : "text-muted-foreground hover:text-foreground"
          }`}
          data-testid="tab-twitter-trends"
        >
          𝕏 تويتر
        </button>
        <button
          onClick={() => setActiveTab("local")}
          className={`flex-1 py-1.5 px-3 rounded-md text-sm font-medium transition-colors ${
            activeTab === "local" 
              ? "bg-background text-foreground shadow-sm" 
              : "text-muted-foreground hover:text-foreground"
          }`}
          data-testid="tab-local-trends"
        >
          {regionName}
        </button>
      </div>
      
      {activeTab === "twitter" 
        ? renderTrends(twitterTrends, twitterLoading, true)
        : renderTrends(localTrends, localLoading, false)
      }
    </div>
  );

  if (mounted && container) {
    return createPortal(content, container);
  }

  return null; 
}
