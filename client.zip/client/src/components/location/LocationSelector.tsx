import { useState } from "react";
import { Check, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useLocationContext } from "@/lib/location-context";

export default function LocationSelector() {
  const [open, setOpen] = useState(false);
  const { locationId, setLocationId, selectedLocation, neighborhoods } = useLocationContext();

  const selectedNeighborhood = selectedLocation?.name || "المملكة العربية السعودية";

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          role="combobox"
          aria-expanded={open}
          className="justify-between font-bold text-lg hover:bg-transparent hover:text-primary p-0 gap-1"
          data-testid="button-location-selector"
        >
            <div className="flex flex-col items-start">
                <span className="text-xs font-normal text-muted-foreground">الموقع الحالي</span>
                <div className="flex items-center gap-1">
                    <span>{selectedNeighborhood}</span>
                    <ChevronDown className="opacity-50 h-4 w-4" />
                </div>
            </div>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[200px] p-0" align="start">
        <Command dir="rtl">
          <CommandInput placeholder="ابحث عن مدينة..." />
          <CommandList>
            <CommandEmpty>لا توجد مدينة بهذا الاسم.</CommandEmpty>
            <CommandGroup>
              {neighborhoods.map((neighborhood) => (
                <CommandItem
                  key={neighborhood.id}
                  value={`${neighborhood.id}-${neighborhood.name}`}
                  onSelect={() => {
                    setLocationId(neighborhood.id);
                    setOpen(false);
                  }}
                  className="cursor-pointer"
                  data-testid={`item-neighborhood-${neighborhood.id}`}
                >
                  <Check
                    className={cn(
                      "ml-2 h-4 w-4",
                      locationId === neighborhood.id ? "opacity-100" : "opacity-0"
                    )}
                  />
                  {neighborhood.name}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
