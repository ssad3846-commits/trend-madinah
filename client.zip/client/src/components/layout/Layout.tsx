import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Home, Video, Bell, Utensils, User, Menu, HelpCircle, Flame, LogIn, LogOut, Feather, X, MapPin, Loader2, ShoppingBag, Calendar, Settings, UserCircle, ChevronLeft, Search, MessageCircle, Radio } from "lucide-react";
import RadioIcon from "@/components/icons/RadioIcon";
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/lib/auth-context";
import { useLocationContext } from "@/lib/location-context";
import { tweetsApi, neighborhoodsApi } from "@/lib/api";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import logo from "@assets/generated_images/minimalist_islamic_geometric_logo_green_and_gold.png";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location, setLocation] = useLocation();
  const { user, isAuthenticated, isLoading, logout } = useAuth();
  const { selectedLocation: currentNeighborhood } = useLocationContext();
  const [composeOpen, setComposeOpen] = useState(false);
  const [tweetContent, setTweetContent] = useState("");
  const [selectedLocation, setSelectedLocation] = useState<string>("");
  const [userSheetOpen, setUserSheetOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const getHarajUrl = () => {
    const baseUrl = "https://haraj.com.sa";
    if (currentNeighborhood && currentNeighborhood.id !== "all") {
      return `${baseUrl}/search/المدينة المنورة ${currentNeighborhood.name}`;
    }
    return `${baseUrl}/search/المدينة المنورة`;
  };

  const { data: neighborhoods = [] } = useQuery({
    queryKey: ["neighborhoods"],
    queryFn: neighborhoodsApi.getNeighborhoods,
  });

  const createTweetMutation = useMutation({
    mutationFn: tweetsApi.createTweet,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tweets"] });
      setTweetContent("");
      setSelectedLocation("");
      setComposeOpen(false);
      toast({
        title: "تم النشر",
        description: "تم نشر تغريدتك بنجاح",
      });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error instanceof Error ? error.message : "فشل في نشر التغريدة",
        variant: "destructive",
      });
    },
  });

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const handleCompose = () => {
    if (!isAuthenticated) {
      setLocation("/auth");
      return;
    }
    setComposeOpen(true);
  };

  const handleSubmitTweet = () => {
    if (!tweetContent.trim()) return;
    
    const selectedNeighborhood = neighborhoods.find(n => n.id === selectedLocation);
    
    createTweetMutation.mutate({
      content: tweetContent,
      locationId: selectedLocation || undefined,
      locationName: selectedNeighborhood?.name || undefined,
    });
  };

  return (
    <div className="min-h-screen bg-background font-sans text-right" dir="rtl">
      <div className="container mx-auto max-w-7xl flex">
        
        {/* Right Sidebar (Navigation) - Desktop */}
        <aside className="hidden md:flex flex-col w-[275px] h-screen sticky top-0 p-4 border-l border-border/40">
          <div className="mb-8 px-4">
            <Link href="/">
              <div className="flex items-center gap-3 cursor-pointer">
                <img src={logo} alt="Logo" className="w-10 h-10 rounded-full" />
                <h1 className="text-xl font-bold text-primary tracking-wide">ترند المدينة</h1>
              </div>
            </Link>
          </div>

          <nav className="flex-1 space-y-2">
            <NavItem href="/" icon={<Home size={26} />} label="الرئيسية" active={location === "/"} />
            <NavItem href="/cameras" icon={<Video size={26} />} label="كاميرات" active={location === "/cameras" || location === "/explore"} />
            <NavItem href="/questions" icon={<HelpCircle size={26} />} label="أسئلة" active={location === "/questions"} />
            <NavItem href="/viral" icon={<Flame size={26} />} label="المتداول" active={location === "/viral"} />
            <NavItem href="/chat" icon={<MessageCircle size={26} />} label="دردشة القريبين" active={location === "/chat"} />
            <NavItem href="/restaurants" icon={<Utensils size={26} />} label="مطاعم" active={location === "/restaurants"} />
            {isAuthenticated && (
              <NavItem href="/profile" icon={<User size={26} />} label="الملف الشخصي" active={location === "/profile"} />
            )}
            <Button 
              className="w-full mt-8 bg-primary hover:bg-primary/90 text-white rounded-full h-12 text-lg font-bold shadow-lg hover:shadow-xl transition-all" 
              data-testid="button-compose-tweet"
              onClick={handleCompose}
            >
              غرد
            </Button>
          </nav>

          {isAuthenticated && user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <div className="mt-auto px-4 py-4 flex items-center gap-3 hover:bg-muted/50 p-2 rounded-full cursor-pointer transition-colors" data-testid="button-user-menu">
                  <img 
                    src={user.avatar} 
                    className="w-10 h-10 rounded-full border border-border object-cover"
                    alt={user.name}
                  />
                  <div className="flex-1 overflow-hidden">
                    <p className="font-bold text-sm truncate">{user.name}</p>
                    <p className="text-muted-foreground text-xs truncate">@{user.handle}</p>
                  </div>
                </div>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem asChild>
                  <Link href="/profile" className="flex items-center gap-2 cursor-pointer">
                    <User size={16} />
                    الملف الشخصي
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-600 cursor-pointer" data-testid="button-logout">
                  <LogOut size={16} className="ml-2" />
                  تسجيل الخروج
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Link href="/auth">
              <div className="mt-auto px-4 py-4 flex items-center gap-3 hover:bg-muted/50 p-2 rounded-full cursor-pointer transition-colors border border-dashed border-primary/30">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <LogIn size={20} className="text-primary" />
                </div>
                <div className="flex-1 overflow-hidden">
                  <p className="font-bold text-sm truncate text-primary">سجل دخولك</p>
                  <p className="text-muted-foreground text-xs truncate">أو أنشئ حساب جديد</p>
                </div>
              </div>
            </Link>
          )}
        </aside>

        {/* Main Content */}
        <main className="flex-1 min-w-0 border-l border-border/40 md:border-l-0 pb-20 md:pb-0">
          {/* Mobile Top Header */}
          <div className="md:hidden sticky top-0 z-20 bg-background/80 backdrop-blur-md border-b border-border/40 px-4 py-2 flex items-center justify-start gap-3">
            {isAuthenticated && user ? (
              <div 
                onClick={() => setUserSheetOpen(true)}
                className="p-1 rounded-full cursor-pointer"
                data-testid="button-user-header"
              >
                <img 
                  src={user.avatar} 
                  alt={user.name}
                  className="w-9 h-9 rounded-full object-cover border-2 border-primary/30"
                />
              </div>
            ) : (
              <Link href="/auth">
                <div className="p-2 rounded-full bg-primary/10">
                  <LogIn size={20} className="text-primary" />
                </div>
              </Link>
            )}
            
            {currentNeighborhood && (
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <MapPin size={14} className="text-primary" />
                <span>{currentNeighborhood.name}</span>
              </div>
            )}
          </div>
          
          {children}
        </main>

        {/* Left Sidebar (Trends) - Desktop */}
        <aside className="hidden lg:block w-[350px] h-screen sticky top-0 p-4 border-r border-border/40">
             {/* Search */}
             <div className="mb-6 relative">
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-muted-foreground">
                  <Search size={18} />
                </div>
                <input 
                  type="text" 
                  placeholder="بحث في ترند المدينة" 
                  className="w-full bg-muted/50 rounded-full py-3 pr-10 pl-4 focus:outline-none focus:ring-2 focus:ring-primary/20 border-none transition-all"
                />
             </div>
             
             {/* This will be populated by the TrendList component passed as children or specific component */}
             <div className="bg-muted/30 rounded-2xl p-4 min-h-[300px]">
                <h2 className="font-bold text-xl mb-4 px-2">ماذا يحدث في المدينة؟</h2>
                 {/* Placeholder for trends sidebar content if not passed via children */}
                 <div id="sidebar-trends-portal"></div>
             </div>
        </aside>
      </div>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-background/80 backdrop-blur-md border-t border-border flex justify-around items-center h-16 z-50 px-2">
        <Link href="/">
          <MobileNavItem icon={<Home size={24} />} active={location === "/"} />
        </Link>
        <Link href="/viral">
          <MobileNavItem icon={<Flame size={24} />} active={location === "/viral"} />
        </Link>
        <Link href="/questions">
          <MobileNavItem icon={<HelpCircle size={24} />} active={location === "/questions"} />
        </Link>
        <Link href="/cameras">
          <MobileNavItem icon={<Video size={24} />} active={location === "/cameras" || location === "/explore"} />
        </Link>
        <Link href="/radio">
          <MobileNavItem icon={<RadioIcon size={24} />} active={location === "/radio"} />
        </Link>
      </nav>

      {/* Floating Action Button for Mobile */}
      <button
        onClick={handleCompose}
        className="md:hidden fixed bottom-20 left-4 w-14 h-14 bg-primary hover:bg-primary/90 text-white rounded-full shadow-lg hover:shadow-xl transition-all flex items-center justify-center z-50"
        data-testid="button-compose-fab"
      >
        <Feather size={24} />
      </button>

      {/* Compose Tweet Dialog */}
      <Dialog open={composeOpen} onOpenChange={setComposeOpen}>
        <DialogContent className="sm:max-w-[500px]" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-right flex items-center justify-between">
              <span>تغريدة جديدة</span>
              <Button
                variant="ghost"
                size="icon"
                className="rounded-full"
                onClick={() => setComposeOpen(false)}
              >
                <X size={20} />
              </Button>
            </DialogTitle>
          </DialogHeader>
          
          <div className="mt-4">
            <div className="flex gap-3">
              {user && (
                <img 
                  src={user.avatar} 
                  alt={user.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
              )}
              <div className="flex-1">
                <Textarea
                  value={tweetContent}
                  onChange={(e) => setTweetContent(e.target.value)}
                  placeholder="ماذا يحدث في المدينة؟"
                  className="min-h-[120px] text-lg border-none resize-none focus-visible:ring-0 p-0"
                  data-testid="input-tweet-content"
                />
              </div>
            </div>

            <div className="border-t border-border/40 pt-4 mt-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapPin size={18} className="text-primary" />
                  <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                    <SelectTrigger className="w-[180px] border-none bg-muted/30 h-9" data-testid="select-tweet-location">
                      <SelectValue placeholder="اختر الحي" />
                    </SelectTrigger>
                    <SelectContent>
                      {neighborhoods.filter(n => n.id !== "all").map((neighborhood) => (
                        <SelectItem key={neighborhood.id} value={neighborhood.id}>
                          {neighborhood.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <Button 
                  onClick={handleSubmitTweet}
                  disabled={!tweetContent.trim() || createTweetMutation.isPending}
                  className="rounded-full px-6"
                  data-testid="button-submit-tweet"
                >
                  {createTweetMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    "غرد"
                  )}
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* User Side Sheet */}
      <Sheet open={userSheetOpen} onOpenChange={setUserSheetOpen}>
        <SheetContent side="right" className="w-[300px] p-0" dir="rtl">
          <div className="flex flex-col h-full">
            {/* User Header */}
            {user && (
              <div className="p-6 border-b border-border/40 bg-muted/30">
                <div className="flex items-center gap-4">
                  <img 
                    src={user.avatar} 
                    alt={user.name}
                    className="w-16 h-16 rounded-full object-cover border-2 border-primary"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-lg truncate">{user.name}</p>
                    <p className="text-muted-foreground text-sm">@{user.handle}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Menu Items */}
            <div className="flex-1 py-4">
              <button
                onClick={() => {
                  setUserSheetOpen(false);
                  setLocation("/profile");
                }}
                className="w-full flex items-center gap-4 px-6 py-4 hover:bg-muted/50 transition-colors text-right"
                data-testid="button-sheet-profile"
              >
                <UserCircle size={24} className="text-primary" />
                <span className="text-lg">الملف الشخصي</span>
                <ChevronLeft size={20} className="mr-auto text-muted-foreground" />
              </button>

              <button
                onClick={() => {
                  setUserSheetOpen(false);
                  setLocation("/chat");
                }}
                className="w-full flex items-center gap-4 px-6 py-4 hover:bg-muted/50 transition-colors text-right"
                data-testid="button-sheet-chat"
              >
                <MessageCircle size={24} className="text-primary" />
                <span className="text-lg">دردشة القريبين</span>
                <ChevronLeft size={20} className="mr-auto text-muted-foreground" />
              </button>

              <button
                onClick={() => {
                  setUserSheetOpen(false);
                  setLocation("/radio");
                }}
                className="w-full flex items-center gap-4 px-6 py-4 hover:bg-muted/50 transition-colors text-right"
                data-testid="button-sheet-radio"
              >
                <RadioIcon size={24} className="text-primary" />
                <span className="text-lg">إذاعات السعودية</span>
                <ChevronLeft size={20} className="mr-auto text-muted-foreground" />
              </button>

              <button
                onClick={() => {
                  setUserSheetOpen(false);
                  toast({
                    title: "الإعدادات",
                    description: "صفحة الإعدادات قيد التطوير",
                  });
                }}
                className="w-full flex items-center gap-4 px-6 py-4 hover:bg-muted/50 transition-colors text-right"
                data-testid="button-sheet-settings"
              >
                <Settings size={24} className="text-primary" />
                <span className="text-lg">الإعدادات</span>
                <ChevronLeft size={20} className="mr-auto text-muted-foreground" />
              </button>
            </div>

            {/* Logout Button */}
            <div className="p-4 border-t border-border/40">
              <Button
                variant="destructive"
                className="w-full h-12 text-lg font-bold rounded-full"
                onClick={() => {
                  setUserSheetOpen(false);
                  handleLogout();
                }}
                data-testid="button-sheet-logout"
              >
                <LogOut size={20} className="ml-2" />
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}

function NavItem({ icon, label, active, href }: { icon: React.ReactNode, label: string, active?: boolean, href: string }) {
  return (
    <Link href={href}>
      <div className={`flex items-center gap-4 px-4 py-3 rounded-full cursor-pointer transition-all duration-200 group ${active ? 'font-bold' : 'hover:bg-muted/50'}`}>
        <div className={`${active ? 'text-primary' : 'text-foreground group-hover:text-primary transition-colors'}`}>
          {icon}
        </div>
        <span className={`text-xl ${active ? 'text-primary' : 'text-foreground group-hover:text-primary transition-colors'}`}>{label}</span>
      </div>
    </Link>
  );
}

function MobileNavItem({ icon, active }: { icon: React.ReactNode, active?: boolean }) {
  return (
    <div className={`p-3 rounded-full cursor-pointer ${active ? 'text-primary bg-primary/10' : 'text-muted-foreground'}`}>
      {icon}
    </div>
  );
}
