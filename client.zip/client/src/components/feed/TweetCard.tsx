import { useState, useEffect } from "react";
import { Heart, MessageCircle, Repeat, Share, MapPin, UserPlus, UserMinus, EyeOff, MoreHorizontal } from "lucide-react";
import { Tweet } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Link, useLocation } from "wouter";
import { usersApi, tweetsApi } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";
import { useLocationContext } from "@/lib/location-context";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface TweetCardProps {
  tweet: Tweet;
}

export default function TweetCard({ tweet }: TweetCardProps) {
  const userHandle = tweet.user.handle.replace('@', '');
  const tweetUserId = parseInt(tweet.user.id);
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const { locationId } = useLocationContext();
  const [localLikes, setLocalLikes] = useState(tweet.likes);
  const [localRetweets, setLocalRetweets] = useState(tweet.retweets);
  const [isLiked, setIsLiked] = useState(false);
  const [isRetweeted, setIsRetweeted] = useState(false);

  const isOwnTweet = user?.id === tweetUserId;

  const handleTweetClick = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (target.tagName === 'BUTTON' || target.closest('button') || target.tagName === 'A' || target.closest('a')) {
      return;
    }
    setLocation(`/tweet/${tweet.id}`);
  };

  const { data: isFollowing = false } = useQuery({
    queryKey: ["isFollowing", tweetUserId],
    queryFn: () => usersApi.isFollowing(tweetUserId),
    enabled: isAuthenticated && !isOwnTweet,
  });

  const followMutation = useMutation({
    mutationFn: () => usersApi.followUser(tweetUserId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["isFollowing", tweetUserId] });
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const likeMutation = useMutation({
    mutationFn: () => tweetsApi.likeTweet(parseInt(tweet.id)),
    onSuccess: (data) => {
      setIsLiked(data.liked);
      setLocalLikes(data.tweet.likes);
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const retweetMutation = useMutation({
    mutationFn: () => tweetsApi.retweetTweet(parseInt(tweet.id)),
    onSuccess: (data) => {
      setIsRetweeted(data.retweeted);
      setLocalRetweets(data.tweet.retweets);
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const hideMutation = useMutation({
    mutationFn: () => usersApi.hideAccount(tweetUserId),
    onSuccess: (data) => {
      toast({
        title: data.hidden ? "تم إخفاء الحساب" : "تم إظهار الحساب",
        description: data.hidden ? "لن تظهر تغريدات هذا الحساب في صفحتك الرئيسية" : "ستظهر تغريدات هذا الحساب مجدداً",
      });
      queryClient.invalidateQueries({ queryKey: ["tweets"] });
      queryClient.invalidateQueries({ queryKey: ["hiddenAccounts"] });
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleShare = async () => {
    try {
      await navigator.share({
        title: `تغريدة من ${tweet.user.name}`,
        text: tweet.content,
        url: window.location.href,
      });
    } catch {
      await navigator.clipboard.writeText(tweet.content);
      toast({
        title: "تم النسخ",
        description: "تم نسخ التغريدة إلى الحافظة",
      });
    }
  };
  
  return (
    <div 
      className="p-4 border-b border-border/40 hover:bg-muted/5 transition-colors animate-in fade-in slide-in-from-bottom-4 duration-500 cursor-pointer"
      onClick={handleTweetClick}
      data-testid={`tweet-card-${tweet.id}`}
    >
      <div className="flex gap-3">
        <div className="flex-shrink-0">
          <Link href={`/user/${userHandle}`} data-testid={`link-avatar-${userHandle}`}>
            <img 
              src={tweet.user.avatar} 
              alt={tweet.user.name} 
              className="w-10 h-10 rounded-full object-cover border border-border cursor-pointer hover:opacity-80 transition-opacity"
            />
          </Link>
        </div>
        
        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1 flex-wrap">
              <Link href={`/user/${userHandle}`} data-testid={`link-name-${userHandle}`}>
                <span className="font-bold text-foreground hover:underline cursor-pointer">{tweet.user.name}</span>
              </Link>
              {tweet.user.verified && (
                <span className="text-primary" title="Verified">
                  <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4"><g><path d="M22.5 12.5c0-1.58-.875-2.95-2.148-3.6.154-.435.238-.905.238-1.4 0-2.21-1.71-3.998-3.818-3.998-.47 0-.92.084-1.336.25C14.818 2.415 13.51 1.5 12 1.5s-2.816.917-3.437 2.25c-.415-.165-.866-.25-1.336-.25-2.11 0-3.818 1.79-3.818 4 0 .495.083.965.238 1.4-1.272.65-2.147 2.018-2.147 3.6 0 1.495.782 2.798 1.942 3.486-.02.17-.032.34-.032.514 0 2.21 1.708 4 3.818 4 .47 0 .92-.086 1.335-.25.62 1.334 1.926 2.25 3.437 2.25 1.512 0 2.818-.916 3.437-2.25.415.163.865.248 1.336.248 2.11 0 3.818-1.79 3.818-4 0-.174-.012-.344-.033-.513 1.158-.687 1.943-1.99 1.943-3.484zm-6.616-3.334l-4.334 6.5c-.145.217-.382.334-.625.334-.143 0-.288-.04-.416-.126l-.115-.094-2.415-2.415c-.293-.293-.293-.768 0-1.06s.768-.294 1.06 0l1.77 1.767 3.825-5.74c.23-.345.696-.436 1.04-.207.346.23.44.696.21 1.04z"></path></g></svg>
                </span>
              )}
              <Link href={`/user/${userHandle}`} data-testid={`link-handle-${userHandle}`}>
                <span className="text-muted-foreground dir-ltr text-sm hover:underline cursor-pointer">{tweet.user.handle}</span>
              </Link>
              <span className="text-muted-foreground text-sm">·</span>
              <span className="text-muted-foreground text-sm hover:underline cursor-pointer">{tweet.timestamp}</span>
            </div>
            
            {/* Follow Button and More Options */}
            {isAuthenticated && !isOwnTweet && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => followMutation.mutate()}
                  disabled={followMutation.isPending}
                  className={cn(
                    "flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold transition-all",
                    isFollowing
                      ? "bg-transparent border border-border hover:border-red-500 hover:text-red-500 text-foreground"
                      : "bg-foreground text-background hover:bg-foreground/90"
                  )}
                  data-testid={`button-follow-${userHandle}`}
                >
                  {isFollowing ? (
                    <>
                      <UserMinus size={14} />
                      <span>إلغاء المتابعة</span>
                    </>
                  ) : (
                    <>
                      <UserPlus size={14} />
                      <span>متابعة</span>
                    </>
                  )}
                </button>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button
                      className="p-1 rounded-full hover:bg-muted/50 transition-colors"
                      data-testid={`button-more-${tweet.id}`}
                    >
                      <MoreHorizontal size={16} className="text-muted-foreground" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="min-w-[160px]">
                    <DropdownMenuItem
                      onClick={() => hideMutation.mutate()}
                      disabled={hideMutation.isPending}
                      className="text-red-500 focus:text-red-500"
                      data-testid={`button-hide-${userHandle}`}
                    >
                      <EyeOff size={16} className="ml-2" />
                      إخفاء الحساب
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            )}
          </div>

          {/* Location Tag */}
          {tweet.location && (
            <div 
              className="flex items-center text-primary text-xs mt-0.5 mb-1 cursor-pointer hover:underline"
              onClick={(e) => {
                e.stopPropagation();
                setLocation(`/location/${tweet.locationId}`);
              }}
              data-testid={`location-tag-${tweet.locationId}`}
            >
              <MapPin size={12} className="ml-1" />
              <span>{tweet.location}</span>
            </div>
          )}

          {/* Content */}
          <p className="text-base mt-1 whitespace-pre-wrap leading-normal font-normal">
            {tweet.content.split(' ').map((word, i) => 
              word.startsWith('#') ? (
                <span 
                  key={i} 
                  className="text-primary cursor-pointer hover:underline"
                  onClick={(e) => {
                    e.stopPropagation();
                    const locationParam = locationId && locationId !== 'all' ? `&locationId=${locationId}` : '';
                    setLocation(`/explore?q=${encodeURIComponent(word)}${locationParam}`);
                  }}
                >{word} </span>
              ) : word + ' '
            )}
          </p>

          {/* Image */}
          {tweet.image && (
            <div className="mt-3 rounded-2xl overflow-hidden border border-border/60 shadow-sm">
              <img src={tweet.image} alt="Tweet attachment" className="w-full h-auto max-h-[500px] object-cover" />
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-between mt-3 text-muted-foreground max-w-md">
            <ActionButton icon={<MessageCircle size={18} />} count={tweet.replies} color="blue" />
            <button
              onClick={() => {
                if (!isAuthenticated) {
                  setLocation("/auth");
                  return;
                }
                retweetMutation.mutate();
              }}
              disabled={retweetMutation.isPending}
              className={cn(
                "flex items-center gap-1 group cursor-pointer transition-all",
                isRetweeted && "text-green-500"
              )}
            >
              <div className={cn(
                "p-2 rounded-full transition-colors -mr-2",
                isRetweeted ? "bg-green-500/10" : "group-hover:bg-green-500/10 group-hover:text-green-500"
              )}>
                <Repeat size={18} />
              </div>
              <span className={cn(
                "text-xs transition-colors pr-2",
                isRetweeted ? "text-green-500" : "group-hover:text-green-500"
              )}>{localRetweets}</span>
            </button>
            <button
              onClick={() => {
                if (!isAuthenticated) {
                  setLocation("/auth");
                  return;
                }
                likeMutation.mutate();
              }}
              disabled={likeMutation.isPending}
              className={cn(
                "flex items-center gap-1 group cursor-pointer transition-all",
                isLiked && "text-pink-500"
              )}
            >
              <div className={cn(
                "p-2 rounded-full transition-colors -mr-2",
                isLiked ? "bg-pink-500/10" : "group-hover:bg-pink-500/10 group-hover:text-pink-500"
              )}>
                <Heart size={18} className={isLiked ? "fill-pink-500" : ""} />
              </div>
              <span className={cn(
                "text-xs transition-colors pr-2",
                isLiked ? "text-pink-500" : "group-hover:text-pink-500"
              )}>{localLikes}</span>
            </button>
            <button
              onClick={handleShare}
              className="flex items-center group cursor-pointer p-2 -ml-2 rounded-full hover:bg-primary/10 hover:text-primary transition-all"
            >
              <Share size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ActionButton({ icon, count, color }: { icon: React.ReactNode, count: number, color: string }) {
  const colorClasses = {
    blue: "group-hover:text-blue-500 group-hover:bg-blue-500/10",
    green: "group-hover:text-green-500 group-hover:bg-green-500/10",
    pink: "group-hover:text-pink-500 group-hover:bg-pink-500/10",
  };

  return (
    <div className={`flex items-center gap-1 group cursor-pointer transition-all`}>
      <div className={`p-2 rounded-full transition-colors ${colorClasses[color as keyof typeof colorClasses]} -mr-2`}>
        {icon}
      </div>
      <span className={`text-xs group-hover:text-${color}-500 transition-colors pr-2`}>{count}</span>
    </div>
  );
}
