import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Image, MapPin, Smile, Calendar } from "lucide-react";

export default function ComposeTweet() {
  const [content, setContent] = useState("");

  return (
    <div className="p-4 border-b border-border/40 bg-background">
      <div className="flex gap-3">
        <div className="flex-shrink-0">
           <img 
              src="https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100&h=100&fit=crop" 
              className="w-10 h-10 rounded-full object-cover"
              alt="User"
            />
        </div>
        <div className="flex-1">
          <textarea
            className="w-full bg-transparent text-lg placeholder:text-muted-foreground/70 border-none focus:ring-0 resize-none min-h-[80px] p-2"
            placeholder="ماذا يحدث في المدينة؟"
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
          <div className="border-t border-border/30 pt-3 flex items-center justify-between">
             <div className="flex items-center gap-1 text-primary">
                <IconButton icon={<Image size={20} />} />
                <IconButton icon={<MapPin size={20} />} />
                <IconButton icon={<Smile size={20} />} />
                <IconButton icon={<Calendar size={20} />} />
             </div>
             <Button 
                className="rounded-full px-6 font-bold bg-primary hover:bg-primary/90 text-white"
                disabled={!content.trim()}
             >
               غرد
             </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

function IconButton({ icon }: { icon: React.ReactNode }) {
  return (
    <div className="p-2 rounded-full hover:bg-primary/10 cursor-pointer transition-colors">
      {icon}
    </div>
  );
}
