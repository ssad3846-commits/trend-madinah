import { NEIGHBORHOODS } from "@/lib/dummy-data";
import { motion } from "framer-motion";
import { MapPin, Users } from "lucide-react";

export default function InteractiveMap() {
  // This is a stylized abstraction of Madinah map inspired by Snap Map
  // Features: Dark/Satellite-ish theme, glowing heatmaps, avatar clusters
  
  return (
    <div className="relative w-full h-[calc(100vh-200px)] bg-[#1a1d21] overflow-hidden rounded-xl border border-border shadow-2xl m-4 group select-none">
      
      {/* Map Base Layer - Dark Theme */}
      <div className="absolute inset-0 opacity-30" 
           style={{ 
             backgroundImage: "linear-gradient(#333 1px, transparent 1px), linear-gradient(90deg, #333 1px, transparent 1px)", 
             backgroundSize: "40px 40px" 
           }}>
      </div>

      {/* Heatmap Glows - Simulated with radial gradients */}
      <div className="absolute inset-0 pointer-events-none mix-blend-screen">
          {/* Intense Heat (Red/Orange) - Aziziyah */}
          <div className="absolute top-[50%] left-[20%] w-64 h-64 bg-red-500/20 rounded-full blur-[60px] transform -translate-x-1/2 -translate-y-1/2 animate-pulse"></div>
          <div className="absolute top-[50%] left-[20%] w-32 h-32 bg-orange-500/30 rounded-full blur-[40px] transform -translate-x-1/2 -translate-y-1/2"></div>
          
          {/* Moderate Heat (Yellow/Green) - Quba */}
          <div className="absolute top-[70%] left-[50%] w-56 h-56 bg-yellow-500/15 rounded-full blur-[50px] transform -translate-x-1/2 -translate-y-1/2"></div>
          
          {/* Active Heat (Blue/Teal) - Prophet's Mosque */}
          <div className="absolute top-[50%] left-[50%] w-80 h-80 bg-primary/20 rounded-full blur-[70px] transform -translate-x-1/2 -translate-y-1/2"></div>
      </div>

      {/* Stylized Roads (SVG) - Lighter for contrast */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-30" viewBox="0 0 800 600" preserveAspectRatio="xMidYMid slice">
        {/* Ring Road 2 */}
        <circle cx="400" cy="300" r="250" fill="none" stroke="#555" strokeWidth="2" strokeDasharray="10 5" />
        {/* Ring Road 1 */}
        <circle cx="400" cy="300" r="100" fill="none" stroke="#666" strokeWidth="2" />
        
        {/* Main Arteries */}
        <line x1="400" y1="0" x2="400" y2="600" stroke="#444" strokeWidth="1" />
        <line x1="100" y1="300" x2="700" y2="300" stroke="#444" strokeWidth="1" />
        
        {/* Connecting Roads */}
        <path d="M 400 300 Q 600 100 700 50" fill="none" stroke="#444" strokeWidth="1" />
        <path d="M 400 300 Q 200 500 100 550" fill="none" stroke="#444" strokeWidth="1" />
      </svg>

      {/* Central Prophet's Mosque Area - Glowing Center */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20">
         <div className="w-32 h-32 bg-primary/10 rounded-full animate-ping absolute inset-0 m-auto"></div>
         <div className="w-12 h-12 bg-[#209269] rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(32,146,105,0.6)] relative z-20 border-[3px] border-[#1a1d21]">
            <span className="text-white text-lg drop-shadow-md">🕌</span>
         </div>
         <div className="absolute top-full mt-2 left-1/2 transform -translate-x-1/2 whitespace-nowrap font-bold text-xs text-white bg-black/60 px-3 py-1 rounded-full backdrop-blur-md border border-white/10">
            المسجد النبوي
         </div>
      </div>

      {/* Interactive Heatmap Markers (Snap Map Style) */}
      
      {/* Quba - South */}
      <SnapMarker top="70%" left="50%" name="قباء" count={120} intensity="medium" />
      
      {/* Sultana - North West */}
      <SnapMarker top="35%" left="30%" name="سلطانة" count={85} intensity="low" />
      
      {/* Al-Khalidiya - South East */}
      <SnapMarker top="65%" left="70%" name="الخالدية" count={42} intensity="low" />
      
      {/* Al-Aziziyah - West */}
      <SnapMarker top="50%" left="20%" name="العزيزية" count={210} intensity="high" hot />
      
      {/* Al-Awali - East */}
      <SnapMarker top="50%" left="80%" name="العوالي" count={56} intensity="low" />

      {/* Uhud - North */}
      <SnapMarker top="20%" left="50%" name="سيد الشهداء" count={95} intensity="medium" />
      
      {/* Overlay Controls (Zoom, My Location) - Mocked */}
      <div className="absolute bottom-6 right-6 flex flex-col gap-2 z-30">
         <div className="bg-[#2d3036] text-white p-2 rounded-full shadow-lg border border-white/10 hover:bg-[#3d4149] cursor-pointer">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
         </div>
         <div className="bg-[#2d3036] text-white p-2 rounded-full shadow-lg border border-white/10 hover:bg-[#3d4149] cursor-pointer">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
         </div>
      </div>
      
      <div className="absolute bottom-6 left-6 bg-[#2d3036]/90 backdrop-blur-md text-white px-4 py-2 rounded-full shadow-lg border border-white/10 text-xs font-bold flex items-center gap-2">
         <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
         مباشر
      </div>

    </div>
  );
}

function SnapMarker({ top, left, name, count, intensity, hot }: { top: string, left: string, name: string, count: number, intensity: 'low' | 'medium' | 'high', hot?: boolean }) {
  
  const colors = {
    low: 'bg-blue-500',
    medium: 'bg-yellow-500',
    high: 'bg-red-500'
  };

  const glowColors = {
    low: 'shadow-[0_0_15px_rgba(59,130,246,0.5)]',
    medium: 'shadow-[0_0_20px_rgba(234,179,8,0.6)]',
    high: 'shadow-[0_0_25px_rgba(239,68,68,0.7)]'
  };

  return (
    <motion.div 
      className="absolute cursor-pointer group z-20"
      style={{ top, left }}
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: "spring", stiffness: 260, damping: 20, delay: Math.random() * 0.5 }}
      whileHover={{ scale: 1.2, zIndex: 50 }}
    >
      <div className="relative flex flex-col items-center transform -translate-x-1/2 -translate-y-1/2">
        
        {/* Avatar/Cluster Representation */}
        <div className="relative">
           {/* Heat Ring */}
           <div className={`absolute inset-0 rounded-full opacity-70 animate-ping ${colors[intensity]}`}></div>
           
           {/* Main Circle */}
           <div className={`
              relative w-10 h-10 rounded-full flex items-center justify-center border-[3px] border-[#1a1d21] overflow-hidden
              ${colors[intensity]} ${glowColors[intensity]}
           `}>
              {/* Mock Avatar or Icon */}
              <div className="w-full h-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                 {hot ? (
                   <span className="text-lg">🔥</span> 
                 ) : (
                   <Users size={16} className="text-white drop-shadow-md" />
                 )}
              </div>
           </div>

           {/* Notification Badge */}
           <div className="absolute -top-1 -right-1 bg-white text-black text-[9px] px-1.5 h-4 flex items-center justify-center rounded-full font-extrabold shadow-sm border border-[#1a1d21]">
             {count}
           </div>
        </div>
        
        {/* Label */}
        <div className="mt-2 bg-[#2d3036]/80 backdrop-blur-md px-3 py-1 rounded-full shadow-lg text-xs font-bold text-center min-w-[60px] border border-white/10 text-white group-hover:bg-[#3d4149] transition-colors opacity-80 group-hover:opacity-100">
          {name}
        </div>
      </div>
    </motion.div>
  );
}
