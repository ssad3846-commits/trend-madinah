export default function RadioIcon({ size = 24, className = "" }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <rect x="2" y="8" width="20" height="12" rx="2" />
      <path d="M6 8L12 3L14 5" />
      <circle cx="7" cy="14" r="2.5" />
      <line x1="13" y1="11" x2="19" y2="11" />
      <line x1="13" y1="14" x2="19" y2="14" />
      <line x1="13" y1="17" x2="19" y2="17" />
    </svg>
  );
}
