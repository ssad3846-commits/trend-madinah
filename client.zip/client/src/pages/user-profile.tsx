import { useParams, useLocation } from "wouter";
import Layout from "@/components/layout/Layout";
import TrendList from "@/components/trends/TrendList";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Link as LinkIcon, ArrowRight, UserPlus, UserMinus } from "lucide-react";
import { Heart, MessageCircle, Repeat, Share, BadgeCheck, Loader2 } from "lucide-react";
import { usersApi } from "@/lib/api";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth-context";
import { useToast } from "@/hooks/use-toast";

function TwitterIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  );
}

function SnapchatIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12.166 3c.796 0 3.495.223 4.769 3.073.426.953.323 2.559.239 3.915l-.011.209c-.027.473-.05.878-.05 1.146 0 .263.075.482.225.654.159.182.393.282.7.297.295.015.59-.033.877-.143.115-.044.225-.095.33-.149.264-.137.545-.18.8-.123.376.083.627.377.682.576.14.5-.242.884-.422 1.024-.13.1-.27.193-.415.28-.293.175-.57.34-.714.541-.273.383-.216.948.192 1.882.148.339.318.67.507.995.364.625.742 1.27 1.018 1.812.138.27.206.478.206.642 0 .157-.05.304-.156.451-.22.305-.655.497-1.3.573-.268.032-.53.048-.786.048-.292 0-.576-.024-.848-.071-.249-.043-.487-.103-.718-.18-.24-.08-.448-.145-.625-.191-.12-.032-.238-.048-.353-.048-.18 0-.36.034-.531.103-.23.094-.429.224-.63.362-.434.298-.933.638-1.815.638-.885 0-1.387-.342-1.823-.643-.2-.138-.4-.268-.63-.361-.171-.07-.351-.104-.531-.104-.115 0-.233.016-.353.048-.177.046-.385.111-.626.191-.23.077-.469.137-.717.18-.273.047-.557.071-.849.071-.256 0-.518-.016-.786-.048-.644-.076-1.08-.268-1.3-.573-.106-.147-.156-.294-.156-.451 0-.164.068-.371.206-.642.276-.542.654-1.187 1.018-1.812.19-.325.359-.656.507-.995.408-.934.465-1.5.192-1.882-.143-.201-.42-.366-.714-.541-.145-.087-.285-.18-.415-.28-.18-.14-.562-.524-.422-1.024.055-.199.306-.493.682-.576.255-.057.536-.014.8.123.105.054.215.105.33.149.287.11.582.158.877.143.307-.015.541-.115.7-.297.15-.172.225-.391.225-.654 0-.268-.023-.673-.05-1.146l-.011-.21c-.084-1.355-.187-2.96.239-3.914C8.505 3.224 11.204 3 12 3h.166z" />
    </svg>
  );
}

function TikTokIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005 20.1a6.34 6.34 0 0010.86-4.43v-7a8.16 8.16 0 004.77 1.52v-3.4a4.85 4.85 0 01-1-.1z" />
    </svg>
  );
}

function LinkedInIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  );
}

export default function UserProfilePage() {
  const params = useParams<{ handle: string }>();
  const [, setLocation] = useLocation();
  const handle = params.handle;
  const { user: currentUser, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: user, isLoading: userLoading, error: userError } = useQuery({
    queryKey: ["user", handle],
    queryFn: () => usersApi.getUserByHandle(handle!),
    enabled: !!handle,
  });

  const { data: userTweets = [], isLoading: tweetsLoading } = useQuery({
    queryKey: ["userTweets", user?.id],
    queryFn: () => usersApi.getUserTweets(parseInt(user!.id)),
    enabled: !!user?.id,
  });

  const profileUserId = user?.id ? parseInt(user.id) : 0;
  const isOwnProfile = currentUser?.id === profileUserId;

  const { data: isFollowing = false } = useQuery({
    queryKey: ["isFollowing", profileUserId],
    queryFn: () => usersApi.isFollowing(profileUserId),
    enabled: isAuthenticated && !isOwnProfile && profileUserId > 0,
  });

  const followMutation = useMutation({
    mutationFn: () => usersApi.followUser(profileUserId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["isFollowing", profileUserId] });
      queryClient.invalidateQueries({ queryKey: ["user", handle] });
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (userLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[50vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (userError || !user) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center min-h-[50vh] gap-4">
          <p className="text-muted-foreground text-lg">المستخدم غير موجود</p>
          <Button variant="outline" onClick={() => setLocation("/")}>
            العودة للرئيسية
          </Button>
        </div>
      </Layout>
    );
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("ar-SA", { month: "long", year: "numeric" });
  };

  const hasSocialLinks = user.twitter || user.snapchat || user.tiktok || user.linkedin;
  const cleanHandle = user.handle.replace('@', '');

  return (
    <Layout>
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border/40 px-4 py-3 flex items-center gap-4">
        <Button 
          variant="ghost" 
          size="icon" 
          className="rounded-full" 
          onClick={() => window.history.back()}
          data-testid="button-back"
        >
          <ArrowRight className="h-5 w-5" />
          <span className="sr-only">رجوع</span>
        </Button>
        <div>
          <h1 className="font-bold text-lg">{user.name}</h1>
          <p className="text-xs text-muted-foreground">{userTweets.length} تغريدة</p>
        </div>
      </header>

      <div className="pb-20">
        <div className="h-32 md:h-48 bg-gradient-to-br from-primary/20 to-primary/5 overflow-hidden relative">
          {user.cover && (
            <img src={user.cover} alt="Cover" className="w-full h-full object-cover" />
          )}
        </div>

        <div className="px-4 relative">
          <div className="flex justify-between items-start -mt-10 mb-4">
            <div className="relative rounded-full p-1 bg-background">
              <img 
                src={user.avatar} 
                alt={user.name} 
                className="w-20 h-20 md:w-32 md:h-32 rounded-full object-cover border-4 border-background"
                data-testid={`img-avatar-${cleanHandle}`}
              />
            </div>
            {isAuthenticated && !isOwnProfile && (
              <Button 
                variant={isFollowing ? "outline" : "default"}
                className={`mt-12 md:mt-14 rounded-full font-bold ${
                  isFollowing 
                    ? "border-border/60 hover:border-red-500 hover:text-red-500 hover:bg-transparent" 
                    : "bg-foreground text-background hover:bg-foreground/90"
                }`}
                onClick={() => followMutation.mutate()}
                disabled={followMutation.isPending}
                data-testid="button-follow"
              >
                {isFollowing ? (
                  <span className="flex items-center gap-1">
                    <UserMinus size={16} />
                    إلغاء المتابعة
                  </span>
                ) : (
                  <span className="flex items-center gap-1">
                    <UserPlus size={16} />
                    متابعة
                  </span>
                )}
              </Button>
            )}
            {!isAuthenticated && (
              <Button 
                variant="default"
                className="mt-12 md:mt-14 rounded-full font-bold bg-foreground text-background hover:bg-foreground/90"
                onClick={() => setLocation("/auth")}
                data-testid="button-follow-login"
              >
                <UserPlus size={16} className="ml-1" />
                متابعة
              </Button>
            )}
          </div>

          <div className="mb-4">
            <div className="flex items-center gap-1">
              <h2 className="font-bold text-xl text-foreground" data-testid={`text-name-${cleanHandle}`}>
                {user.name}
              </h2>
              {user.verified && <BadgeCheck size={20} className="text-primary fill-primary/10" />}
            </div>
            <p className="text-muted-foreground ltr:text-right" dir="ltr" data-testid={`text-handle-${cleanHandle}`}>
              {user.handle}
            </p>

            {hasSocialLinks && (
              <div className="flex items-center gap-3 mt-3">
                {user.twitter && (
                  <a
                    href={`https://twitter.com/${user.twitter}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                    data-testid="link-twitter"
                  >
                    <TwitterIcon className="w-5 h-5" />
                  </a>
                )}
                {user.snapchat && (
                  <a
                    href={`https://snapchat.com/add/${user.snapchat}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-[#FFFC00] transition-colors"
                    data-testid="link-snapchat"
                  >
                    <SnapchatIcon className="w-5 h-5" />
                  </a>
                )}
                {user.tiktok && (
                  <a
                    href={`https://tiktok.com/@${user.tiktok}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                    data-testid="link-tiktok"
                  >
                    <TikTokIcon className="w-5 h-5" />
                  </a>
                )}
                {user.linkedin && (
                  <a
                    href={`https://linkedin.com/in/${user.linkedin}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-[#0A66C2] transition-colors"
                    data-testid="link-linkedin"
                  >
                    <LinkedInIcon className="w-5 h-5" />
                  </a>
                )}
              </div>
            )}
            
            {user.bio && (
              <p className="mt-3 text-base leading-relaxed">{user.bio}</p>
            )}

            <div className="flex flex-wrap gap-x-4 gap-y-2 mt-3 text-muted-foreground text-sm">
              {user.location && (
                <div className="flex items-center gap-1">
                  <MapPin size={16} />
                  <span>{user.location}</span>
                </div>
              )}
              {user.website && (
                <div className="flex items-center gap-1">
                  <LinkIcon size={16} />
                  <a 
                    href={`https://${user.website}`} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-primary hover:underline"
                  >
                    {user.website}
                  </a>
                </div>
              )}
              <div className="flex items-center gap-1">
                <Calendar size={16} />
                <span>انضم في {formatDate(user.joinedAt)}</span>
              </div>
            </div>

            <div className="flex gap-4 mt-4 text-sm">
              <div className="flex gap-1 hover:underline cursor-pointer">
                <span className="font-bold text-foreground">{user.following}</span>
                <span className="text-muted-foreground">يتابع</span>
              </div>
              <div className="flex gap-1 hover:underline cursor-pointer">
                <span className="font-bold text-foreground">{user.followers}</span>
                <span className="text-muted-foreground">متابع</span>
              </div>
            </div>
          </div>

          <div className="flex border-b border-border/40 mt-4">
            <div className="flex-1 text-center py-3 hover:bg-muted/30 cursor-pointer relative font-bold text-foreground">
              تغريدات
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-primary rounded-full mx-4"></div>
            </div>
            <div className="flex-1 text-center py-3 hover:bg-muted/30 cursor-pointer text-muted-foreground font-medium">
              ردود
            </div>
            <div className="flex-1 text-center py-3 hover:bg-muted/30 cursor-pointer text-muted-foreground font-medium">
              وسائط
            </div>
            <div className="flex-1 text-center py-3 hover:bg-muted/30 cursor-pointer text-muted-foreground font-medium">
              إعجابات
            </div>
          </div>
        </div>

        <div>
          {tweetsLoading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : userTweets.length > 0 ? (
            userTweets.map((tweet) => (
              <TweetItem key={tweet.id} tweet={tweet} user={user} />
            ))
          ) : (
            <div className="p-8 text-center text-muted-foreground">
              لا توجد تغريدات حتى الآن
            </div>
          )}
        </div>
      </div>

      <div className="hidden lg:block fixed left-0 top-0 h-screen w-[350px] border-r border-border/40 p-4 overflow-y-auto">
        <TrendList />
      </div>
    </Layout>
  );
}

interface TweetItemProps {
  tweet: {
    id: string;
    content: string;
    image?: string;
    likes: number;
    replies: number;
    retweets: number;
    timestamp: string;
  };
  user: {
    name: string;
    handle: string;
    avatar: string;
    verified?: boolean;
  };
}

function TweetItem({ tweet, user }: TweetItemProps) {
  const displayHandle = user.handle.startsWith('@') ? user.handle : `@${user.handle}`;
  
  return (
    <div 
      className="p-4 border-b border-border/40 hover:bg-muted/10 transition-colors cursor-pointer"
      data-testid={`tweet-${tweet.id}`}
    >
      <div className="flex gap-3">
        <img 
          src={user.avatar} 
          alt={user.name} 
          className="w-10 h-10 rounded-full object-cover"
        />
        <div className="flex-1">
          <div className="flex items-center gap-1 mb-1">
            <span className="font-bold text-sm">{user.name}</span>
            {user.verified && <BadgeCheck size={14} className="text-primary fill-primary/10" />}
            <span className="text-muted-foreground text-sm" dir="ltr">{displayHandle}</span>
            <span className="text-muted-foreground text-xs">· {tweet.timestamp}</span>
          </div>
          
          <p className="text-base whitespace-pre-wrap mb-3 leading-relaxed">
            {tweet.content}
          </p>

          {tweet.image && (
            <div className="mb-3 rounded-xl overflow-hidden border border-border/40">
              <img src={tweet.image} alt="Tweet attachment" className="w-full h-auto object-cover max-h-[300px]" />
            </div>
          )}

          <div className="flex items-center justify-between text-muted-foreground max-w-md">
            <button className="flex items-center gap-2 group hover:text-primary transition-colors text-xs sm:text-sm">
              <div className="p-2 rounded-full group-hover:bg-primary/10 transition-colors">
                <MessageCircle size={18} />
              </div>
              <span>{tweet.replies}</span>
            </button>
            
            <button className="flex items-center gap-2 group hover:text-green-500 transition-colors text-xs sm:text-sm">
              <div className="p-2 rounded-full group-hover:bg-green-500/10 transition-colors">
                <Repeat size={18} />
              </div>
              <span>{tweet.retweets}</span>
            </button>
            
            <button className="flex items-center gap-2 group hover:text-red-500 transition-colors text-xs sm:text-sm">
              <div className="p-2 rounded-full group-hover:bg-red-500/10 transition-colors">
                <Heart size={18} />
              </div>
              <span>{tweet.likes}</span>
            </button>
            
            <button className="flex items-center gap-2 group hover:text-primary transition-colors text-xs sm:text-sm">
              <div className="p-2 rounded-full group-hover:bg-primary/10 transition-colors">
                <Share size={18} />
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
