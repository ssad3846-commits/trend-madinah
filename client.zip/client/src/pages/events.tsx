import Layout from "@/components/layout/Layout";
import TrendList from "@/components/trends/TrendList";
import { eventsApi, ApiEvent } from "@/lib/api";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Search, Calendar, MapPin, Users, Clock, Plus, Heart, Check, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { useLocationContext } from "@/lib/location-context";

const EVENT_CATEGORIES = [
  { id: "workshop", label: "ورشة عمل", icon: "🛠️" },
  { id: "sport", label: "رياضة", icon: "⚽" },
  { id: "religious", label: "دينية", icon: "🕌" },
  { id: "entertainment", label: "ترفيه", icon: "🎉" },
  { id: "education", label: "تعليم", icon: "📚" },
  { id: "charity", label: "خيرية", icon: "❤️" },
  { id: "social", label: "اجتماعية", icon: "👥" },
  { id: "other", label: "أخرى", icon: "📌" },
];

function getCategoryLabel(categoryId: string) {
  return EVENT_CATEGORIES.find(c => c.id === categoryId)?.label || categoryId;
}

function getCategoryIcon(categoryId: string) {
  return EVENT_CATEGORIES.find(c => c.id === categoryId)?.icon || "📌";
}

function formatEventDate(dateStr: string) {
  const date = new Date(dateStr);
  return format(date, "EEEE، d MMMM yyyy", { locale: ar });
}

function EventCard({ event, onAttend }: { event: ApiEvent; onAttend: (status: "attending" | "interested") => void }) {
  const { data: userStatus, isLoading: statusLoading } = useQuery({
    queryKey: ['eventStatus', event.id],
    queryFn: () => eventsApi.getEventStatus(event.id),
  });

  const isUpcoming = new Date(event.eventDate) > new Date();

  return (
    <div 
      data-testid={`card-event-${event.id}`}
      className="bg-card border border-border/50 rounded-xl overflow-hidden hover:shadow-lg transition-all"
    >
      {event.image && (
        <div className="h-40 overflow-hidden">
          <img 
            src={event.image} 
            alt={event.title}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{getCategoryIcon(event.category)}</span>
            <span className="text-xs px-2 py-1 bg-primary/10 text-primary rounded-full">
              {getCategoryLabel(event.category)}
            </span>
          </div>
          {!isUpcoming && (
            <span className="text-xs px-2 py-1 bg-muted text-muted-foreground rounded-full">
              انتهت
            </span>
          )}
        </div>

        <h3 className="font-bold text-lg mb-2">{event.title}</h3>
        <p className="text-muted-foreground text-sm mb-3 line-clamp-2">{event.description}</p>

        <div className="space-y-2 text-sm text-muted-foreground mb-4">
          <div className="flex items-center gap-2">
            <Calendar size={14} />
            <span>{formatEventDate(event.eventDate)}</span>
          </div>
          {event.eventTime && (
            <div className="flex items-center gap-2">
              <Clock size={14} />
              <span>{event.eventTime}</span>
            </div>
          )}
          {event.locationName && (
            <div className="flex items-center gap-2">
              <MapPin size={14} />
              <span>{event.locationName}</span>
            </div>
          )}
          {event.address && (
            <div className="flex items-center gap-2 text-xs">
              <span className="mr-4">{event.address}</span>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between border-t border-border/50 pt-3">
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Users size={14} />
              <span>{event.attendees} حضور</span>
            </div>
            <div className="flex items-center gap-1">
              <Heart size={14} />
              <span>{event.interested} مهتم</span>
            </div>
          </div>

          {isUpcoming && (
            <div className="flex gap-2">
              <Button
                size="sm"
                variant={userStatus === "interested" ? "secondary" : "outline"}
                onClick={() => onAttend("interested")}
                disabled={statusLoading}
                data-testid={`button-interested-${event.id}`}
              >
                <Heart size={14} className={userStatus === "interested" ? "fill-current" : ""} />
              </Button>
              <Button
                size="sm"
                variant={userStatus === "attending" ? "default" : "outline"}
                onClick={() => onAttend("attending")}
                disabled={statusLoading}
                data-testid={`button-attending-${event.id}`}
              >
                <Check size={14} />
                <span className="mr-1">سأحضر</span>
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function CreateEventDialog({ locationId, locationName }: { locationId?: string; locationName?: string }) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [eventDate, setEventDate] = useState("");
  const [eventTime, setEventTime] = useState("");
  const [address, setAddress] = useState("");
  const [organizer, setOrganizer] = useState("");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: eventsApi.createEvent,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
      setOpen(false);
      setTitle("");
      setDescription("");
      setCategory("");
      setEventDate("");
      setEventTime("");
      setAddress("");
      setOrganizer("");
      toast({ title: "تم إنشاء الفعالية بنجاح" });
    },
    onError: (error: Error) => {
      toast({ title: error.message, variant: "destructive" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description || !category || !eventDate) {
      toast({ title: "يرجى ملء جميع الحقول المطلوبة", variant: "destructive" });
      return;
    }
    createMutation.mutate({
      title,
      description,
      category,
      eventDate,
      eventTime: eventTime || undefined,
      address: address || undefined,
      organizer: organizer || undefined,
      locationId,
      locationName,
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button data-testid="button-create-event" className="gap-2">
          <Plus size={18} />
          <span>إضافة فعالية</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>إضافة فعالية جديدة</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Input
              placeholder="عنوان الفعالية *"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              data-testid="input-event-title"
            />
          </div>
          <div>
            <Textarea
              placeholder="وصف الفعالية *"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              data-testid="input-event-description"
            />
          </div>
          <div>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger data-testid="select-event-category">
                <SelectValue placeholder="اختر التصنيف *" />
              </SelectTrigger>
              <SelectContent>
                {EVENT_CATEGORIES.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.icon} {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm text-muted-foreground mb-1 block">التاريخ *</label>
              <Input
                type="date"
                value={eventDate}
                onChange={(e) => setEventDate(e.target.value)}
                data-testid="input-event-date"
              />
            </div>
            <div>
              <label className="text-sm text-muted-foreground mb-1 block">الوقت</label>
              <Input
                type="time"
                value={eventTime}
                onChange={(e) => setEventTime(e.target.value)}
                data-testid="input-event-time"
              />
            </div>
          </div>
          <div>
            <Input
              placeholder="العنوان / الموقع"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              data-testid="input-event-address"
            />
          </div>
          <div>
            <Input
              placeholder="الجهة المنظمة"
              value={organizer}
              onChange={(e) => setOrganizer(e.target.value)}
              data-testid="input-event-organizer"
            />
          </div>
          <Button 
            type="submit" 
            className="w-full" 
            disabled={createMutation.isPending}
            data-testid="button-submit-event"
          >
            {createMutation.isPending ? <Loader2 className="animate-spin" /> : "إضافة الفعالية"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function EventsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { selectedLocation, locationId } = useLocationContext();
  
  const currentLocationName = selectedLocation?.name || "المملكة العربية السعودية";

  const { data: events = [], isLoading } = useQuery({
    queryKey: ['events'],
    queryFn: () => eventsApi.getEvents(),
  });

  const attendMutation = useMutation({
    mutationFn: ({ eventId, status }: { eventId: number; status: "attending" | "interested" }) =>
      eventsApi.toggleAttendance(eventId, status),
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
      queryClient.invalidateQueries({ queryKey: ['eventStatus', variables.eventId] });
      if (data.status) {
        toast({ title: data.status === "attending" ? "تم تسجيل حضورك" : "تم تسجيل اهتمامك" });
      } else {
        toast({ title: "تم إلغاء التسجيل" });
      }
    },
    onError: (error: Error) => {
      toast({ title: error.message, variant: "destructive" });
    },
  });

  const handleAttend = (eventId: number, status: "attending" | "interested") => {
    attendMutation.mutate({ eventId, status });
  };

  const upcomingEvents = events.filter(e => new Date(e.eventDate) >= new Date());
  const pastEvents = events.filter(e => new Date(e.eventDate) < new Date());

  return (
    <Layout>
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border/40 px-4 py-3 flex items-center justify-between">
        <div className="flex-1 max-w-xl relative mx-auto md:mx-0">
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-muted-foreground">
            <Search size={18} />
          </div>
          <input 
            type="text" 
            placeholder={`بحث عن فعاليات في ${currentLocationName}...`}
            className="w-full bg-muted/50 rounded-full py-2 pr-10 pl-4 focus:outline-none focus:ring-2 focus:ring-primary/20 border-none transition-all text-sm"
            data-testid="input-search-events"
          />
        </div>
      </header>

      <div className="p-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Calendar className="text-primary" />
            <h2 className="text-xl font-bold">فعاليات {currentLocationName}</h2>
          </div>
          <CreateEventDialog 
            locationId="all" 
            locationName="المدينة المنورة"
          />
        </div>

        {isLoading && (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        )}

        {!isLoading && events.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Calendar size={48} className="mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium">لا توجد فعاليات حالياً</p>
            <p className="text-sm">كن أول من يضيف فعالية في {currentLocationName}!</p>
          </div>
        )}

        {!isLoading && upcomingEvents.length > 0 && (
          <>
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <span className="text-green-500">●</span>
              الفعاليات القادمة ({upcomingEvents.length})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {upcomingEvents.map((event) => (
                <EventCard 
                  key={event.id} 
                  event={event} 
                  onAttend={(status) => handleAttend(event.id, status)}
                />
              ))}
            </div>
          </>
        )}

        {!isLoading && pastEvents.length > 0 && (
          <>
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2 text-muted-foreground">
              <span>●</span>
              فعاليات سابقة ({pastEvents.length})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 opacity-75">
              {pastEvents.map((event) => (
                <EventCard 
                  key={event.id} 
                  event={event} 
                  onAttend={(status) => handleAttend(event.id, status)}
                />
              ))}
            </div>
          </>
        )}
      </div>

      <TrendList />
    </Layout>
  );
}
