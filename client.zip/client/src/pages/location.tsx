import Layout from "@/components/layout/Layout";
import TrendList from "@/components/trends/TrendList";
import TweetCard from "@/components/feed/TweetCard";
import { tweetsApi, neighborhoodsApi } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { MapPin, ArrowRight, Loader2 } from "lucide-react";
import { useParams, useLocation, Link } from "wouter";

export default function LocationPage() {
  const params = useParams<{ id: string }>();
  const locationId = params.id || "all";
  const [, setLocationPath] = useLocation();

  const { data: neighborhoods = [] } = useQuery({
    queryKey: ['neighborhoods'],
    queryFn: () => neighborhoodsApi.getNeighborhoods(),
  });

  const { data: tweets = [], isLoading } = useQuery({
    queryKey: ['tweets', locationId],
    queryFn: () => tweetsApi.getTweets(locationId),
  });

  const locationName = neighborhoods.find(n => n.id === locationId)?.name || "المدينة المنورة";

  return (
    <Layout>
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border/40 px-4 py-3">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setLocationPath("/")}
            className="p-2 hover:bg-muted rounded-full transition-colors"
            data-testid="button-back"
          >
            <ArrowRight size={20} />
          </button>
          <div className="flex items-center gap-2">
            <MapPin className="text-primary" size={20} />
            <h1 className="text-xl font-bold">{locationName}</h1>
          </div>
        </div>
      </header>

      <div className="p-4">
        <div className="mb-4 text-muted-foreground text-sm">
          جميع التغريدات في {locationName}
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : tweets.length > 0 ? (
          <div className="divide-y divide-border/40">
            {tweets.map((tweet) => (
              <TweetCard key={tweet.id} tweet={tweet} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 text-muted-foreground">
            <MapPin className="mx-auto mb-4 text-muted-foreground/50" size={48} />
            <p className="text-lg font-medium">لا توجد تغريدات في هذا الموقع</p>
            <p className="text-sm mt-2">كن أول من يغرد من هذا المكان!</p>
            <Link href="/" className="text-primary hover:underline mt-4 inline-block">
              العودة للرئيسية
            </Link>
          </div>
        )}
      </div>

      <TrendList />
    </Layout>
  );
}
