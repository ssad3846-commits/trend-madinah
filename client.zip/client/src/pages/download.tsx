import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Smartphone, 
  MessageCircle, 
  MapPin, 
  TrendingUp, 
  Radio, 
  Video, 
  Users, 
  Bell,
  Shield,
  Zap,
  Star,
  ChevronDown,
  Apple,
  Play
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const features = [
  {
    icon: TrendingUp,
    title: "ترندات المناطق",
    description: "تابع الأكثر تداولاً في كل منطقة من مناطق المملكة"
  },
  {
    icon: MapPin,
    title: "محتوى محلي",
    description: "اكتشف ما يحدث في منطقتك من أخبار وأحداث"
  },
  {
    icon: MessageCircle,
    title: "دردشة القريبين",
    description: "تواصل مع من حولك في نطاق 10 كيلومتر"
  },
  {
    icon: Radio,
    title: "إذاعات سعودية",
    description: "استمع للإذاعات السعودية المباشرة"
  },
  {
    icon: Video,
    title: "بث مباشر",
    description: "شاهد البث المباشر من الحرمين والقنوات الإخبارية"
  },
  {
    icon: Users,
    title: "مجتمع نشط",
    description: "انضم لمجتمع يضم آلاف المستخدمين من كل المناطق"
  }
];

const stats = [
  { value: "13", label: "منطقة" },
  { value: "50K+", label: "مستخدم" },
  { value: "100K+", label: "تغريدة" },
  { value: "24/7", label: "بث مباشر" }
];

export default function DownloadPage() {
  const [showVideo, setShowVideo] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-primary/5" dir="rtl">
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border/40">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <span className="font-bold text-xl">ترند المدينة</span>
            </div>
          </Link>
          <Link href="/">
            <Button variant="outline" size="sm" data-testid="button-open-app">
              افتح التطبيق
            </Button>
          </Link>
        </div>
      </header>

      <main className="pt-20">
        <section className="container mx-auto px-4 py-16 md:py-24">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center md:text-right"
            >
              <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Zap className="w-4 h-4" />
                تطبيق جديد للسعوديين
              </div>
              
              <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
                كل ما يحدث في
                <span className="text-transparent bg-clip-text bg-gradient-to-l from-primary to-blue-500"> المملكة </span>
                بين يديك
              </h1>
              
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                تابع أخبار منطقتك، شارك آرائك، واكتشف ما يتحدث عنه السعوديون في كل مكان. منصة اجتماعية مصممة خصيصاً لك.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Button 
                  size="lg" 
                  className="bg-black hover:bg-black/90 text-white gap-2 h-14 px-6 rounded-xl"
                  data-testid="button-app-store"
                >
                  <Apple className="w-6 h-6" />
                  <div className="text-right">
                    <div className="text-xs opacity-80">حمّل من</div>
                    <div className="font-semibold">App Store</div>
                  </div>
                </Button>
                
                <Button 
                  size="lg" 
                  className="bg-black hover:bg-black/90 text-white gap-2 h-14 px-6 rounded-xl"
                  data-testid="button-google-play"
                >
                  <Play className="w-6 h-6 fill-current" />
                  <div className="text-right">
                    <div className="text-xs opacity-80">احصل عليه من</div>
                    <div className="font-semibold">Google Play</div>
                  </div>
                </Button>
              </div>

              <div className="flex items-center gap-4 mt-8 justify-center md:justify-start">
                <div className="flex -space-x-2 space-x-reverse">
                  {[1,2,3,4,5].map((i) => (
                    <div 
                      key={i}
                      className="w-8 h-8 rounded-full border-2 border-background bg-gradient-to-br from-primary/40 to-primary"
                    />
                  ))}
                </div>
                <div className="text-sm text-muted-foreground">
                  <span className="font-bold text-foreground">+50,000</span> مستخدم نشط
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative"
            >
              <div className="relative mx-auto w-[280px] md:w-[320px]">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-blue-500/30 rounded-[3rem] blur-3xl" />
                
                <div className="relative bg-gradient-to-b from-zinc-800 to-zinc-900 rounded-[3rem] p-3 shadow-2xl">
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-black rounded-b-2xl" />
                  
                  <div className="bg-background rounded-[2.5rem] overflow-hidden aspect-[9/19]">
                    <div className="p-4 bg-gradient-to-b from-primary/20 to-transparent">
                      <div className="flex items-center justify-between mb-4">
                        <div className="w-10 h-10 rounded-full bg-primary/20" />
                        <div className="flex items-center gap-2">
                          <Bell className="w-5 h-5 text-muted-foreground" />
                          <div className="w-8 h-8 rounded-full bg-primary/20" />
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div className="bg-card rounded-xl p-3 shadow-sm">
                          <div className="flex items-start gap-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-400 to-green-600" />
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <div className="h-3 w-20 bg-foreground/20 rounded" />
                                <Shield className="w-4 h-4 text-primary" />
                              </div>
                              <div className="h-2 w-full bg-foreground/10 rounded mb-1" />
                              <div className="h-2 w-3/4 bg-foreground/10 rounded" />
                            </div>
                          </div>
                        </div>
                        
                        <div className="bg-card rounded-xl p-3 shadow-sm">
                          <div className="flex items-start gap-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-blue-600" />
                            <div className="flex-1">
                              <div className="h-3 w-24 bg-foreground/20 rounded mb-2" />
                              <div className="h-2 w-full bg-foreground/10 rounded mb-1" />
                              <div className="h-2 w-2/3 bg-foreground/10 rounded" />
                              <div className="h-24 w-full bg-gradient-to-br from-primary/20 to-blue-500/20 rounded-lg mt-2" />
                            </div>
                          </div>
                        </div>
                        
                        <div className="bg-card rounded-xl p-3 shadow-sm">
                          <div className="flex items-start gap-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-400 to-purple-600" />
                            <div className="flex-1">
                              <div className="h-3 w-16 bg-foreground/20 rounded mb-2" />
                              <div className="h-2 w-full bg-foreground/10 rounded" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="absolute bottom-0 left-0 right-0 h-16 bg-card border-t border-border/40 flex items-center justify-around px-4">
                      <div className="w-6 h-6 rounded-full bg-primary" />
                      <div className="w-6 h-6 rounded-full bg-muted" />
                      <div className="w-6 h-6 rounded-full bg-muted" />
                      <div className="w-6 h-6 rounded-full bg-muted" />
                    </div>
                  </div>
                </div>
              </div>
              
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: 0.6 }}
                className="absolute -top-4 -right-4 bg-card shadow-lg rounded-2xl p-3 flex items-center gap-2"
              >
                <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-green-500" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">#الرياض</div>
                  <div className="font-bold text-sm">12.5K تغريدة</div>
                </div>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: 0.8 }}
                className="absolute -bottom-4 -left-4 bg-card shadow-lg rounded-2xl p-3 flex items-center gap-2"
              >
                <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                  <Video className="w-5 h-5 text-red-500" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">بث مباشر</div>
                  <div className="font-bold text-sm">الحرم المكي</div>
                </div>
              </motion.div>
            </motion.div>
          </div>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="flex justify-center mt-16"
          >
            <ChevronDown className="w-8 h-8 text-muted-foreground animate-bounce" />
          </motion.div>
        </section>

        <section className="bg-card/50 py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="text-center"
                >
                  <div className="text-4xl md:text-5xl font-bold text-primary mb-2">
                    {stat.value}
                  </div>
                  <div className="text-muted-foreground">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="container mx-auto px-4 py-20">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              كل ما تحتاجه في مكان واحد
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              مميزات حصرية تجعل تجربتك فريدة ومتكاملة
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-card rounded-2xl p-6 border border-border/40 hover:border-primary/40 transition-colors group"
              >
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="bg-gradient-to-br from-primary to-blue-600 py-20">
          <div className="container mx-auto px-4 text-center text-white">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                جاهز للانضمام؟
              </h2>
              <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto">
                حمّل التطبيق الآن وكن جزءاً من أكبر مجتمع سعودي رقمي
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  className="bg-white text-black hover:bg-white/90 gap-2 h-14 px-6 rounded-xl"
                  data-testid="button-app-store-footer"
                >
                  <Apple className="w-6 h-6" />
                  <div className="text-right">
                    <div className="text-xs opacity-60">حمّل من</div>
                    <div className="font-semibold">App Store</div>
                  </div>
                </Button>
                
                <Button 
                  size="lg" 
                  className="bg-white text-black hover:bg-white/90 gap-2 h-14 px-6 rounded-xl"
                  data-testid="button-google-play-footer"
                >
                  <Play className="w-6 h-6 fill-current" />
                  <div className="text-right">
                    <div className="text-xs opacity-60">احصل عليه من</div>
                    <div className="font-semibold">Google Play</div>
                  </div>
                </Button>
              </div>

              <div className="flex items-center justify-center gap-2 mt-8">
                {[1,2,3,4,5].map((i) => (
                  <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                ))}
                <span className="mr-2 font-medium">4.9 تقييم المستخدمين</span>
              </div>
            </motion.div>
          </div>
        </section>

        <footer className="bg-card border-t border-border/40 py-8">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-white" />
                </div>
                <span className="font-bold">ترند المدينة</span>
              </div>
              
              <p className="text-sm text-muted-foreground">
                © 2025 ترند المدينة. جميع الحقوق محفوظة.
              </p>
              
              <div className="flex items-center gap-4">
                <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground">
                  سياسة الخصوصية
                </Link>
                <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground">
                  شروط الاستخدام
                </Link>
              </div>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
