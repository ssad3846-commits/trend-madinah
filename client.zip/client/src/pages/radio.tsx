import Layout from "@/components/layout/Layout";
import { Radio, Headphones, Music2, BookOpen, Mic2, Play, Square, Newspaper, Volume2 } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";

interface RadioStation {
  id: string;
  name: string;
  description: string;
  streamUrl: string;
  category: string;
  frequency: string;
  color: string;
}

const SAUDI_RADIO_STATIONS: RadioStation[] = [
  {
    id: "quran",
    name: "إذاعة القرآن الكريم",
    description: "البث المباشر من المملكة العربية السعودية",
    streamUrl: "https://stream.radiojar.com/4wqre23fytzuv",
    category: "دينية",
    frequency: "FM 88.6",
    color: "from-emerald-600 to-emerald-800"
  },
  {
    id: "mix-fm",
    name: "مكس FM",
    description: "الإذاعة الأولى لأحدث الأغاني",
    streamUrl: "https://stream.statsradio.com:8054/stream",
    category: "موسيقى",
    frequency: "FM 98.0",
    color: "from-orange-500 to-red-600"
  },
  {
    id: "rotana",
    name: "روتانا FM",
    description: "أغاني عربية ومشاهير",
    streamUrl: "https://philae.shoutca.st:8250/;",
    category: "موسيقى",
    frequency: "FM 88.0",
    color: "from-purple-500 to-purple-700"
  },
  {
    id: "ufm",
    name: "UFM يو إف إم",
    description: "إذاعة شبابية ورياضية",
    streamUrl: "https://stream.ufmradio.com:8000/;",
    category: "شبابية",
    frequency: "FM 90.0",
    color: "from-blue-500 to-blue-700"
  },
  {
    id: "alif-alif",
    name: "ألف ألف FM",
    description: "الموجة السعودية",
    streamUrl: "https://alifalifjobs.com/radio/8000/AlifAlifLive.mp3",
    category: "موسيقى",
    frequency: "FM 101.0",
    color: "from-pink-500 to-pink-700"
  },
  {
    id: "sunna",
    name: "إذاعة السنة",
    description: "إذاعة إسلامية من مكة المكرمة",
    streamUrl: "https://andromeda.shoutca.st:8189/stream",
    category: "دينية",
    frequency: "Live",
    color: "from-teal-600 to-teal-800"
  },
  {
    id: "miraath",
    name: "إذاعة ميراث",
    description: "نشر العلم الشرعي",
    streamUrl: "https://radio.al7eah.net/8010/stream",
    category: "دينية",
    frequency: "Live",
    color: "from-green-600 to-green-800"
  },
  {
    id: "houb",
    name: "راديو حب",
    description: "إذاعة منوعة",
    streamUrl: "https://nap.casthost.net:8028/live",
    category: "موسيقى",
    frequency: "Live",
    color: "from-rose-500 to-rose-700"
  },
  {
    id: "ibe",
    name: "راديو i-be",
    description: "ريادة الأعمال والاستثمار",
    streamUrl: "https://stream.zeno.fm/xh6d0xs8f18uv",
    category: "أخبار",
    frequency: "Live",
    color: "from-indigo-500 to-indigo-700"
  },
  {
    id: "quran-alukah",
    name: "القرآن الكريم - الألوكة",
    description: "تلاوات قرآنية متنوعة",
    streamUrl: "https://radio.alukah.net/quran.mp3",
    category: "دينية",
    frequency: "Live",
    color: "from-amber-600 to-amber-800"
  },
  {
    id: "nidaa",
    name: "نداء الإسلام",
    description: "إذاعة دينية من مكة المكرمة",
    streamUrl: "https://nidaa.fm:8811/quran.mp3",
    category: "دينية",
    frequency: "FM 89.2",
    color: "from-cyan-600 to-cyan-800"
  },
  {
    id: "ulama",
    name: "كبار العلماء",
    description: "دروس ومحاضرات العلماء",
    streamUrl: "https://radio.alukah.net/ulama",
    category: "دينية",
    frequency: "Live",
    color: "from-lime-600 to-lime-800"
  },
];

const categories = ["الكل", "دينية", "موسيقى", "شبابية", "أخبار"];

const getCategoryIcon = (category: string) => {
  switch (category) {
    case "دينية": return <BookOpen className="w-4 h-4" />;
    case "موسيقى": return <Music2 className="w-4 h-4" />;
    case "شبابية": return <Headphones className="w-4 h-4" />;
    case "أخبار": return <Newspaper className="w-4 h-4" />;
    default: return <Radio className="w-4 h-4" />;
  }
};

export default function RadioPage() {
  const [selectedCategory, setSelectedCategory] = useState("الكل");
  const [playingStation, setPlayingStation] = useState<RadioStation | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorStation, setErrorStation] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const filteredStations = selectedCategory === "الكل" 
    ? SAUDI_RADIO_STATIONS 
    : SAUDI_RADIO_STATIONS.filter(s => s.category === selectedCategory);

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
        audioRef.current = null;
      }
    };
  }, []);

  const handleStationClick = (station: RadioStation) => {
    setErrorStation(null);
    
    if (playingStation?.id === station.id) {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
        audioRef.current = null;
      }
      setPlayingStation(null);
      setIsLoading(false);
      return;
    }

    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = '';
      audioRef.current = null;
    }

    setPlayingStation(station);
    setIsLoading(true);

    const audio = new Audio();
    audio.preload = 'none';
    audioRef.current = audio;
    
    audio.onplaying = () => {
      setIsLoading(false);
      setErrorStation(null);
    };

    audio.onerror = () => {
      setIsLoading(false);
      setPlayingStation(null);
      setErrorStation(station.id);
    };

    audio.src = station.streamUrl;
    audio.load();
    audio.play().catch(() => {
      setIsLoading(false);
      setPlayingStation(null);
      setErrorStation(station.id);
    });
  };

  const stopPlaying = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = '';
      audioRef.current = null;
    }
    setPlayingStation(null);
    setIsLoading(false);
  };

  return (
    <Layout>
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border/40 px-4 py-3">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center">
            <Headphones className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-xl">إذاعات السعودية FM</h1>
            <p className="text-xs text-muted-foreground">استمع مباشرة لأشهر الإذاعات</p>
          </div>
        </div>
        
        <div className="flex gap-2 overflow-x-auto pb-1">
          {categories.map((cat) => (
            <Button
              key={cat}
              variant={selectedCategory === cat ? "default" : "outline"}
              size="sm"
              className="rounded-full whitespace-nowrap gap-1.5"
              onClick={() => setSelectedCategory(cat)}
              data-testid={`filter-category-${cat}`}
            >
              {getCategoryIcon(cat)}
              {cat}
            </Button>
          ))}
        </div>
      </header>

      <div className="p-4 space-y-3 pb-32">
        {filteredStations.map((station) => {
          const isPlaying = playingStation?.id === station.id;
          const isCurrentLoading = isPlaying && isLoading;
          const hasError = errorStation === station.id;
          
          return (
            <div
              key={station.id}
              onClick={() => handleStationClick(station)}
              className={`rounded-2xl overflow-hidden cursor-pointer transition-all active:scale-[0.98] ${
                isPlaying ? "ring-2 ring-primary shadow-lg" : hasError ? "ring-2 ring-red-500" : "hover:shadow-md"
              }`}
              data-testid={`radio-station-${station.id}`}
            >
              <div className={`bg-gradient-to-l ${station.color} p-4 flex items-center gap-4`}>
                <div className={`w-14 h-14 rounded-full flex items-center justify-center shrink-0 ${
                  isPlaying ? "bg-white" : hasError ? "bg-red-500" : "bg-white/20"
                }`}>
                  {isCurrentLoading ? (
                    <div className="w-6 h-6 border-2 border-gray-800 border-t-transparent rounded-full animate-spin" />
                  ) : isPlaying ? (
                    <Square className="w-6 h-6 text-gray-800" />
                  ) : hasError ? (
                    <span className="text-white text-lg">!</span>
                  ) : (
                    <Play className="w-6 h-6 text-white mr-[-2px]" />
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-white truncate">{station.name}</h3>
                  <p className="text-white/70 text-sm truncate">
                    {hasError ? "غير متاح حالياً - اضغط للمحاولة مجدداً" : station.description}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="px-2 py-0.5 bg-white/20 rounded-full text-white text-xs">
                      {station.frequency}
                    </span>
                    <span className="text-white/60 text-xs">{station.category}</span>
                  </div>
                </div>
                
                {isPlaying && !isCurrentLoading && (
                  <div className="flex gap-0.5 items-end h-6">
                    <div className="w-1 bg-white rounded-full animate-pulse" style={{height: '60%', animationDelay: '0ms'}} />
                    <div className="w-1 bg-white rounded-full animate-pulse" style={{height: '100%', animationDelay: '150ms'}} />
                    <div className="w-1 bg-white rounded-full animate-pulse" style={{height: '40%', animationDelay: '300ms'}} />
                    <div className="w-1 bg-white rounded-full animate-pulse" style={{height: '80%', animationDelay: '450ms'}} />
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {playingStation && (
        <div className="fixed bottom-16 md:bottom-0 left-0 right-0 z-40 bg-card border-t border-border shadow-lg">
          <div className={`h-1 bg-gradient-to-l ${playingStation.color}`} />
          <div className="p-3 flex items-center gap-3">
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${playingStation.color} flex items-center justify-center shrink-0`}>
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Volume2 className="w-6 h-6 text-white" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold truncate">{playingStation.name}</h4>
              <p className="text-sm text-muted-foreground truncate">
                {isLoading ? "جاري الاتصال..." : "يعمل الآن"}
              </p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="shrink-0"
              onClick={(e) => {
                e.stopPropagation();
                stopPlaying();
              }}
            >
              <Square className="w-5 h-5" />
            </Button>
          </div>
        </div>
      )}
    </Layout>
  );
}
