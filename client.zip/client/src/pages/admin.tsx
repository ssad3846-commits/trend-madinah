import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Users, MessageSquare, HelpCircle, MapPin, TrendingUp, BarChart3, Lock, Eye, EyeOff, LogOut, Loader2, UserPlus, CheckCircle } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface RecentUser {
  id: number;
  name: string;
  handle: string;
  email: string | null;
  avatar: string;
  verified: boolean | null;
  createdAt: string;
}

interface AdminStats {
  totalUsers: number;
  totalTweets: number;
  totalQuestions: number;
  totalPlaces: number;
  tweetsPerRegion: { regionId: string; regionName: string; count: number }[];
  usersPerDay: { date: string; count: number }[];
  tweetsPerDay: { date: string; count: number }[];
  recentUsers: RecentUser[];
}

async function fetchAdminStats(): Promise<AdminStats> {
  const response = await fetch("/api/admin/stats");
  if (!response.ok) throw new Error("Failed to fetch stats");
  return response.json();
}

async function loginAdmin(credentials: { login: string; password: string }) {
  const response = await fetch("/api/admin/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(credentials),
  });
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "فشل في تسجيل الدخول");
  }
  return response.json();
}

async function checkAdminSession() {
  const response = await fetch("/api/admin/session");
  if (!response.ok) return null;
  return response.json();
}

async function logoutAdmin() {
  const response = await fetch("/api/admin/logout", { method: "POST" });
  if (!response.ok) throw new Error("فشل في تسجيل الخروج");
  return response.json();
}

function AdminLoginForm({ onSuccess }: { onSuccess: () => void }) {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const loginMutation = useMutation({
    mutationFn: loginAdmin,
    onSuccess: () => {
      onSuccess();
    },
    onError: (err: Error) => {
      setError(err.message);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    loginMutation.mutate({ login, password });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-emerald-100 dark:bg-emerald-900 flex items-center justify-center">
            <Lock className="h-8 w-8 text-emerald-600" />
          </div>
          <CardTitle className="text-2xl">لوحة تحكم الإدارة</CardTitle>
          <p className="text-muted-foreground mt-2">سجل دخولك للوصول إلى لوحة التحكم</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 p-3 rounded-lg text-sm text-center">
                {error}
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="login">اسم المستخدم أو البريد الإلكتروني</Label>
              <Input
                id="login"
                type="text"
                placeholder="admin أو admin@example.com"
                value={login}
                onChange={(e) => setLogin(e.target.value)}
                className="text-left"
                dir="ltr"
                required
                data-testid="input-admin-login"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">كلمة المرور</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="text-left pr-10"
                  dir="ltr"
                  required
                  data-testid="input-admin-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <Button
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-700"
              disabled={loginMutation.isPending}
              data-testid="button-admin-login"
            >
              {loginMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                "تسجيل الدخول"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

function AdminDashboard({ onLogout }: { onLogout: () => void }) {
  const queryClient = useQueryClient();
  const { data: stats, isLoading, error } = useQuery({
    queryKey: ["admin-stats"],
    queryFn: fetchAdminStats,
  });

  const logoutMutation = useMutation({
    mutationFn: logoutAdmin,
    onSuccess: () => {
      queryClient.clear();
      onLogout();
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-red-500">فشل في تحميل الإحصائيات</p>
      </div>
    );
  }

  const maxTweetsInRegion = Math.max(...(stats?.tweetsPerRegion.map(r => r.count) || [1]));

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-card border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BarChart3 className="h-8 w-8 text-emerald-600" />
            <h1 className="text-2xl font-bold text-foreground" data-testid="admin-title">لوحة التحكم</h1>
          </div>
          <Button
            variant="outline"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
            data-testid="button-admin-logout"
          >
            <LogOut className="h-4 w-4 ml-2" />
            تسجيل الخروج
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card data-testid="stat-users">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">المستخدمين</CardTitle>
              <Users className="h-5 w-5 text-emerald-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats?.totalUsers.toLocaleString("ar-SA")}</div>
            </CardContent>
          </Card>

          <Card data-testid="stat-tweets">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">التغريدات</CardTitle>
              <MessageSquare className="h-5 w-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats?.totalTweets.toLocaleString("ar-SA")}</div>
            </CardContent>
          </Card>

          <Card data-testid="stat-questions">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">الأسئلة</CardTitle>
              <HelpCircle className="h-5 w-5 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats?.totalQuestions.toLocaleString("ar-SA")}</div>
            </CardContent>
          </Card>

          <Card data-testid="stat-places">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">الأماكن</CardTitle>
              <MapPin className="h-5 w-5 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats?.totalPlaces.toLocaleString("ar-SA")}</div>
            </CardContent>
          </Card>
        </div>

        <Card data-testid="tweets-per-region">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-emerald-600" />
              التغريدات حسب المنطقة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats?.tweetsPerRegion
                .sort((a, b) => b.count - a.count)
                .map((region) => (
                  <div key={region.regionId} className="space-y-2" data-testid={`region-stat-${region.regionId}`}>
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-foreground">{region.regionName}</span>
                      <span className="text-muted-foreground">{region.count.toLocaleString("ar-SA")} تغريدة</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-3">
                      <div
                        className="bg-gradient-to-l from-emerald-500 to-emerald-600 h-3 rounded-full transition-all duration-500"
                        style={{ width: `${(region.count / maxTweetsInRegion) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card data-testid="users-per-day">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-emerald-600" />
                المستخدمين الجدد (آخر 7 أيام)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {stats?.usersPerDay.slice(-7).map((day) => (
                  <div key={day.date} className="flex justify-between items-center py-1 border-b border-border last:border-0">
                    <span className="text-muted-foreground text-sm">{new Date(day.date).toLocaleDateString("ar-SA")}</span>
                    <span className="font-medium text-foreground">{day.count} مستخدم</span>
                  </div>
                ))}
                {(!stats?.usersPerDay || stats.usersPerDay.length === 0) && (
                  <p className="text-muted-foreground text-center py-4">لا توجد بيانات</p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card data-testid="tweets-per-day">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-blue-600" />
                التغريدات اليومية (آخر 7 أيام)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {stats?.tweetsPerDay.slice(-7).map((day) => (
                  <div key={day.date} className="flex justify-between items-center py-1 border-b border-border last:border-0">
                    <span className="text-muted-foreground text-sm">{new Date(day.date).toLocaleDateString("ar-SA")}</span>
                    <span className="font-medium text-foreground">{day.count} تغريدة</span>
                  </div>
                ))}
                {(!stats?.tweetsPerDay || stats.tweetsPerDay.length === 0) && (
                  <p className="text-muted-foreground text-center py-4">لا توجد بيانات</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card data-testid="recent-users">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5 text-emerald-600" />
              المسجلين الجدد
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {stats?.recentUsers?.map((user) => (
                <div key={user.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors" data-testid={`recent-user-${user.id}`}>
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-foreground truncate">{user.name}</span>
                      {user.verified && <CheckCircle className="h-4 w-4 text-blue-500 flex-shrink-0" />}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span dir="ltr">@{user.handle}</span>
                      {user.email && <span className="truncate">• {user.email}</span>}
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground text-left">
                    {new Date(user.createdAt).toLocaleDateString("ar-SA", {
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                    })}
                  </div>
                </div>
              ))}
              {(!stats?.recentUsers || stats.recentUsers.length === 0) && (
                <p className="text-muted-foreground text-center py-4">لا يوجد مستخدمين مسجلين</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isChecking, setIsChecking] = useState(true);

  const { data: session, isLoading: sessionLoading } = useQuery({
    queryKey: ["admin-session"],
    queryFn: checkAdminSession,
    retry: false,
  });

  if (sessionLoading || isChecking) {
    if (sessionLoading) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
        </div>
      );
    }
    setIsChecking(false);
  }

  if (session?.isAdmin || isAuthenticated) {
    return <AdminDashboard onLogout={() => setIsAuthenticated(false)} />;
  }

  return <AdminLoginForm onSuccess={() => setIsAuthenticated(true)} />;
}
