import Layout from "@/components/layout/Layout";
import TrendList from "@/components/trends/TrendList";
import { trendsApi, tweetsApi, usersApi } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { Search, Twitter, TrendingUp, Loader2, ArrowRight, UserCircle, BadgeCheck } from "lucide-react";
import { useSearch, useLocation, Link } from "wouter";
import { useState, useEffect } from "react";
import TweetCard from "@/components/feed/TweetCard";
import { useLocationContext } from "@/lib/location-context";

export default function ExplorePage() {
  const { selectedLocation } = useLocationContext();
  const currentLocationName = selectedLocation?.name || "المملكة العربية السعودية";
  const searchString = useSearch();
  const [, setLocationPath] = useLocation();
  
  const urlParams = new URLSearchParams(searchString);
  const queryParam = urlParams.get('q') || '';
  const [searchQuery, setSearchQuery] = useState(queryParam);
  
  useEffect(() => {
    setSearchQuery(queryParam);
  }, [queryParam]);

  const { data: trends = [], isLoading } = useQuery({
    queryKey: ['trends-explore', selectedLocation?.id],
    queryFn: () => trendsApi.getTrends(selectedLocation?.id, 10),
  });

  const { data: tweets = [], isLoading: tweetsLoading } = useQuery({
    queryKey: ['tweets-explore', selectedLocation?.id],
    queryFn: () => tweetsApi.getTweets(selectedLocation?.id),
  });

  const { data: searchedUsers = [], isLoading: usersLoading } = useQuery({
    queryKey: ['users-search', queryParam],
    queryFn: () => usersApi.searchUsers(queryParam),
    enabled: !!queryParam && queryParam.length > 0,
  });

  const filteredTweets = queryParam 
    ? tweets.filter(tweet => tweet.content.includes(queryParam))
    : [];

  const sortedTrends = [...trends].sort((a, b) => a.rank - b.rank).slice(0, 10);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocationPath(`/explore?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };
  
  const clearSearch = () => {
    setSearchQuery('');
    setLocationPath('/explore');
  };

  return (
    <Layout>
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border/40 px-4 py-3 flex items-center justify-between gap-2">
         {queryParam && (
           <button 
             onClick={clearSearch}
             className="p-2 hover:bg-muted rounded-full transition-colors"
             data-testid="button-back"
           >
             <ArrowRight size={20} />
           </button>
         )}
         <form onSubmit={handleSearch} className="flex-1 max-w-xl relative mx-auto md:mx-0">
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-muted-foreground">
               <Search size={18} />
            </div>
            <input 
               type="text" 
               value={searchQuery}
               onChange={(e) => setSearchQuery(e.target.value)}
               placeholder={`بحث عن هاشتاق في ${currentLocationName}...`}
               className="w-full bg-muted/50 rounded-full py-2 pr-10 pl-4 focus:outline-none focus:ring-2 focus:ring-primary/20 border-none transition-all text-sm"
               data-testid="input-search-hashtag"
            />
         </form>
      </header>

      <div className="p-4">
        
        {/* Show search results when query exists */}
        {queryParam ? (
          <>
            <div className="flex items-center gap-2 mb-6">
              <Search className="text-primary" />
              <h2 className="text-xl font-bold">نتائج البحث عن "{queryParam}"</h2>
            </div>
            
            {/* Users Section */}
            {usersLoading ? (
              <div className="flex justify-center items-center py-4">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
              </div>
            ) : searchedUsers.length > 0 && (
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-3">
                  <UserCircle className="text-primary" size={18} />
                  <h3 className="font-bold">الحسابات</h3>
                </div>
                <div className="space-y-2">
                  {searchedUsers.map((user) => (
                    <Link 
                      key={user.id} 
                      href={`/user/${user.handle.replace('@', '')}`}
                      className="flex items-center gap-3 p-3 rounded-xl hover:bg-muted/50 transition-colors"
                    >
                      <img 
                        src={user.avatar} 
                        alt={user.name}
                        className="w-12 h-12 rounded-full object-cover border border-border"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="font-bold truncate">{user.name}</span>
                          {user.verified && (
                            <BadgeCheck size={16} className="text-primary fill-primary/20" />
                          )}
                        </div>
                        <span className="text-sm text-muted-foreground">{user.handle}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">{user.followers} متابع</span>
                    </Link>
                  ))}
                </div>
              </div>
            )}
            
            {/* Tweets Section */}
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="text-primary" size={18} />
              <h3 className="font-bold">التغريدات</h3>
            </div>
            
            {tweetsLoading ? (
              <div className="flex justify-center items-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredTweets.length > 0 ? (
              <div className="divide-y divide-border/40">
                {filteredTweets.map((tweet) => (
                  <TweetCard key={tweet.id} tweet={tweet} />
                ))}
              </div>
            ) : (
              <div className="text-center py-10 text-muted-foreground">
                <p>لا توجد تغريدات تحتوي على "{queryParam}"</p>
                <p className="text-sm mt-2">جرب البحث بكلمات أخرى</p>
              </div>
            )}
          </>
        ) : (
          <>
            {/* Twitter Integration Banner (Mock) */}
            <div className="mb-6 p-4 bg-[#1DA1F2]/5 rounded-xl border border-[#1DA1F2]/20 flex items-center justify-between">
               <div className="flex items-center gap-3">
                  <div className="bg-[#1DA1F2] p-2 rounded-full text-white">
                     <Twitter size={20} fill="currentColor" />
                  </div>
                  <div>
                     <h3 className="font-bold text-sm text-[#1DA1F2]">متصل بمنصة تويتر (X)</h3>
                     <p className="text-xs text-muted-foreground">يتم جلب الهاشتاقات المتداولة من تويتر مباشرة</p>
                  </div>
               </div>
               <div className="flex items-center gap-1 text-green-600 text-xs font-bold bg-green-100 px-2 py-1 rounded-full">
                  <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                  متصل
               </div>
            </div>

            {/* Trending Section Header */}
            <div className="flex items-center gap-2 mb-6">
               <TrendingUp className="text-primary" />
               <h2 className="text-xl font-bold">الهاشتاقات المتداولة في {currentLocationName}</h2>
            </div>

            {/* Loading State */}
            {isLoading && (
              <div className="flex justify-center items-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            )}

            {/* Hashtag Grid */}
            {!isLoading && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               {sortedTrends.length > 0 ? (
                 sortedTrends.map((trend, index) => (
                   <div 
                     key={trend.id} 
                     className="group cursor-pointer bg-card hover:bg-muted/40 border border-border/40 rounded-xl p-4 transition-all hover:shadow-sm hover:border-primary/30"
                     onClick={() => {
                      setLocationPath(`/explore?q=${encodeURIComponent(trend.hashtag)}`);
                    }}
                     data-testid={`explore-trend-${trend.id}`}
                   >
                      <div className="flex justify-between items-start">
                         <div className="flex items-center gap-2">
                            <span className="text-lg font-bold text-muted-foreground/50 w-6">{index + 1}</span>
                            <div>
                               <h3 className="font-bold text-lg text-foreground group-hover:text-primary transition-colors dir-ltr text-right">
                                  {trend.hashtag}
                               </h3>
                               <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                                  <span>{trend.category}</span>
                                  <span>·</span>
                                  <span>{trend.posts} تغريدة</span>
                               </div>
                            </div>
                         </div>
                      </div>
                   </div>
                 ))
               ) : (
                 <div className="col-span-full text-center py-10 text-muted-foreground">
                    <p>لا توجد هاشتاقات نشطة حالياً في هذه المنطقة.</p>
                    <p className="text-sm mt-2">جرب اختيار "المملكة العربية السعودية" (الكل)</p>
                 </div>
               )}
              </div>
            )}
          </>
        )}
      </div>

      {/* Sidebar Trends */}
      <TrendList />
    </Layout>
  );
}
