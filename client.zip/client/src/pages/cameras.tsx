import Layout from "@/components/layout/Layout";
import TrendList from "@/components/trends/TrendList";
import { camerasApi, LiveCamera } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { Video, Loader2, X, Radio, Building2, MapPin, Globe, Newspaper } from "lucide-react";
import { useState } from "react";

const categories = [
  { id: "all", name: "الكل", icon: Globe },
  { id: "مسجد", name: "الحرمين", icon: Building2 },
  { id: "ساحات", name: "مدن العالم", icon: MapPin },
  { id: "أخبار", name: "الأخبار", icon: Newspaper },
];

export default function CamerasPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedCamera, setSelectedCamera] = useState<LiveCamera | null>(null);

  const { data: cameras = [], isLoading } = useQuery({
    queryKey: ['cameras', selectedCategory],
    queryFn: () => camerasApi.getCameras(
      undefined,
      selectedCategory === "all" ? undefined : selectedCategory
    ),
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "مسجد": return <Building2 className="w-4 h-4" />;
      case "ساحات": return <MapPin className="w-4 h-4" />;
      case "أخبار": return <Newspaper className="w-4 h-4" />;
      default: return <Globe className="w-4 h-4" />;
    }
  };

  return (
    <Layout>
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border/40 px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <h1 className="font-bold text-xl flex items-center gap-2">
            <Video className="text-red-500" />
            بث مباشر حول العالم
          </h1>
        </div>
        
        <div className="flex gap-2 overflow-x-auto pb-1">
          {categories.map((cat) => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                  selectedCategory === cat.id 
                    ? 'bg-red-500 text-white' 
                    : 'bg-muted text-muted-foreground hover:bg-muted/80'
                }`}
                data-testid={`category-${cat.id}`}
              >
                <Icon className="w-4 h-4" />
                {cat.name}
              </button>
            );
          })}
        </div>
      </header>

      <div className="p-4">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
          <span className="text-sm text-muted-foreground">بث مباشر من حول العالم</span>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : cameras.length === 0 ? (
          <div className="text-center py-12">
            <Video className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">لا توجد كاميرات متاحة حالياً</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {cameras.map((camera) => (
              <div 
                key={camera.id}
                className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-gray-900 to-gray-800 aspect-video group cursor-pointer hover:ring-2 hover:ring-red-500 transition-all"
                onClick={() => setSelectedCamera(camera)}
                data-testid={`camera-card-${camera.id}`}
              >
                {camera.thumbnailUrl ? (
                  <img 
                    src={camera.thumbnailUrl} 
                    alt={camera.name}
                    className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                  />
                ) : (
                  <div className="absolute inset-0 bg-gradient-to-br from-red-900/50 to-gray-900" />
                )}
                
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                
                <div className="absolute top-3 right-3 flex items-center gap-2">
                  {camera.isLive && (
                    <div className="flex items-center gap-1 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                      <Radio className="w-3 h-3 animate-pulse" />
                      مباشر
                    </div>
                  )}
                  {camera.isOfficial && (
                    <div className="bg-blue-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                      رسمي
                    </div>
                  )}
                </div>

                <div className="absolute top-3 left-3">
                  <div className="flex items-center gap-1 bg-black/50 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-full">
                    {getCategoryIcon(camera.category)}
                    {camera.category}
                  </div>
                </div>
                
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <h3 className="text-white font-bold text-lg mb-1 line-clamp-1">
                    {camera.name}
                  </h3>
                  {camera.description && (
                    <p className="text-white/70 text-sm line-clamp-2">
                      {camera.description}
                    </p>
                  )}
                  {camera.locationName && (
                    <div className="flex items-center gap-1 text-white/60 text-xs mt-2">
                      <MapPin className="w-3 h-3" />
                      {camera.locationName}
                    </div>
                  )}
                </div>
                
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-16 h-16 bg-red-500/80 backdrop-blur-sm rounded-full flex items-center justify-center">
                    <Video className="w-8 h-8 text-white" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedCamera && (
        <div 
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setSelectedCamera(null)}
        >
          <div 
            className="relative w-full max-w-4xl bg-background rounded-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-3">
                {selectedCamera.isLive && (
                  <div className="flex items-center gap-1 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                    <Radio className="w-3 h-3 animate-pulse" />
                    مباشر
                  </div>
                )}
                <h2 className="font-bold text-lg">{selectedCamera.name}</h2>
              </div>
              <button 
                onClick={() => setSelectedCamera(null)}
                className="p-2 hover:bg-muted rounded-full transition-colors"
                data-testid="btn-close-camera"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="aspect-video">
              <iframe
                src={selectedCamera.embedUrl.includes('?') 
                  ? `${selectedCamera.embedUrl}&autoplay=1&mute=0` 
                  : `${selectedCamera.embedUrl}?autoplay=1&mute=0`}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                title={selectedCamera.name}
              />
            </div>
            
            {selectedCamera.description && (
              <div className="p-4 border-t border-border">
                <p className="text-muted-foreground">{selectedCamera.description}</p>
              </div>
            )}
          </div>
        </div>
      )}

      <TrendList />
    </Layout>
  );
}
