import { useParams, useLocation, Link } from "wouter";
import Layout from "@/components/layout/Layout";
import TrendList from "@/components/trends/TrendList";
import { Button } from "@/components/ui/button";
import { ArrowRight, Heart, MessageCircle, Repeat, Share, MapPin, BadgeCheck, Loader2, UserPlus, UserMinus } from "lucide-react";
import { tweetsApi, usersApi } from "@/lib/api";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth-context";
import { useToast } from "@/hooks/use-toast";
import { useState, useRef } from "react";
import { cn } from "@/lib/utils";

export default function TweetDetailPage() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const tweetId = params.id ? parseInt(params.id) : 0;
  const { user: currentUser, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tweet, isLoading, error } = useQuery({
    queryKey: ["tweet", tweetId],
    queryFn: () => tweetsApi.getTweet(tweetId),
    enabled: tweetId > 0,
  });

  const [localLikes, setLocalLikes] = useState(0);
  const [localRetweets, setLocalRetweets] = useState(0);
  const [isLiked, setIsLiked] = useState(false);
  const [isRetweeted, setIsRetweeted] = useState(false);
  const [replyContent, setReplyContent] = useState("");
  const replyInputRef = useRef<HTMLTextAreaElement>(null);

  const tweetUserId = tweet?.user?.id ? parseInt(tweet.user.id) : 0;
  const isOwnTweet = currentUser?.id === tweetUserId;
  const userHandle = tweet?.user?.handle?.replace('@', '') || '';

  const { data: isFollowing = false } = useQuery({
    queryKey: ["isFollowing", tweetUserId],
    queryFn: () => usersApi.isFollowing(tweetUserId),
    enabled: isAuthenticated && !isOwnTweet && tweetUserId > 0,
  });

  const followMutation = useMutation({
    mutationFn: () => usersApi.followUser(tweetUserId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["isFollowing", tweetUserId] });
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const likeMutation = useMutation({
    mutationFn: () => tweetsApi.likeTweet(tweetId),
    onSuccess: (data) => {
      setIsLiked(data.liked);
      setLocalLikes(data.tweet.likes);
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const retweetMutation = useMutation({
    mutationFn: () => tweetsApi.retweetTweet(tweetId),
    onSuccess: (data) => {
      setIsRetweeted(data.retweeted);
      setLocalRetweets(data.tweet.retweets);
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const { data: replies = [], isLoading: repliesLoading } = useQuery({
    queryKey: ["replies", tweetId],
    queryFn: () => tweetsApi.getReplies(tweetId),
    enabled: tweetId > 0,
  });

  const replyMutation = useMutation({
    mutationFn: (content: string) => tweetsApi.createReply(tweetId, content),
    onSuccess: () => {
      setReplyContent("");
      queryClient.invalidateQueries({ queryKey: ["replies", tweetId] });
      queryClient.invalidateQueries({ queryKey: ["tweet", tweetId] });
      toast({
        title: "تم",
        description: "تم إضافة الرد بنجاح",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleReply = () => {
    if (replyContent.trim()) {
      replyMutation.mutate(replyContent.trim());
    }
  };

  const handleShare = async () => {
    try {
      await navigator.share({
        title: `تغريدة من ${tweet?.user?.name}`,
        text: tweet?.content,
        url: window.location.href,
      });
    } catch {
      if (tweet?.content) {
        await navigator.clipboard.writeText(tweet.content);
        toast({
          title: "تم النسخ",
          description: "تم نسخ التغريدة إلى الحافظة",
        });
      }
    }
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[50vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (error || !tweet) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center min-h-[50vh] gap-4">
          <p className="text-muted-foreground text-lg">التغريدة غير موجودة</p>
          <Button variant="outline" onClick={() => setLocation("/")}>
            العودة للرئيسية
          </Button>
        </div>
      </Layout>
    );
  }

  const displayLikes = localLikes || tweet.likes;
  const displayRetweets = localRetweets || tweet.retweets;

  return (
    <Layout>
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border/40 px-4 py-3 flex items-center gap-4">
        <Button 
          variant="ghost" 
          size="icon" 
          className="rounded-full" 
          onClick={() => window.history.back()}
          data-testid="button-back"
        >
          <ArrowRight className="h-5 w-5" />
          <span className="sr-only">رجوع</span>
        </Button>
        <h1 className="font-bold text-lg">تغريدة</h1>
      </header>

      <div className="p-4 border-b border-border/40">
        <div className="flex items-start gap-3 mb-4">
          <Link href={`/user/${userHandle}`}>
            <img 
              src={tweet.user.avatar} 
              alt={tweet.user.name} 
              className="w-12 h-12 rounded-full object-cover border border-border cursor-pointer hover:opacity-80 transition-opacity"
            />
          </Link>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <div>
                <Link href={`/user/${userHandle}`}>
                  <span className="font-bold text-foreground hover:underline cursor-pointer flex items-center gap-1">
                    {tweet.user.name}
                    {tweet.user.verified && (
                      <BadgeCheck size={16} className="text-primary fill-primary/10" />
                    )}
                  </span>
                </Link>
                <Link href={`/user/${userHandle}`}>
                  <span className="text-muted-foreground text-sm hover:underline cursor-pointer block" dir="ltr">
                    @{userHandle}
                  </span>
                </Link>
              </div>
              {isAuthenticated && !isOwnTweet && (
                <button
                  onClick={() => followMutation.mutate()}
                  disabled={followMutation.isPending}
                  className={cn(
                    "flex items-center gap-1 px-4 py-2 rounded-full text-sm font-bold transition-all",
                    isFollowing
                      ? "bg-transparent border border-border hover:border-red-500 hover:text-red-500 text-foreground"
                      : "bg-foreground text-background hover:bg-foreground/90"
                  )}
                >
                  {isFollowing ? (
                    <>
                      <UserMinus size={16} />
                      <span>إلغاء المتابعة</span>
                    </>
                  ) : (
                    <>
                      <UserPlus size={16} />
                      <span>متابعة</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        </div>

        {tweet.location && (
          <div className="flex items-center text-primary text-sm mb-3">
            <MapPin size={14} className="ml-1" />
            <span>{tweet.location}</span>
          </div>
        )}

        <p className="text-xl leading-relaxed mb-4 whitespace-pre-wrap">
          {tweet.content.split(' ').map((word: string, i: number) => 
            word.startsWith('#') ? <span key={i} className="text-primary cursor-pointer hover:underline">{word} </span> : word + ' '
          )}
        </p>

        {tweet.image && (
          <div className="rounded-2xl overflow-hidden border border-border/60 shadow-sm mb-4">
            <img src={tweet.image} alt="Tweet attachment" className="w-full h-auto max-h-[500px] object-cover" />
          </div>
        )}

        <div className="text-muted-foreground text-sm mb-4">
          <span>{tweet.timestamp}</span>
        </div>

        <div className="flex gap-6 py-3 border-t border-b border-border/40 text-sm">
          <div className="flex gap-1">
            <span className="font-bold text-foreground">{displayRetweets}</span>
            <span className="text-muted-foreground">إعادة تغريد</span>
          </div>
          <div className="flex gap-1">
            <span className="font-bold text-foreground">{displayLikes}</span>
            <span className="text-muted-foreground">إعجاب</span>
          </div>
          <div className="flex gap-1">
            <span className="font-bold text-foreground">{tweet.replies}</span>
            <span className="text-muted-foreground">رد</span>
          </div>
        </div>

        <div className="flex justify-around py-3 text-muted-foreground">
          <button 
            onClick={() => {
              if (!isAuthenticated) {
                setLocation("/auth");
                return;
              }
              replyInputRef.current?.focus();
            }}
            className="flex items-center justify-center p-2 rounded-full hover:bg-primary/10 hover:text-primary transition-all"
          >
            <MessageCircle size={22} />
          </button>
          <button
            onClick={() => {
              if (!isAuthenticated) {
                setLocation("/auth");
                return;
              }
              retweetMutation.mutate();
            }}
            disabled={retweetMutation.isPending}
            className={cn(
              "flex items-center justify-center p-2 rounded-full transition-all",
              isRetweeted ? "text-green-500 bg-green-500/10" : "hover:bg-green-500/10 hover:text-green-500"
            )}
          >
            <Repeat size={22} />
          </button>
          <button
            onClick={() => {
              if (!isAuthenticated) {
                setLocation("/auth");
                return;
              }
              likeMutation.mutate();
            }}
            disabled={likeMutation.isPending}
            className={cn(
              "flex items-center justify-center p-2 rounded-full transition-all",
              isLiked ? "text-pink-500 bg-pink-500/10" : "hover:bg-pink-500/10 hover:text-pink-500"
            )}
          >
            <Heart size={22} className={isLiked ? "fill-pink-500" : ""} />
          </button>
          <button
            onClick={handleShare}
            className="flex items-center justify-center p-2 rounded-full hover:bg-primary/10 hover:text-primary transition-all"
          >
            <Share size={22} />
          </button>
        </div>
      </div>

      {/* Reply input */}
      {isAuthenticated ? (
        <div className="p-4 border-b border-border/40">
          <div className="flex gap-3">
            <img 
              src={currentUser?.avatar || "https://api.dicebear.com/7.x/initials/svg?seed=U"} 
              alt="Avatar" 
              className="w-10 h-10 rounded-full object-cover"
            />
            <div className="flex-1">
              <textarea
                ref={replyInputRef}
                placeholder="اكتب ردك..."
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                className="w-full bg-transparent border-none outline-none resize-none text-base placeholder:text-muted-foreground"
                rows={2}
              />
              <div className="flex justify-end mt-2">
                <Button
                  onClick={handleReply}
                  disabled={!replyContent.trim() || replyMutation.isPending}
                  className="rounded-full px-4"
                >
                  {replyMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "رد"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-4 border-b border-border/40 bg-muted/30">
          <div className="flex items-center justify-center gap-3 py-2">
            <span className="text-muted-foreground text-sm">سجّل دخولك لإضافة رد</span>
            <Link href="/auth" className="bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-2 rounded-full text-sm font-bold transition-colors">
              تسجيل الدخول
            </Link>
          </div>
        </div>
      )}

      {/* Replies */}
      <div>
        {repliesLoading ? (
          <div className="flex justify-center p-4">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : replies.length > 0 ? (
          replies.map((reply: any) => (
            <div key={reply.id} className="p-4 border-b border-border/40">
              <div className="flex gap-3">
                <Link href={`/user/${reply.user.handle}`}>
                  <img 
                    src={reply.user.avatar} 
                    alt={reply.user.name} 
                    className="w-10 h-10 rounded-full object-cover cursor-pointer hover:opacity-80"
                  />
                </Link>
                <div className="flex-1">
                  <div className="flex items-center gap-1 mb-1">
                    <Link href={`/user/${reply.user.handle}`}>
                      <span className="font-bold text-sm hover:underline cursor-pointer">{reply.user.name}</span>
                    </Link>
                    <span className="text-muted-foreground text-sm" dir="ltr">@{reply.user.handle}</span>
                  </div>
                  <p className="text-base whitespace-pre-wrap">{reply.content}</p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="p-8 text-center text-muted-foreground">
            لا توجد ردود حتى الآن
          </div>
        )}
      </div>

      <div className="hidden lg:block fixed left-0 top-0 h-screen w-[350px] border-r border-border/40 p-4 overflow-y-auto">
        <TrendList />
      </div>
    </Layout>
  );
}
