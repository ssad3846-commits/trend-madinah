import Layout from "@/components/layout/Layout";
import TrendList from "@/components/trends/TrendList";
import { tweetsApi, trendsApi } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { Flame, TrendingUp, Heart, MessageCircle, Repeat2, Loader2, Play } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { useLocationContext } from "@/lib/location-context";

export default function ViralPage() {
  const [activeTab, setActiveTab] = useState<'viral' | 'trending'>('viral');
  const { selectedLocation, locationId } = useLocationContext();
  
  const currentLocationName = selectedLocation?.name || "المملكة العربية السعودية";

  const { data: tweets = [], isLoading: tweetsLoading } = useQuery({
    queryKey: ['tweets'],
    queryFn: () => tweetsApi.getTweets(),
  });

  const { data: trends = [], isLoading: trendsLoading } = useQuery({
    queryKey: ['trends'],
    queryFn: () => trendsApi.getTrends(undefined, 10),
  });

  const viralTweets = [...tweets]
    .sort((a, b) => (b.likes + b.retweets * 2) - (a.likes + a.retweets * 2))
    .slice(0, 20);

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <Layout>
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border/40 px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <h1 className="font-bold text-xl flex items-center gap-2">
            <Flame className="text-orange-500" />
            المتداول
          </h1>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('viral')}
            className={`flex-1 py-2 px-3 rounded-full text-sm font-medium transition-all ${
              activeTab === 'viral' 
                ? 'bg-gradient-to-r from-orange-500 to-pink-500 text-white' 
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            }`}
            data-testid="tab-viral"
          >
            <Flame className="inline-block w-4 h-4 ml-1" />
            الأكثر تفاعلاً
          </button>
          <button
            onClick={() => setActiveTab('trending')}
            className={`flex-1 py-2 px-3 rounded-full text-sm font-medium transition-all ${
              activeTab === 'trending' 
                ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white' 
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            }`}
            data-testid="tab-trending"
          >
            <TrendingUp className="inline-block w-4 h-4 ml-1" />
            الهاشتاقات
          </button>
        </div>
      </header>

      <div className="p-4">
        {activeTab === 'viral' ? (
          <>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse" />
              <span className="text-sm text-muted-foreground">محتوى رائج في {currentLocationName}</span>
            </div>

            {tweetsLoading ? (
              <div className="flex justify-center items-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {viralTweets.map((tweet, index) => (
                  <Link 
                    key={tweet.id} 
                    href={`/tweet/${tweet.id}`}
                    className="block"
                    data-testid={`viral-card-${tweet.id}`}
                  >
                    <div className={`relative rounded-2xl overflow-hidden ${
                      index === 0 ? 'col-span-2 aspect-video' : 'aspect-[3/4]'
                    } bg-gradient-to-br from-gray-900 to-gray-800 group cursor-pointer hover:scale-[1.02] transition-transform`}>
                      {tweet.image ? (
                        <img 
                          src={tweet.image} 
                          alt="" 
                          className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                        />
                      ) : (
                        <div className={`absolute inset-0 bg-gradient-to-br ${
                          index % 4 === 0 ? 'from-orange-600 to-pink-600' :
                          index % 4 === 1 ? 'from-blue-600 to-purple-600' :
                          index % 4 === 2 ? 'from-green-600 to-teal-600' :
                          'from-yellow-600 to-orange-600'
                        }`} />
                      )}
                      
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                      
                      {index < 3 && (
                        <div className="absolute top-2 right-2 bg-orange-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1">
                          <Flame className="w-3 h-3" />
                          {index === 0 ? 'الأكثر رواجاً' : `#${index + 1}`}
                        </div>
                      )}
                      
                      <div className="absolute bottom-0 left-0 right-0 p-3">
                        <div className="flex items-center gap-2 mb-2">
                          <img 
                            src={tweet.user?.avatar} 
                            alt={tweet.user?.name}
                            className="w-6 h-6 rounded-full border border-white/30"
                          />
                          <span className="text-white text-xs font-medium truncate">
                            {tweet.user?.name}
                          </span>
                          {tweet.user?.verified && (
                            <span className="text-blue-400 text-xs">✓</span>
                          )}
                        </div>
                        
                        <p className="text-white text-sm line-clamp-2 mb-2 leading-relaxed">
                          {tweet.content.slice(0, 80)}...
                        </p>
                        
                        <div className="flex items-center gap-3 text-white/80 text-xs">
                          <span className="flex items-center gap-1">
                            <Heart className="w-3 h-3" />
                            {formatNumber(tweet.likes)}
                          </span>
                          <span className="flex items-center gap-1">
                            <Repeat2 className="w-3 h-3" />
                            {formatNumber(tweet.retweets)}
                          </span>
                          <span className="flex items-center gap-1">
                            <MessageCircle className="w-3 h-3" />
                            {formatNumber(tweet.replies)}
                          </span>
                        </div>
                      </div>
                      
                      {tweet.image && (
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                            <Play className="w-6 h-6 text-white fill-white" />
                          </div>
                        </div>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </>
        ) : (
          <>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
              <span className="text-sm text-muted-foreground">هاشتاقات رائجة في {currentLocationName}</span>
            </div>

            {trendsLoading ? (
              <div className="flex justify-center items-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="space-y-3">
                {trends.slice(0, 10).map((trend, index) => (
                  <Link
                    key={trend.id}
                    href={`/explore?q=${encodeURIComponent(trend.hashtag)}`}
                    className="block"
                    data-testid={`trend-card-${trend.id}`}
                  >
                    <div className="bg-card border border-border/60 rounded-xl p-4 hover:bg-muted/50 transition-colors group">
                      <div className="flex items-start gap-4">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold ${
                          index === 0 ? 'bg-gradient-to-br from-orange-500 to-pink-500' :
                          index === 1 ? 'bg-gradient-to-br from-blue-500 to-purple-500' :
                          index === 2 ? 'bg-gradient-to-br from-green-500 to-teal-500' :
                          'bg-gradient-to-br from-gray-500 to-gray-600'
                        }`}>
                          {index + 1}
                        </div>
                        
                        <div className="flex-1">
                          <h3 className="font-bold text-lg group-hover:text-primary transition-colors">
                            {trend.hashtag}
                          </h3>
                          <p className="text-sm text-muted-foreground mt-1">
                            {trend.posts} تغريدة
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {trend.category}
                          </p>
                        </div>
                        
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <TrendingUp className="w-4 h-4" />
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      <TrendList />
    </Layout>
  );
}
