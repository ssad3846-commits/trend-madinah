import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth-context";
import { authApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Check, X, Eye, EyeOff } from "lucide-react";

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [isResetPassword, setIsResetPassword] = useState(false);
  const [, setLocation] = useLocation();
  const { login, signup, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();

  const [name, setName] = useState("");
  const [handle, setHandle] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [handleAvailable, setHandleAvailable] = useState<boolean | null>(null);
  const [checkingHandle, setCheckingHandle] = useState(false);
  const [resetCode, setResetCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [savedResetCode, setSavedResetCode] = useState("");

  useEffect(() => {
    if (isAuthenticated && !authLoading) {
      setLocation("/");
    }
  }, [isAuthenticated, authLoading, setLocation]);

  useEffect(() => {
    if (!handle || handle.length < 3) {
      setHandleAvailable(null);
      return;
    }

    const timer = setTimeout(async () => {
      setCheckingHandle(true);
      try {
        const available = await authApi.checkHandle(handle);
        setHandleAvailable(available);
      } catch (error) {
        setHandleAvailable(null);
      } finally {
        setCheckingHandle(false);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [handle]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      if (isLogin) {
        await login(email, password);
        toast({
          title: "مرحباً بعودتك!",
          description: "تم تسجيل الدخول بنجاح",
        });
      } else {
        if (!name || name.trim().length < 2) {
          toast({
            title: "خطأ",
            description: "الاسم الكامل مطلوب (حرفين على الأقل)",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
        if (!handle || handle.length < 3) {
          toast({
            title: "خطأ",
            description: "اسم المستخدم يجب أن يكون 3 أحرف على الأقل",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
        if (!email || !email.includes("@")) {
          toast({
            title: "خطأ",
            description: "البريد الإلكتروني غير صحيح",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
        if (password.length < 6) {
          toast({
            title: "خطأ",
            description: "كلمة المرور يجب أن تكون 6 أحرف على الأقل",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
        if (password !== confirmPassword) {
          toast({
            title: "خطأ",
            description: "كلمات المرور غير متطابقة",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
        if (!handleAvailable) {
          toast({
            title: "خطأ",
            description: "اسم المستخدم غير متاح أو قصير جداً",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
        await signup({ name, handle, email, password });
        toast({
          title: "مرحباً بك!",
          description: "تم إنشاء حسابك بنجاح",
        });
      }
      setLocation("/");
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message || "حدث خطأ، حاول مرة أخرى",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const switchMode = () => {
    setIsLogin(!isLogin);
    setIsForgotPassword(false);
    setIsResetPassword(false);
    setName("");
    setHandle("");
    setEmail("");
    setPassword("");
    setConfirmPassword("");
    setHandleAvailable(null);
    setResetCode("");
    setNewPassword("");
    setSavedResetCode("");
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const result = await authApi.forgotPassword(email);
      setSavedResetCode(result.code);
      setIsResetPassword(true);
      toast({
        title: "تم إرسال رمز التحقق",
        description: `رمز التحقق: ${result.code}`,
      });
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message || "فشل في إرسال رمز التحقق",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await authApi.resetPassword(email, resetCode, newPassword);
      toast({
        title: "تم تغيير كلمة المرور",
        description: "يمكنك الآن تسجيل الدخول بكلمة المرور الجديدة",
      });
      setIsForgotPassword(false);
      setIsResetPassword(false);
      setResetCode("");
      setNewPassword("");
      setSavedResetCode("");
      setPassword("");
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message || "فشل في تغيير كلمة المرور",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 to-emerald-100">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
      </div>
    );
  }

  if (isForgotPassword) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 via-white to-emerald-100 p-4">
        <Card className="w-full max-w-md shadow-xl border-emerald-100">
          <CardHeader className="text-center space-y-4">
            <div className="mx-auto w-16 h-16 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-2xl text-white font-bold">ت</span>
            </div>
            <CardTitle className="text-2xl font-bold text-emerald-800">
              {isResetPassword ? "إعادة تعيين كلمة المرور" : "استعادة كلمة المرور"}
            </CardTitle>
            <CardDescription className="text-gray-600">
              {isResetPassword
                ? "أدخل رمز التحقق وكلمة المرور الجديدة"
                : "أدخل بريدك الإلكتروني لإرسال رمز التحقق"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!isResetPassword ? (
              <form onSubmit={handleForgotPassword} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="forgot-email" className="text-right block">البريد الإلكتروني</Label>
                  <Input
                    id="forgot-email"
                    type="email"
                    placeholder="example@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="text-left"
                    required
                    data-testid="input-forgot-email"
                    dir="ltr"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                  disabled={isSubmitting}
                  data-testid="button-send-reset-code"
                >
                  {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "إرسال رمز التحقق"}
                </Button>
                <button
                  type="button"
                  onClick={() => setIsForgotPassword(false)}
                  className="w-full text-sm text-muted-foreground hover:text-emerald-600 transition-colors"
                  data-testid="button-back-to-login"
                >
                  العودة لتسجيل الدخول
                </button>
              </form>
            ) : (
              <form onSubmit={handleResetPassword} className="space-y-4">
                {savedResetCode && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-center">
                    <p className="text-sm text-emerald-700">رمز التحقق: <span className="font-bold">{savedResetCode}</span></p>
                    <p className="text-xs text-emerald-600 mt-1">تم إرسال الرمز أيضاً لبريدك الإلكتروني</p>
                  </div>
                )}
                <div className="space-y-2">
                  <Label htmlFor="reset-code" className="text-right block">رمز التحقق</Label>
                  <Input
                    id="reset-code"
                    type="text"
                    placeholder="123456"
                    value={resetCode}
                    onChange={(e) => setResetCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                    className="text-center text-2xl tracking-widest"
                    required
                    maxLength={6}
                    data-testid="input-reset-code"
                    dir="ltr"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-password" className="text-right block">كلمة المرور الجديدة</Label>
                  <Input
                    id="new-password"
                    type="password"
                    placeholder="••••••••"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="text-left"
                    required
                    minLength={6}
                    data-testid="input-new-password"
                    dir="ltr"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                  disabled={isSubmitting || resetCode.length !== 6}
                  data-testid="button-reset-password"
                >
                  {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "تغيير كلمة المرور"}
                </Button>
                <button
                  type="button"
                  onClick={() => {
                    setIsResetPassword(false);
                    setIsForgotPassword(false);
                    setResetCode("");
                    setNewPassword("");
                    setSavedResetCode("");
                  }}
                  className="w-full text-sm text-muted-foreground hover:text-emerald-600 transition-colors"
                  data-testid="button-cancel-reset"
                >
                  إلغاء والعودة
                </button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 via-white to-emerald-100 p-4">
      <Card className="w-full max-w-md shadow-xl border-emerald-100">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center shadow-lg">
            <span className="text-2xl text-white font-bold">ت</span>
          </div>
          <CardTitle className="text-2xl font-bold text-emerald-800">
            {isLogin ? "تسجيل الدخول" : "إنشاء حساب جديد"}
          </CardTitle>
          <CardDescription className="text-gray-600">
            {isLogin
              ? "أدخل بياناتك للدخول إلى حسابك"
              : "احجز اسم المستخدم الخاص بك وابدأ التغريد"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-right block">الاسم الكامل</Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="مثال: محمد أحمد"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="text-right"
                    required
                    data-testid="input-name"
                    dir="rtl"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="handle" className="text-right block">اسم المستخدم</Label>
                  <div className="relative">
                    <Input
                      id="handle"
                      type="text"
                      placeholder="mohammed_ahmed"
                      value={handle}
                      onChange={(e) => setHandle(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))}
                      className="text-left pl-8 pr-12"
                      required
                      data-testid="input-handle"
                      dir="ltr"
                    />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">@</span>
                    <div className="absolute right-3 top-1/2 -translate-y-1/2">
                      {checkingHandle && <Loader2 className="h-4 w-4 animate-spin text-gray-400" />}
                      {!checkingHandle && handleAvailable === true && (
                        <Check className="h-4 w-4 text-emerald-500" />
                      )}
                      {!checkingHandle && handleAvailable === false && (
                        <X className="h-4 w-4 text-red-500" />
                      )}
                    </div>
                  </div>
                  {handle.length >= 3 && !checkingHandle && (
                    <p className={`text-xs ${handleAvailable ? "text-emerald-600" : "text-red-500"}`}>
                      {handleAvailable ? "اسم المستخدم متاح ✓" : "اسم المستخدم محجوز، جرب اسم آخر"}
                    </p>
                  )}
                </div>
              </>
            )}
            <div className="space-y-2">
              <Label htmlFor="email" className="text-right block">
                {isLogin ? "اسم المستخدم أو البريد الإلكتروني" : "البريد الإلكتروني"}
              </Label>
              <Input
                id="email"
                type={isLogin ? "text" : "email"}
                placeholder={isLogin ? "username أو example@email.com" : "example@email.com"}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="text-left"
                required
                data-testid="input-email"
                dir="ltr"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-right block">كلمة المرور</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="text-left pr-10"
                  required
                  minLength={6}
                  data-testid="input-password"
                  dir="ltr"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  data-testid="button-toggle-password"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            {!isLogin && (
              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-right block">تأكيد كلمة المرور</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="text-left"
                  required
                  minLength={6}
                  data-testid="input-confirm-password"
                  dir="ltr"
                />
                {confirmPassword && password !== confirmPassword && (
                  <p className="text-xs text-red-500">كلمات المرور غير متطابقة</p>
                )}
              </div>
            )}
            <Button
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              disabled={isSubmitting || (!isLogin && !handleAvailable)}
              data-testid="button-submit-auth"
            >
              {isSubmitting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : isLogin ? (
                "تسجيل الدخول"
              ) : (
                "إنشاء الحساب"
              )}
            </Button>
            {isLogin && !isForgotPassword && (
              <button
                type="button"
                onClick={() => setIsForgotPassword(true)}
                className="w-full mt-3 text-sm text-muted-foreground hover:text-emerald-600 transition-colors"
                data-testid="button-forgot-password"
              >
                نسيت كلمة المرور؟
              </button>
            )}
          </form>
          
          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-2 text-muted-foreground">أو</span>
              </div>
            </div>
            <div className="mt-4">
              <Button
                type="button"
                variant="outline"
                className="w-full bg-black hover:bg-gray-900 text-white border-black"
                onClick={() => {
                  window.location.href = "/api/auth/apple";
                }}
                data-testid="button-apple-signin"
              >
                <svg className="h-5 w-5 ml-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12.152 6.896c-.948 0-2.415-1.078-3.96-1.04-2.04.027-3.91 1.183-4.961 3.014-2.117 3.675-.546 9.103 1.519 12.09 1.013 1.454 2.208 3.09 3.792 3.039 1.52-.065 2.09-.987 3.935-.987 1.831 0 2.35.987 3.96.948 1.637-.026 2.676-1.48 3.676-2.948 1.156-1.688 1.636-3.325 1.662-3.415-.039-.013-3.182-1.221-3.22-4.857-.026-3.04 2.48-4.494 2.597-4.559-1.429-2.09-3.623-2.324-4.39-2.376-2-.156-3.675 1.09-4.61 1.09zM15.53 3.83c.843-1.012 1.4-2.427 1.245-3.83-1.207.052-2.662.805-3.532 1.818-.78.896-1.454 2.338-1.273 3.714 1.338.104 2.715-.688 3.559-1.701"/>
                </svg>
                {isLogin ? "تسجيل الدخول بـ Apple" : "التسجيل بـ Apple"}
              </Button>
            </div>
            {!isLogin && (
              <>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      setEmail(email.includes("@") ? email : email + "@icloud.com");
                    }}
                    data-testid="button-icloud-email"
                  >
                    <svg className="h-4 w-4 ml-2" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M13.527.099C6.955-.744.942 3.9.099 10.473c-.843 6.572 3.8 12.584 10.373 13.428 6.573.843 12.587-3.801 13.428-10.374C24.744 6.955 20.101.943 13.527.099zm2.471 7.485a.855.855 0 0 0-.593.25l-4.453 4.453-.978-.978a.856.856 0 0 0-1.212 1.212l1.584 1.584a.855.855 0 0 0 1.212 0l5.059-5.059a.856.856 0 0 0-.619-1.462z"/>
                    </svg>
                    iCloud
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      setEmail(email.includes("@") ? email : email + "@gmail.com");
                    }}
                    data-testid="button-gmail-email"
                  >
                    <svg className="h-4 w-4 ml-2" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M24 5.457v13.909c0 .904-.732 1.636-1.636 1.636h-3.819V11.73L12 16.64l-6.545-4.91v9.273H1.636A1.636 1.636 0 0 1 0 19.366V5.457c0-2.023 2.309-3.178 3.927-1.964L5.455 4.64 12 9.548l6.545-4.91 1.528-1.145C21.69 2.28 24 3.434 24 5.457z"/>
                    </svg>
                    Gmail
                  </Button>
                </div>
                <p className="text-xs text-center text-muted-foreground mt-2">
                  اضغط لإضافة نطاق البريد تلقائياً
                </p>
              </>
            )}
          </div>
          
          <div className="mt-6 text-center">
            <button
              onClick={switchMode}
              className="text-emerald-600 hover:text-emerald-700 text-sm font-medium"
              data-testid="button-switch-auth-mode"
            >
              {isLogin ? "ليس لديك حساب؟ إنشاء حساب جديد" : "لديك حساب بالفعل؟ تسجيل الدخول"}
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
