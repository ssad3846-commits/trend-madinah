import Layout from "@/components/layout/Layout";
import ComposeTweet from "@/components/feed/ComposeTweet";
import TweetCard from "@/components/feed/TweetCard";
import TrendList from "@/components/trends/TrendList";
import LocationSelector from "@/components/location/LocationSelector";
import { useLocationContext } from "@/lib/location-context";
import { tweetsApi, usersApi } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { Moon, Sun, Loader2, Search, BadgeCheck, UserPlus } from "lucide-react";
import { useTheme } from "next-themes";
import { useState } from "react";
import { Link } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth-context";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const { selectedLocation } = useLocationContext();
  const { theme, setTheme } = useTheme();
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: tweets = [], isLoading, error } = useQuery({
    queryKey: ['tweets', selectedLocation?.id],
    queryFn: () => tweetsApi.getTweets(selectedLocation?.id),
  });

  // Get hidden accounts to filter tweets
  const { data: hiddenAccounts = [] } = useQuery({
    queryKey: ['hiddenAccounts'],
    queryFn: () => usersApi.getHiddenAccounts(),
    enabled: isAuthenticated,
  });

  // Filter out tweets from hidden accounts
  const filteredTweets = isAuthenticated 
    ? tweets.filter(tweet => !hiddenAccounts.some(hidden => hidden.id === tweet.user.id))
    : tweets;

  const { data: searchedUsers = [], isLoading: usersLoading } = useQuery({
    queryKey: ['users-search-home', searchQuery],
    queryFn: () => usersApi.searchUsers(searchQuery),
    enabled: searchQuery.length >= 2,
  });

  // Suggested users when search box is focused but empty
  const { data: suggestedUsers = [] } = useQuery({
    queryKey: ['suggested-users'],
    queryFn: () => usersApi.searchUsers(""),
  });

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const FollowButton = ({ userId }: { userId: number }) => {
    const { data: isFollowing = false } = useQuery({
      queryKey: ["isFollowing", userId],
      queryFn: () => usersApi.isFollowing(userId),
      enabled: isAuthenticated,
    });

    const followMutation = useMutation({
      mutationFn: () => usersApi.followUser(userId),
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["isFollowing", userId] });
        queryClient.invalidateQueries({ queryKey: ["tweets"] });
        toast({
          title: isFollowing ? "تم إلغاء المتابعة" : "تمت المتابعة",
          description: isFollowing ? "لن تظهر تغريداته في صفحتك" : "ستظهر تغريداته في صفحتك الرئيسية",
        });
      },
      onError: (error: Error) => {
        toast({
          title: "خطأ",
          description: error.message,
          variant: "destructive",
        });
      },
    });

    if (!isAuthenticated) return null;

    return (
      <button
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          followMutation.mutate();
        }}
        disabled={followMutation.isPending}
        className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${
          isFollowing 
            ? "bg-muted text-foreground hover:bg-red-100 hover:text-red-600" 
            : "bg-primary text-primary-foreground hover:bg-primary/90"
        }`}
      >
        {isFollowing ? "إلغاء" : "متابعة"}
      </button>
    );
  };

  return (
    <Layout>
      {/* Sticky Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border/40 px-4 py-3 flex items-center justify-between">
         <div className="flex flex-col">
            <LocationSelector />
         </div>
         <button 
           onClick={toggleTheme}
           className="p-2 hover:bg-muted/50 rounded-full cursor-pointer transition-colors" 
           title={theme === "dark" ? "الوضع النهاري" : "الوضع الليلي"}
           data-testid="button-toggle-theme"
         >
           {theme === "dark" ? (
             <Sun size={20} className="text-primary" />
           ) : (
             <Moon size={20} className="text-primary" />
           )}
         </button>
      </header>

      {/* Search Users Box */}
      <div className="p-4 border-b border-border/40">
        <div className="relative">
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-muted-foreground">
            <Search size={18} />
          </div>
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setShowSearch(true);
            }}
            onFocus={() => setShowSearch(true)}
            onBlur={() => setTimeout(() => setShowSearch(false), 200)}
            placeholder="ابحث عن حسابات لمتابعتها..."
            className="w-full bg-muted/50 rounded-full py-2.5 pr-10 pl-4 focus:outline-none focus:ring-2 focus:ring-primary/20 border-none transition-all text-sm"
            data-testid="input-search-users"
          />
        </div>
        
        {/* Search Results or Suggestions */}
        {showSearch && (
          <div className="mt-3 bg-card rounded-xl border border-border/40 overflow-hidden">
            {searchQuery.length >= 2 ? (
              // Show search results
              usersLoading ? (
                <div className="flex justify-center py-4">
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                </div>
              ) : searchedUsers.length > 0 ? (
                <div className="divide-y divide-border/40">
                  {searchedUsers.slice(0, 5).map((user) => (
                    <Link 
                      key={user.id} 
                      href={`/user/${user.handle.replace('@', '')}`}
                      className="flex items-center gap-3 p-3 hover:bg-muted/50 transition-colors"
                    >
                      <img 
                        src={user.avatar} 
                        alt={user.name}
                        className="w-10 h-10 rounded-full object-cover border border-border"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="font-bold text-sm truncate">{user.name}</span>
                          {user.verified && (
                            <BadgeCheck size={14} className="text-primary fill-primary/20" />
                          )}
                        </div>
                        <span className="text-xs text-muted-foreground">{user.handle}</span>
                      </div>
                      <FollowButton userId={parseInt(user.id)} />
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 text-sm text-muted-foreground">
                  لا توجد نتائج
                </div>
              )
            ) : (
              // Show suggested accounts
              <>
                <div className="px-4 py-2 border-b border-border/40 bg-muted/30">
                  <span className="text-sm font-bold text-muted-foreground">حسابات مقترحة في المدينة</span>
                </div>
                <div className="divide-y divide-border/40">
                  {suggestedUsers.slice(0, 6).map((user) => (
                    <Link 
                      key={user.id} 
                      href={`/user/${user.handle.replace('@', '')}`}
                      className="flex items-center gap-3 p-3 hover:bg-muted/50 transition-colors"
                    >
                      <img 
                        src={user.avatar} 
                        alt={user.name}
                        className="w-10 h-10 rounded-full object-cover border border-border"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="font-bold text-sm truncate">{user.name}</span>
                          {user.verified && (
                            <BadgeCheck size={14} className="text-primary fill-primary/20" />
                          )}
                        </div>
                        <span className="text-xs text-muted-foreground">{user.handle}</span>
                      </div>
                      <FollowButton userId={parseInt(user.id)} />
                    </Link>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* Compose Tweet Area - Only for authenticated users */}
      {isAuthenticated ? (
        <div className="hidden sm:block">
          <ComposeTweet />
        </div>
      ) : (
        <div className="p-4 border-b border-border/40 bg-muted/30">
          <div className="flex items-center justify-center gap-3 py-3">
            <span className="text-muted-foreground text-sm">سجّل دخولك لمشاركة تغريداتك</span>
            <Link href="/auth" className="bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-2 rounded-full text-sm font-bold transition-colors">
              تسجيل الدخول
            </Link>
          </div>
        </div>
      )}

      {/* Feed */}
      <div className="pb-20 md:pb-0">
        {isLoading && (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        )}
        
        {error && (
          <div className="text-center py-8 text-muted-foreground">
            حدث خطأ في تحميل التغريدات
          </div>
        )}
        
        {!isLoading && !error && filteredTweets.map((tweet) => (
          <TweetCard key={tweet.id} tweet={tweet} />
        ))}
      </div>

      {/* Render Trends in the Portal defined in Layout */}
      <TrendList />
    </Layout>
  );
}
