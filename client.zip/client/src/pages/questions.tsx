import Layout from "@/components/layout/Layout";
import TrendList from "@/components/trends/TrendList";
import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { MessageCircle, Send, User, HelpCircle, Loader2, Search, X } from "lucide-react";
import { questionsApi } from "@/lib/api";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocationContext } from "@/lib/location-context";
import { useAuth } from "@/lib/auth-context";
import { Link } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function QuestionsPage() {
  const [questionText, setQuestionText] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const queryClient = useQueryClient();
  const { selectedLocation, locationId } = useLocationContext();
  const { isAuthenticated } = useAuth();
  
  const currentLocationName = selectedLocation?.name || "المملكة العربية السعودية";

  const { data: questions = [], isLoading } = useQuery({
    queryKey: ['questions'],
    queryFn: () => questionsApi.getQuestions(),
  });

  const filteredQuestions = useMemo(() => {
    if (!searchQuery.trim()) return questions;
    return questions.filter(q => 
      q.content.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [questions, searchQuery]);

  const createQuestionMutation = useMutation({
    mutationFn: questionsApi.createQuestion,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['questions'] });
      setQuestionText("");
    },
  });

  const handleAsk = () => {
    if (!questionText.trim()) return;
    createQuestionMutation.mutate({
      content: questionText,
      locationId: "all",
      locationName: currentLocationName,
    });
  };

  return (
    <Layout>
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border/40 px-4 py-3">
         <div className="flex items-center justify-between mb-3">
           <h1 className="font-bold text-xl flex items-center gap-2">
             <HelpCircle className="text-primary" />
             أسئلة واستفسارات
           </h1>
         </div>
         <div className="relative">
           <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-muted-foreground">
             <Search size={18} />
           </div>
           <input 
             type="text" 
             value={searchQuery}
             onChange={(e) => setSearchQuery(e.target.value)}
             placeholder="ابحث في الأسئلة..."
             className="w-full bg-muted/50 rounded-full py-2 pr-10 pl-10 focus:outline-none focus:ring-2 focus:ring-primary/20 border-none transition-all text-sm"
             data-testid="input-search-questions"
           />
           {searchQuery && (
             <button
               onClick={() => setSearchQuery("")}
               className="absolute inset-y-0 left-0 pl-3 flex items-center text-muted-foreground hover:text-foreground"
               data-testid="button-clear-search"
             >
               <X size={18} />
             </button>
           )}
         </div>
      </header>

      <div className="p-4">
        
        {/* Ask Box - Only for authenticated users */}
        {isAuthenticated ? (
          <div className="bg-card border border-border/60 rounded-xl p-4 mb-8 shadow-sm">
            <h2 className="font-bold text-lg mb-2">عندك استفسار عن {currentLocationName}؟</h2>
            <p className="text-sm text-muted-foreground mb-4">اسأل أهل المدينة وبيجاوبونك (اسمك سيظهر كـ "مجهول" للخصوصية)</p>
            
            <Textarea 
              placeholder="اكتب سؤالك هنا..." 
              className="resize-none min-h-[100px] mb-3 bg-muted/30 border-border/60 focus:border-primary"
              value={questionText}
              onChange={(e) => setQuestionText(e.target.value)}
            />
            
            <div className="flex justify-between items-center">
               <div className="text-xs text-muted-foreground flex items-center gap-1">
                 <User size={14} />
                 <span>سيتم النشر باسم: فاعل خير (مخفي)</span>
               </div>
               <Button onClick={handleAsk} disabled={!questionText.trim()} className="gap-2 font-bold rounded-full px-6">
                 إرسال
                 <Send size={16} />
               </Button>
            </div>
          </div>
        ) : (
          <div className="bg-muted/30 border border-border/60 rounded-xl p-4 mb-8">
            <div className="flex items-center justify-center gap-3 py-2">
              <span className="text-muted-foreground text-sm">سجّل دخولك لطرح سؤال</span>
              <Link href="/auth" className="bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-2 rounded-full text-sm font-bold transition-colors">
                تسجيل الدخول
              </Link>
            </div>
          </div>
        )}

        {/* Questions Feed */}
        <div className="space-y-6">
           <h3 className="font-bold text-lg px-2 border-r-4 border-primary/40">أحدث الأسئلة</h3>
           
           {isLoading && (
             <div className="flex justify-center items-center py-12">
               <Loader2 className="h-8 w-8 animate-spin text-primary" />
             </div>
           )}
           
           {!isLoading && filteredQuestions.map((q) => (
             <QuestionCard key={q.id} question={q} />
           ))}
           
           {!isLoading && filteredQuestions.length === 0 && searchQuery && (
             <div className="text-center py-12 text-muted-foreground">
               لا توجد نتائج للبحث عن "{searchQuery}"
             </div>
           )}
           
           {!isLoading && questions.length === 0 && !searchQuery && (
             <div className="text-center py-12 text-muted-foreground">
               لا توجد أسئلة في هذا الحي حالياً
             </div>
           )}
        </div>

      </div>

      {/* Sidebar Trends */}
      <TrendList />
    </Layout>
  );
}

function QuestionCard({ question }: { question: any }) {
  const [showAnswers, setShowAnswers] = useState(false);
  const [answerDialogOpen, setAnswerDialogOpen] = useState(false);
  const [answerText, setAnswerText] = useState("");
  const queryClient = useQueryClient();
  const { isAuthenticated } = useAuth();
  
  const { data: answers = [], isLoading } = useQuery({
    queryKey: ['answers', question.id],
    queryFn: () => questionsApi.getAnswers(parseInt(question.id)),
    enabled: showAnswers,
  });

  const createAnswerMutation = useMutation({
    mutationFn: (content: string) => questionsApi.createAnswer(parseInt(question.id), content),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['answers', question.id] });
      queryClient.invalidateQueries({ queryKey: ['questions'] });
      setAnswerText("");
      setAnswerDialogOpen(false);
    },
  });

  const handleSubmitAnswer = () => {
    if (!answerText.trim()) return;
    createAnswerMutation.mutate(answerText);
  };

  return (
    <div className="bg-card border border-border/40 rounded-xl overflow-hidden hover:border-primary/20 transition-colors">
      {/* Question Header */}
      <div className="p-4 pb-2">
        <div className="flex justify-between items-start mb-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
              <HelpCircle size={16} className="text-muted-foreground" />
            </div>
            <div>
              <p className="font-bold text-sm">سائل مجهول</p>
              <p className="text-xs text-muted-foreground">{question.timestamp} · {question.location}</p>
            </div>
          </div>
        </div>
        <p className="font-medium text-lg leading-relaxed">{question.content}</p>
      </div>

      {/* Answers Section */}
      <div className="bg-muted/30 p-4 border-t border-border/30">
        <div 
          className="flex items-center gap-2 mb-3 text-sm font-bold text-muted-foreground cursor-pointer hover:text-primary"
          onClick={() => setShowAnswers(!showAnswers)}
          data-testid={`button-toggle-answers-${question.id}`}
        >
          <MessageCircle size={16} />
          <span>الإجابات ({question.answersCount})</span>
        </div>
        
        {showAnswers && (
          <div className="space-y-3">
            {isLoading && (
              <div className="flex justify-center py-4">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
              </div>
            )}
            
            {!isLoading && answers.map((answer: any) => (
              <div key={answer.id} className="bg-background p-3 rounded-lg border border-border/30 shadow-sm text-sm">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-bold text-primary text-xs">جواب {answer.number}</span>
                  <span className="text-[10px] text-muted-foreground">{answer.timestamp}</span>
                </div>
                <p className="text-foreground/90">{answer.content}</p>
              </div>
            ))}
            
            {isAuthenticated ? (
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-full text-primary text-xs mt-2 hover:bg-primary/5"
                onClick={() => setAnswerDialogOpen(true)}
                data-testid={`button-add-answer-${question.id}`}
              >
                أضف إجابة...
              </Button>
            ) : (
              <Link href="/auth" className="block w-full text-center text-xs mt-2 py-2 text-muted-foreground hover:text-primary transition-colors">
                سجّل دخولك لإضافة إجابة
              </Link>
            )}
          </div>
        )}
      </div>

      {/* Add Answer Dialog */}
      <Dialog open={answerDialogOpen} onOpenChange={setAnswerDialogOpen}>
        <DialogContent className="sm:max-w-[425px]" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-right">أضف إجابتك</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm text-muted-foreground mb-3">
              السؤال: {question.content}
            </p>
            <Textarea
              placeholder="اكتب إجابتك هنا..."
              value={answerText}
              onChange={(e) => setAnswerText(e.target.value)}
              className="min-h-[120px] text-right"
              data-testid="input-answer-text"
            />
            <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
              <User size={12} />
              سيتم النشر باسم: فاعل خير (مخفي)
            </p>
          </div>
          <div className="flex justify-end gap-2">
            <Button 
              variant="outline" 
              onClick={() => setAnswerDialogOpen(false)}
              data-testid="button-cancel-answer"
            >
              إلغاء
            </Button>
            <Button 
              onClick={handleSubmitAnswer}
              disabled={!answerText.trim() || createAnswerMutation.isPending}
              data-testid="button-submit-answer"
            >
              {createAnswerMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  إرسال الإجابة
                  <Send size={14} className="mr-2" />
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
