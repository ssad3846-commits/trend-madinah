import { useState, useEffect, useRef } from "react";
import Layout from "@/components/layout/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/lib/auth-context";
import { useLocation } from "wouter";
import { Send, MapPin, Loader2, MessageCircle, AlertCircle, CheckCircle2 } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { chatApi } from "@/lib/api";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

interface GPSLocation {
  latitude: number;
  longitude: number;
}

export default function ChatPage() {
  const { isAuthenticated, isLoading: authLoading, user } = useAuth();
  const [, setLocation] = useLocation();
  const [message, setMessage] = useState("");
  const [gpsLocation, setGpsLocation] = useState<GPSLocation | null>(null);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [gpsLoading, setGpsLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const defaultLocation = { latitude: 24.4672, longitude: 39.6024 };
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setGpsLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
          setGpsLoading(false);
        },
        (error) => {
          setGpsLocation(defaultLocation);
          setGpsLoading(false);
        },
        { enableHighAccuracy: true, timeout: 5000 }
      );
    } else {
      setGpsLocation(defaultLocation);
      setGpsLoading(false);
    }
  }, []);

  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ["chat", gpsLocation?.latitude, gpsLocation?.longitude],
    queryFn: () =>
      gpsLocation
        ? chatApi.getMessages(gpsLocation.latitude, gpsLocation.longitude)
        : Promise.resolve([]),
    enabled: !!gpsLocation,
    refetchInterval: 5000,
  });

  const sendMessageMutation = useMutation({
    mutationFn: (content: string) =>
      chatApi.sendMessage(content, gpsLocation!.latitude, gpsLocation!.longitude),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["chat"] });
      setMessage("");
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (!message.trim() || !gpsLocation) return;
    sendMessageMutation.mutate(message);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (gpsLoading) {
    return (
      <Layout>
        <div className="flex-1 flex flex-col items-center justify-center min-h-[60vh] gap-4">
          <div className="relative">
            <MapPin className="w-16 h-16 text-primary animate-pulse" />
            <Loader2 className="w-8 h-8 text-muted-foreground animate-spin absolute -bottom-2 -right-2" />
          </div>
          <p className="text-lg text-muted-foreground">جاري تحديد موقعك...</p>
          <p className="text-sm text-muted-foreground/70">يرجى السماح بالوصول للموقع</p>
        </div>
      </Layout>
    );
  }

  if (gpsError) {
    return (
      <Layout>
        <div className="flex-1 flex flex-col items-center justify-center min-h-[60vh] gap-4">
          <AlertCircle className="w-16 h-16 text-destructive" />
          <p className="text-lg text-muted-foreground">{gpsError}</p>
          <Button onClick={() => window.location.reload()}>
            إعادة المحاولة
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="flex-1 flex flex-col h-[calc(100vh-120px)]">
        <div className="border-b border-border/40 p-4">
          <div className="flex items-center gap-3">
            <MessageCircle className="w-7 h-7 text-primary" />
            <div>
              <h1 className="text-xl font-bold">دردشة القريبين</h1>
              <p className="text-sm text-muted-foreground flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                تتحدث مع الأشخاص ضمن ١٠ كم منك
              </p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4" data-testid="chat-messages-container">
          {messagesLoading ? (
            <div className="flex items-center justify-center h-full">
              <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center gap-4">
              <MessageCircle className="w-16 h-16 text-muted-foreground/30" />
              <div>
                <p className="text-lg text-muted-foreground">لا توجد رسائل بعد</p>
                <p className="text-sm text-muted-foreground/70">كن أول من يبدأ المحادثة مع القريبين منك!</p>
              </div>
            </div>
          ) : (
            messages.map((msg) => {
              const isOwn = user?.id === msg.userId;
              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${isOwn ? "flex-row-reverse" : ""}`}
                  data-testid={`chat-message-${msg.id}`}
                >
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={msg.user.avatar} />
                    <AvatarFallback>{msg.user.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className={`max-w-[70%] ${isOwn ? "items-end" : "items-start"}`}>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-sm">{msg.user.name}</span>
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(msg.createdAt), {
                          addSuffix: true,
                          locale: ar,
                        })}
                      </span>
                    </div>
                    <Card
                      className={`p-3 ${
                        isOwn
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted"
                      }`}
                    >
                      <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                    </Card>
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {isAuthenticated ? (
          <div className="border-t border-border/40 p-4">
            <div className="flex gap-3">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="اكتب رسالتك..."
                className="flex-1"
                data-testid="input-chat-message"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!message.trim() || sendMessageMutation.isPending}
                data-testid="button-send-message"
              >
                {sendMessageMutation.isPending ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </Button>
            </div>
          </div>
        ) : (
          <div className="border-t border-border/40 p-4">
            <div className="text-center">
              <p className="text-muted-foreground mb-2">سجل دخولك للمشاركة في الدردشة</p>
              <Button onClick={() => setLocation("/auth")} data-testid="button-login-chat">
                تسجيل الدخول
              </Button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
