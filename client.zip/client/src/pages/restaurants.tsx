import Layout from "@/components/layout/Layout";
import TrendList from "@/components/trends/TrendList";
import { placesApi } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { Search, Utensils, Star, MapPin, ExternalLink, Filter, Coffee, Bed, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useMemo } from "react";
import { useLocationContext } from "@/lib/location-context";

type Category = "ALL" | "RESTAURANT" | "CAFE" | "HOTEL";

export default function RestaurantsPage() {
  const [selectedCategory, setSelectedCategory] = useState<Category>("ALL");
  const [searchQuery, setSearchQuery] = useState("");
  const { selectedLocation, locationId } = useLocationContext();
  
  const currentLocationName = selectedLocation?.name || "المملكة العربية السعودية";

  const { data: places = [], isLoading } = useQuery({
    queryKey: ['places', selectedCategory],
    queryFn: () => placesApi.getPlaces(
      undefined, 
      selectedCategory === "ALL" ? undefined : selectedCategory
    ),
  });

  const sortedItems = useMemo(() => {
    let filtered = [...places];
    if (searchQuery.trim()) {
      const query = searchQuery.trim().toLowerCase();
      filtered = filtered.filter(item => 
        item.name.toLowerCase().includes(query) ||
        item.cuisine?.toLowerCase().includes(query) ||
        item.location?.toLowerCase().includes(query)
      );
    }
    return filtered.sort((a, b) => b.rating - a.rating);
  }, [places, searchQuery]);
  
  const isFallback = false;

  return (
    <Layout>
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border/40 px-4 py-3 flex items-center justify-between">
         <div className="flex-1 max-w-xl relative mx-auto md:mx-0">
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-muted-foreground">
               <Search size={18} />
            </div>
            <input 
               type="text" 
               placeholder={`بحث في ${currentLocationName}...`}
               value={searchQuery}
               onChange={(e) => setSearchQuery(e.target.value)}
               className="w-full bg-muted/50 rounded-full py-2 pr-10 pl-4 focus:outline-none focus:ring-2 focus:ring-primary/20 border-none transition-all text-sm"
               data-testid="input-search-places"
            />
         </div>
      </header>

      <div className="p-4">
        
        {/* Google Maps Integration Banner */}
        <div className="mb-6 p-4 bg-blue-50 rounded-xl border border-blue-100 flex items-center justify-between group cursor-pointer hover:bg-blue-100/50 transition-colors">
           <div className="flex items-center gap-3">
              <div className="bg-white p-2 rounded-full text-blue-600 shadow-sm">
                 <img src="https://www.google.com/images/branding/product/ico/maps15_bnuw3a_32dp.ico" alt="Google Maps" className="w-6 h-6" />
              </div>
              <div>
                 <h3 className="font-bold text-sm text-blue-800">مدعوم بواسطة خرائط Google</h3>
                 <p className="text-xs text-blue-600/80">التقييمات والمواقع مأخوذة من خرائط Google مباشرة</p>
              </div>
           </div>
           <ExternalLink size={18} className="text-blue-500" />
        </div>

        {/* Category Pills */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2 scrollbar-none">
           <CategoryPill 
              active={selectedCategory === "ALL"} 
              onClick={() => setSelectedCategory("ALL")} 
              icon={<Filter size={16} />} 
              label="الكل" 
           />
           <CategoryPill 
              active={selectedCategory === "RESTAURANT"} 
              onClick={() => setSelectedCategory("RESTAURANT")} 
              icon={<Utensils size={16} />} 
              label="مطاعم" 
           />
           <CategoryPill 
              active={selectedCategory === "CAFE"} 
              onClick={() => setSelectedCategory("CAFE")} 
              icon={<Coffee size={16} />} 
              label="مقاهي" 
           />
           <CategoryPill 
              active={selectedCategory === "HOTEL"} 
              onClick={() => setSelectedCategory("HOTEL")} 
              icon={<Bed size={16} />} 
              label="فنادق" 
           />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between mb-6">
           <div className="flex items-center gap-2">
              {selectedCategory === "RESTAURANT" && <Utensils className="text-primary" />}
              {selectedCategory === "CAFE" && <Coffee className="text-primary" />}
              {selectedCategory === "HOTEL" && <Bed className="text-primary" />}
              {selectedCategory === "ALL" && <Utensils className="text-primary" />}
              
              <h2 className="text-xl font-bold">
                 {isFallback ? `مقترحات مميزة في المدينة المنورة` : `أفضل الخيارات في ${currentLocationName}`}
              </h2>
           </div>
        </div>
        
        {isFallback && (
          <div className="mb-6 bg-yellow-50 text-yellow-800 px-4 py-2 rounded-lg text-sm border border-yellow-100 flex items-center gap-2">
             <Star size={16} className="fill-yellow-500 text-yellow-500" />
             <span>لم نجد نتائج مسجلة بالتحديد في {currentLocationName} لهذا التصنيف، إليك أفضل خياراتنا في المدينة!</span>
          </div>
        )}

        {/* Loading State */}
        {isLoading && (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        )}

        {/* Items Grid */}
        {!isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           {sortedItems.length > 0 ? (
             sortedItems.map((item) => (
               <div key={item.id} className="group bg-card rounded-2xl overflow-hidden border border-border/40 shadow-sm hover:shadow-md hover:border-primary/30 transition-all flex flex-col animate-in fade-in zoom-in-95 duration-300">
                  {/* Image */}
                  <div className="relative h-48 overflow-hidden">
                     <img 
                        src={item.image} 
                        alt={item.name} 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                     />
                     <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-xs font-bold shadow-sm flex items-center gap-1">
                        <Star size={14} className="fill-yellow-400 text-yellow-400" />
                        <span>{item.rating}</span>
                        <span className="text-muted-foreground font-normal">({item.reviews})</span>
                     </div>
                     <div className="absolute top-3 left-3 bg-black/60 text-white backdrop-blur-sm px-2 py-1 rounded-lg text-[10px] font-bold shadow-sm">
                        {item.category === "RESTAURANT" ? "مطعم" : item.category === "CAFE" ? "مقهى" : "فندق"}
                     </div>
                  </div>

                  {/* Content */}
                  <div className="p-4 flex-1 flex flex-col">
                     <div className="flex justify-between items-start mb-2">
                        <h3 className="font-bold text-lg">{item.name}</h3>
                        <span className="text-sm font-medium text-muted-foreground bg-muted px-2 py-0.5 rounded">{item.priceRange}</span>
                     </div>
                     
                     <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                        <span>{item.cuisine}</span>
                        <span>·</span>
                        <div className="flex items-center gap-1 text-primary/80">
                           <MapPin size={14} />
                           <span>{item.location}</span>
                        </div>
                     </div>

                     <div className="mt-auto pt-3 border-t border-border/30 flex gap-2">
                        <Button 
                          className="flex-1 bg-primary/5 hover:bg-primary/10 text-primary border-none shadow-none"
                          onClick={() => window.open(`https://www.google.com/maps/search/${item.name}+${item.location}`, '_blank')}
                        >
                           عرض في الخريطة
                        </Button>
                     </div>
                  </div>
               </div>
             ))
           ) : (
             <div className="col-span-full text-center py-16 bg-muted/20 rounded-2xl border border-dashed border-border">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                   <Filter size={32} className="text-muted-foreground/50" />
                </div>
                <h3 className="text-lg font-bold mb-1">لا توجد نتائج</h3>
                <p className="text-muted-foreground">جرب تغيير التصنيف أو البحث في حي آخر</p>
                <Button 
                  variant="link" 
                  className="mt-2 text-primary"
                  onClick={() => setSelectedCategory("ALL")}
                >
                   عرض الكل
                </Button>
             </div>
           )}
          </div>
        )}
      </div>

      {/* Sidebar Trends */}
      <TrendList />
    </Layout>
  );
}

function CategoryPill({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={`
        flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold transition-all whitespace-nowrap
        ${active 
          ? 'bg-primary text-white shadow-md' 
          : 'bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground'
        }
      `}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}
