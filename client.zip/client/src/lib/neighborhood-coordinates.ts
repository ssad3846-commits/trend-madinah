export interface NeighborhoodCoords {
  id: string;
  name: string;
  lat: number;
  lng: number;
}

export const neighborhoodCoordinates: NeighborhoodCoords[] = [
  { id: "1", name: "منطقة الرياض", lat: 24.7136, lng: 46.6753 },
  { id: "2", name: "منطقة مكة المكرمة", lat: 21.4225, lng: 39.8262 },
  { id: "3", name: "منطقة المدينة المنورة", lat: 24.5247, lng: 39.5692 },
  { id: "4", name: "منطقة القصيم", lat: 26.3260, lng: 43.9750 },
  { id: "5", name: "المنطقة الشرقية", lat: 26.4207, lng: 50.0888 },
  { id: "6", name: "منطقة عسير", lat: 18.2164, lng: 42.5053 },
  { id: "7", name: "منطقة تبوك", lat: 28.3838, lng: 36.5550 },
  { id: "8", name: "منطقة حائل", lat: 27.5219, lng: 41.6907 },
  { id: "9", name: "منطقة الحدود الشمالية", lat: 30.9753, lng: 41.0182 },
  { id: "10", name: "منطقة جازان", lat: 16.8892, lng: 42.5706 },
  { id: "11", name: "منطقة نجران", lat: 17.4922, lng: 44.1277 },
  { id: "12", name: "منطقة الباحة", lat: 20.0129, lng: 41.4677 },
  { id: "13", name: "منطقة الجوف", lat: 29.8866, lng: 40.0992 },
];

export const SAUDI_CENTER = { lat: 23.8859, lng: 45.0792 };

export function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

export function findNearestNeighborhood(lat: number, lng: number): NeighborhoodCoords | null {
  let nearest: NeighborhoodCoords | null = null;
  let minDistance = Infinity;
  
  for (const neighborhood of neighborhoodCoordinates) {
    const distance = calculateDistance(lat, lng, neighborhood.lat, neighborhood.lng);
    if (distance < minDistance) {
      minDistance = distance;
      nearest = neighborhood;
    }
  }
  
  if (minDistance > 500) {
    return null;
  }
  
  return nearest;
}
