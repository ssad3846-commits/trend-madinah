import { Tweet, Trend, Neighborhood, Restaurant, Question } from "./types";

export const QUESTIONS: Question[] = [
  {
    id: "1",
    content: "يا أهل المدينة، وين ألقى أفضل محل يبيع تمور عجوة أصلية وبسعر معقول؟",
    timestamp: "منذ ساعتين",
    location: "السوق المركزي",
    answers: [
      { id: "a1", content: "سوق التمور المركزي مليان، بس انتبه وأنا أخوك لازم تذوق قبل تشتري. فيه محل اسمه 'تمور طيبة' ممتاز.", timestamp: "منذ ساعة" },
      { id: "a2", content: "روحي لمزارع العالية، يبيعون لك من المزرعة مباشرة وجديد.", timestamp: "منذ 45 دقيقة" }
    ]
  },
  {
    id: "2",
    content: "أحتاج سباك شاطر وأمين في حي العزيزية، عندي تهريب موية وما عرفت له.",
    timestamp: "منذ ٥ ساعات",
    location: "العزيزية",
    answers: [
      { id: "a3", content: "فيه واحد باكستاني اسمه محمد، شغله نظيف وسعره طيب. هذا رقمه...", timestamp: "منذ 3 ساعات" }
    ]
  },
  {
    id: "3",
    content: "متى مواعيد زيارة الروضة الشريفة للنساء هالأيام؟",
    timestamp: "منذ ٦ ساعات",
    location: "المسجد النبوي",
    answers: [
      { id: "a4", content: "لازم حجز عن طريق تطبيق نسك، المواعيد تفتح كل يوم جمعة الظهر عادة.", timestamp: "منذ ٥ ساعات" },
      { id: "a5", content: "صح تطبيق نسك، بس ترا الزحمة خفت هالأيام يمديك تحصلين حجز بسهولة.", timestamp: "منذ ساعتين" }
    ]
  },
  {
    id: "4",
    content: "وش رايكم في مدرسة المنارات الأهلية؟ تنصحون فيها لأولى ابتدائي؟",
    timestamp: "منذ يوم",
    location: "سلطانة",
    answers: [
      { id: "a6", content: "ممتازة جداً وتأسيسهم قوي، عيالي فيها.", timestamp: "منذ ٢٠ ساعة" }
    ]
  }
];

export const RESTAURANTS: Restaurant[] = [
  {
    id: "1",
    name: "مطعم التراث المديني",
    rating: 4.8,
    reviews: 1250,
    cuisine: "شعبي / سعودي",
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&h=400&fit=crop",
    location: "سلطانة",
    locationId: "4",
    priceRange: "$$",
    googleMapsUrl: "https://goo.gl/maps/example1",
    category: "RESTAURANT"
  },
  {
    id: "2",
    name: "ستيك هاوس المدينة",
    rating: 4.5,
    reviews: 890,
    cuisine: "غربي / ستيك",
    image: "https://images.unsplash.com/photo-1544025162-d76694265947?w=600&h=400&fit=crop",
    location: "العالية مول - الحديقة",
    locationId: "30",
    priceRange: "$$$",
    category: "RESTAURANT"
  },
  {
    id: "3",
    name: "بيتزا نابولي",
    rating: 4.2,
    reviews: 560,
    cuisine: "إيطالي",
    image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=600&h=400&fit=crop",
    location: "العزيزية",
    locationId: "1",
    priceRange: "$$",
    category: "RESTAURANT"
  },
  {
    id: "4",
    name: "شاورما الطازج",
    rating: 4.7,
    reviews: 3200,
    cuisine: "وجبات سريعة",
    image: "https://images.unsplash.com/photo-1529042410759-befb1204b468?w=600&h=400&fit=crop",
    location: "الخالدية",
    locationId: "2",
    priceRange: "$",
    category: "RESTAURANT"
  },
  {
    id: "5",
    name: "مطعم البحار",
    rating: 4.0,
    reviews: 430,
    cuisine: "مأكولات بحرية",
    image: "https://images.unsplash.com/photo-1565689157206-0fddef7589a2?w=600&h=400&fit=crop",
    location: "طريق الهجرة",
    locationId: "58",
    priceRange: "$$$",
    category: "RESTAURANT"
  },
  {
    id: "6",
    name: "كافيه ومحمصة القمة",
    rating: 4.9,
    reviews: 150,
    cuisine: "قهوة مختصة",
    image: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=600&h=400&fit=crop",
    location: "قباء",
    locationId: "5",
    priceRange: "$$",
    category: "CAFE"
  },
  {
    id: "7",
    name: "برجر فاكتوري",
    rating: 4.4,
    reviews: 670,
    cuisine: "برجر",
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&h=400&fit=crop",
    location: "العزيزية",
    locationId: "1",
    priceRange: "$$",
    category: "RESTAURANT"
  },
  {
    id: "8",
    name: "مطعم بخاري المدينة",
    rating: 4.6,
    reviews: 2100,
    cuisine: "شعبي / بخاري",
    image: "https://images.unsplash.com/photo-1594041680534-e8c8cdebd659?w=600&h=400&fit=crop",
    location: "سيد الشهداء",
    locationId: "60",
    priceRange: "$",
    category: "RESTAURANT"
  },
  // New Cafes
  {
    id: "9",
    name: "ستاربكس",
    rating: 4.3,
    reviews: 5400,
    cuisine: "قهوة",
    image: "https://images.unsplash.com/photo-1559925393-8be0ec4767c8?w=600&h=400&fit=crop",
    location: "سلطانة",
    locationId: "4",
    priceRange: "$$",
    category: "CAFE"
  },
  {
    id: "10",
    name: "دوز كافيه",
    rating: 4.5,
    reviews: 320,
    cuisine: "قهوة مختصة",
    image: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=600&h=400&fit=crop",
    location: "العالية مول",
    locationId: "30",
    priceRange: "$$",
    category: "CAFE"
  },
  // New Hotels
  {
    id: "11",
    name: "فندق دار التقوى",
    rating: 4.9,
    reviews: 1200,
    cuisine: "فندق 5 نجوم",
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600&h=400&fit=crop",
    location: "المنطقة المركزية",
    locationId: "all", // Near Haram, generally applicable
    priceRange: "$$$$",
    category: "HOTEL"
  },
  {
    id: "12",
    name: "فندق ماريوت المدينة",
    rating: 4.6,
    reviews: 890,
    cuisine: "فندق 5 نجوم",
    image: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=600&h=400&fit=crop",
    location: "الدائري الثاني",
    locationId: "18", // King Fahd Dist usually
    priceRange: "$$$",
    category: "HOTEL"
  },
   {
    id: "13",
    name: "فندق بولمان زمزم",
    rating: 4.7,
    reviews: 2500,
    cuisine: "فندق 5 نجوم",
    image: "https://images.unsplash.com/photo-1582719508461-905c673771fd?w=600&h=400&fit=crop",
    location: "باب السلام",
    locationId: "all",
    priceRange: "$$$$",
    category: "HOTEL"
  }
];

export const NEIGHBORHOODS: Neighborhood[] = [
  { id: "all", name: "المدينة المنورة" }, 
  { id: "1", name: "العزيزية" },
  { id: "2", name: "الخالدية" },
  { id: "3", name: "العوالي" },
  { id: "4", name: "سلطانة" },
  { id: "5", name: "قباء" },
  { id: "6", name: "الحرة الشرقية" },
  { id: "7", name: "الحرة الغربية" },
  { id: "8", name: "باقدو" },
  { id: "9", name: "الفيصلية" },
  { id: "10", name: "أبيار علي" },
  { id: "11", name: "الأغوات" },
  { id: "12", name: "باب المجيدي" },
  { id: "13", name: "الساحة" },
  { id: "14", name: "باب الشامي" },
  { id: "15", name: "التاجوري" },
  { id: "16", name: "الحرة الشمالية" },
  { id: "17", name: "الربوة" },
  { id: "18", name: "الملك فهد" },
  { id: "19", name: "المطار" },
  { id: "20", name: "المستراح" },
  { id: "21", name: "البدراني" },
  { id: "22", name: "الجصة" },
  { id: "23", name: "الإسكان" },
  { id: "24", name: "العصيفرين" },
  { id: "25", name: "البركة" },
  { id: "26", name: "الجابرة" },
  { id: "27", name: "الجامعة" },
  { id: "28", name: "الجماوات" },
  { id: "29", name: "الجمعة" },
  { id: "30", name: "الحديقة" },
  { id: "31", name: "الختم" },
  { id: "32", name: "الدار" },
  { id: "33", name: "الدويخلة" },
  { id: "34", name: "الدويمة" },
  { id: "35", name: "الرانوناء" },
  { id: "36", name: "الراية" },
  { id: "37", name: "الروابي" },
  { id: "38", name: "الزهراء" },
  { id: "39", name: "السد" },
  { id: "40", name: "السقيا" },
  { id: "41", name: "السلام" },
  { id: "42", name: "الصيح" },
  { id: "43", name: "الشريبات" },
  { id: "44", name: "الظاهرة" },
  { id: "45", name: "العريض" },
  { id: "46", name: "العصبة" },
  { id: "47", name: "العنابس" },
  { id: "48", name: "الإهن" },
  { id: "49", name: "العيون" },
  { id: "50", name: "الفتح" },
  { id: "51", name: "القبلتين" },
  { id: "52", name: "القصواء" },
  { id: "53", name: "القلعة" },
  { id: "54", name: "المبعوث" },
  { id: "55", name: "المصانع" },
  { id: "56", name: "المغيسلة" },
  { id: "57", name: "المناخة" },
  { id: "58", name: "الهجرة" },
  { id: "59", name: "الدعيثة" },
  { id: "60", name: "سيد الشهداء" },
];

export const TRENDS: Trend[] = [
  { id: "1", rank: 1, hashtag: "#امطار_المدينة", posts: "٥٠.٢ ألف", category: "طقس" },
  { id: "2", rank: 2, hashtag: "#المسجد_النبوي", posts: "٣٢.١ ألف", category: "ديني" },
  { id: "3", rank: 3, hashtag: "#فعاليات_المدينة", posts: "١٥.٤ ألف", category: "ترفيه" },
  { id: "4", rank: 4, hashtag: "#مطاعم_المدينة", posts: "١٠.٢ ألف", category: "لايف ستايل" },
  { id: "5", rank: 5, hashtag: "#الخالدية", posts: "٨.٥ ألف", category: "أحياء", locationId: "2" }, // Khalidiya
  { id: "6", rank: 6, hashtag: "#العزيزية_الآن", posts: "٥.٣ ألف", category: "أحياء", locationId: "1" }, // Aziziyah
  { id: "7", rank: 7, hashtag: "#زحمة_الدائري", posts: "٤.١ ألف", category: "مرور" },
  { id: "8", rank: 8, hashtag: "#سلطانة", posts: "٣.٩ ألف", category: "أحياء", locationId: "4" }, // Sultana
  { id: "9", rank: 9, hashtag: "#حديقة_الملك_فهد", posts: "٣.٢ ألف", category: "أماكن", locationId: "30" }, // Al-Hadiqah/King Fahd Park usually near specific area
  { id: "10", rank: 10, hashtag: "#قباء", posts: "٢.٨ ألف", category: "أحياء", locationId: "5" }, // Quba
  { id: "11", rank: 11, hashtag: "#العوالي_بارك", posts: "٢.١ ألف", category: "أماكن", locationId: "3" }, // Awali
  { id: "12", rank: 12, hashtag: "#جامعة_طيبة", posts: "٢٠.٥ ألف", category: "تعليم", locationId: "27" }, // Al-Jamiah
];

export const TWEETS: Tweet[] = [
  {
    id: "1",
    user: {
      id: "u1",
      name: "أحمد المدني",
      handle: "@ahmed_madani",
      avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100&h=100&fit=crop",
      verified: true,
    },
    content: "صباح الخير من مدينة رسول الله ﷺ. الأجواء اليوم خيالية في ممشى الهجرة! 🌧️🍃 #امطار_المدينة",
    image: "https://images.unsplash.com/photo-1565552629477-bc872752b924?w=600&h=400&fit=crop",
    likes: 1240,
    replies: 45,
    retweets: 230,
    timestamp: "منذ ساعتين",
    location: "ممشى الهجرة"
  },
  {
    id: "2",
    user: {
      id: "u2",
      name: "دليل المدينة",
      handle: "@madinah_guide",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop",
      verified: true,
    },
    content: "تم افتتاح الفرع الجديد لمقهى القبة في شارع سلطانة. الديكور يجمع بين التراث والحداثة. ☕✨ #مطاعم_المدينة",
    likes: 856,
    replies: 120,
    retweets: 560,
    timestamp: "منذ ٤ ساعات",
    location: "سلطانة"
  },
  {
    id: "3",
    user: {
      id: "u3",
      name: "سارة الحربي",
      handle: "@sara_alharbi",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    },
    content: "هل فيه احد يعرف متى تبدأ فعاليات حديقة الملك فهد؟ 🎡",
    likes: 45,
    replies: 12,
    retweets: 5,
    timestamp: "منذ ٥ ساعات",
    location: "حديقة الملك فهد"
  },
  {
    id: "4",
    user: {
      id: "u4",
      name: "عبدالله",
      handle: "@abdullah_99",
      avatar: "https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100&h=100&fit=crop",
    },
    content: "زحمة مو طبيعية في الدائري الثاني اليوم 🚗🚗",
    likes: 210,
    replies: 34,
    retweets: 12,
    timestamp: "منذ ٦ ساعات",
    location: "الدائري الثاني"
  },
  {
    id: "5",
    user: {
      id: "u5",
      name: "أخبار المدينة",
      handle: "@MadinahNews",
      avatar: "https://images.unsplash.com/photo-1589309736404-2e142a2acdf0?w=100&h=100&fit=crop",
      verified: true,
    },
    content: "عاجل: افتتاح مشروع حديقة الملك فهد بعد التطوير رسمياً اليوم. #المدينة_المنورة #مشاريع_المدينة",
    image: "https://images.unsplash.com/photo-1596895111956-bf1cf0599ce5?w=600&h=400&fit=crop",
    likes: 5430,
    replies: 340,
    retweets: 1200,
    timestamp: "منذ ساعة",
    location: "حديقة الملك فهد"
  },
  {
    id: "6",
    user: {
      id: "u6",
      name: "عشاق العزيزية",
      handle: "@AziziahLovers",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop",
    },
    content: "أجمل غروب شمس ممكن تشوفه اليوم في العزيزية 😍 #العزيزية",
    likes: 230,
    replies: 15,
    retweets: 45,
    timestamp: "منذ ٣ ساعات",
    location: "العزيزية"
  },
  {
    id: "7",
    user: {
      id: "u7",
      name: "سعد الجهني",
      handle: "@saad_j",
      avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop",
    },
    content: "زحمة عند دوار القبلتين يا جماعة انتبهوا 🛑",
    likes: 120,
    replies: 40,
    retweets: 30,
    timestamp: "منذ ٣٠ دقيقة",
    location: "القبلتين"
  },
  {
    id: "8",
    user: {
      id: "u8",
      name: "كافيهات المدينة",
      handle: "@MadinahCafes",
      avatar: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=100&h=100&fit=crop",
    },
    content: "تجربتنا اليوم في كافيه جديد في ممشى الهجرة.. القهوة تفوز! ☕️👌 #مطاعم_المدينة",
    likes: 670,
    replies: 55,
    retweets: 110,
    timestamp: "منذ ٥ ساعات",
    location: "ممشى الهجرة"
  },
  {
    id: "9",
    user: {
      id: "u9",
      name: "بندر الحربي",
      handle: "@bandar_h",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    },
    content: "حي الخالدية يحتاج اهتمام أكثر بالإنارة في الشوارع الفرعية 💡",
    likes: 89,
    replies: 22,
    retweets: 10,
    timestamp: "منذ ٨ ساعات",
    location: "الخالدية"
  },
  {
    id: "10",
    user: {
      id: "u10",
      name: "فعاليات طيبة",
      handle: "@TaibahEvents",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    },
    content: "لا تفوتكم فعالية الرسم الحر في حديقة الملك فهد الليلة 🎨🖌️",
    likes: 340,
    replies: 28,
    retweets: 67,
    timestamp: "منذ ساعتين",
    location: "حديقة الملك فهد"
  }
];
