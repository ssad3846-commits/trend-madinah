export interface User {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  verified?: boolean;
}

export interface Tweet {
  id: string;
  user: User;
  content: string;
  image?: string;
  likes: number;
  replies: number;
  retweets: number;
  timestamp: string;
  location: string;
  locationId: string;
}

export interface Restaurant {
  id: string;
  name: string;
  rating: number;
  reviews: number;
  cuisine: string;
  image: string;
  location: string;
  locationId: string; // Link to neighborhood
  priceRange: string; // e.g., "$", "$$", "$$$"
  googleMapsUrl?: string;
  category: "RESTAURANT" | "CAFE" | "HOTEL"; // Added category
}

export interface Trend {
  id: string;
  rank: number;
  hashtag: string;
  posts: string;
  category?: string;
}

export interface Question {
  id: string;
  content: string;
  timestamp: string;
  answers: Answer[];
  location?: string;
}

export interface Answer {
  id: string;
  content: string;
  timestamp: string;
}

export interface Neighborhood {
  id: string;
  name: string;
}
