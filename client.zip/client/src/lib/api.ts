// API client for backend communication

export interface ApiUser {
  id: number;
  name: string;
  handle: string;
  avatar: string;
  cover?: string | null;
  bio?: string | null;
  location?: string | null;
  website?: string | null;
  twitter?: string | null;
  snapchat?: string | null;
  tiktok?: string | null;
  linkedin?: string | null;
  verified?: boolean | null;
  following: number;
  followers: number;
  joinedAt: string;
  createdAt: string;
}

export interface ApiTweet {
  id: number;
  userId: number;
  content: string;
  image?: string | null;
  likes: number;
  replies: number;
  retweets: number;
  locationId?: string | null;
  locationName?: string | null;
  createdAt: string;
  user: ApiUser;
}

export interface ApiQuestion {
  id: number;
  content: string;
  locationId?: string | null;
  locationName?: string | null;
  answersCount: number;
  createdAt: string;
}

export interface ApiAnswer {
  id: number;
  questionId: number;
  content: string;
  createdAt: string;
}

export interface ApiPlace {
  id: number;
  name: string;
  rating: number;
  reviews: number;
  cuisine: string;
  image: string;
  locationId?: string | null;
  locationName?: string | null;
  priceRange: string;
  googleMapsUrl?: string | null;
  category: string;
  createdAt: string;
}

export interface ApiTrend {
  id: number;
  rank: number;
  hashtag: string;
  posts: string;
  category?: string | null;
  locationId?: string | null;
  createdAt: string;
}

export interface ApiNeighborhood {
  id: string;
  name: string;
}

export interface ApiEvent {
  id: number;
  title: string;
  description: string;
  image?: string | null;
  locationId?: string | null;
  locationName?: string | null;
  address?: string | null;
  eventDate: string;
  eventTime?: string | null;
  category: string;
  organizer?: string | null;
  userId?: number | null;
  attendees: number;
  interested: number;
  isApproved: boolean;
  createdAt: string;
}

// Helper to get relative time in Arabic
function getRelativeTime(date: Date): string {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 60) {
    return diffMins <= 1 ? "منذ دقيقة" : `منذ ${diffMins} دقيقة`;
  } else if (diffHours < 24) {
    return diffHours === 1 ? "منذ ساعة" : `منذ ${diffHours} ساعات`;
  } else if (diffDays === 1) {
    return "منذ يوم";
  } else {
    return `منذ ${diffDays} أيام`;
  }
}

// Convert API user to frontend user
function convertUser(apiUser: ApiUser) {
  return {
    id: apiUser.id.toString(),
    name: apiUser.name,
    handle: `@${apiUser.handle}`,
    avatar: apiUser.avatar,
    verified: apiUser.verified || false,
    bio: apiUser.bio || undefined,
    location: apiUser.location || undefined,
    website: apiUser.website || undefined,
    twitter: apiUser.twitter || undefined,
    snapchat: apiUser.snapchat || undefined,
    tiktok: apiUser.tiktok || undefined,
    linkedin: apiUser.linkedin || undefined,
    cover: apiUser.cover || undefined,
    following: apiUser.following,
    followers: apiUser.followers,
    joinedAt: new Date(apiUser.joinedAt).toLocaleDateString("ar-SA"),
  };
}

// Tweets API
export const tweetsApi = {
  async getTweets(locationId?: string) {
    const url = locationId
      ? `/api/tweets?locationId=${locationId}`
      : "/api/tweets";
    const response = await fetch(url);
    if (!response.ok) throw new Error("Failed to fetch tweets");
    const data: ApiTweet[] = await response.json();
    
    return data.map((tweet) => ({
      id: tweet.id.toString(),
      user: convertUser(tweet.user),
      content: tweet.content,
      image: tweet.image || undefined,
      likes: tweet.likes,
      replies: tweet.replies,
      retweets: tweet.retweets,
      timestamp: getRelativeTime(new Date(tweet.createdAt)),
      location: tweet.locationName || "المدينة المنورة",
      locationId: tweet.locationId || "all",
    }));
  },

  async getTweet(id: number) {
    const response = await fetch(`/api/tweets/${id}`);
    if (!response.ok) throw new Error("Failed to fetch tweet");
    const tweet: ApiTweet = await response.json();
    
    return {
      id: tweet.id.toString(),
      user: convertUser(tweet.user),
      content: tweet.content,
      image: tweet.image || undefined,
      likes: tweet.likes,
      replies: tweet.replies,
      retweets: tweet.retweets,
      timestamp: getRelativeTime(new Date(tweet.createdAt)),
      location: tweet.locationName || "المدينة المنورة",
      locationId: tweet.locationId || "all",
    };
  },

  async createTweet(data: {
    content: string;
    locationId?: string;
    locationName?: string;
    image?: string;
  }) {
    const response = await fetch("/api/tweets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) {
      if (response.status === 401) throw new Error("يجب تسجيل الدخول");
      throw new Error("Failed to create tweet");
    }
    return response.json();
  },

  async likeTweet(id: number): Promise<{ tweet: any; liked: boolean }> {
    const response = await fetch(`/api/tweets/${id}/like`, {
      method: "POST",
    });
    if (!response.ok) {
      if (response.status === 401) throw new Error("يجب تسجيل الدخول");
      throw new Error("Failed to like tweet");
    }
    return response.json();
  },

  async retweetTweet(id: number): Promise<{ tweet: any; retweeted: boolean }> {
    const response = await fetch(`/api/tweets/${id}/retweet`, {
      method: "POST",
    });
    if (!response.ok) {
      if (response.status === 401) throw new Error("يجب تسجيل الدخول");
      throw new Error("Failed to retweet");
    }
    return response.json();
  },

  async getReplies(tweetId: number) {
    const response = await fetch(`/api/tweets/${tweetId}/replies`);
    if (!response.ok) throw new Error("Failed to fetch replies");
    return response.json();
  },

  async createReply(tweetId: number, content: string) {
    const response = await fetch(`/api/tweets/${tweetId}/replies`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content }),
    });
    if (!response.ok) {
      if (response.status === 401) throw new Error("يجب تسجيل الدخول للرد");
      throw new Error("Failed to create reply");
    }
    return response.json();
  },

  async getTweetStatus(tweetIds: number[]): Promise<{
    likes: { tweetId: number; liked: boolean }[];
    retweets: { tweetId: number; retweeted: boolean }[];
  }> {
    const response = await fetch("/api/tweets/status", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tweetIds }),
    });
    if (!response.ok) throw new Error("Failed to get tweet status");
    return response.json();
  },
};

// Questions API
export const questionsApi = {
  async getQuestions(locationId?: string) {
    const url = locationId
      ? `/api/questions?locationId=${locationId}`
      : "/api/questions";
    const response = await fetch(url);
    if (!response.ok) throw new Error("Failed to fetch questions");
    const data: ApiQuestion[] = await response.json();
    
    return data.map((q) => ({
      id: q.id.toString(),
      content: q.content,
      timestamp: getRelativeTime(new Date(q.createdAt)),
      location: q.locationName || "المدينة المنورة",
      answersCount: q.answersCount,
    }));
  },

  async getAnswers(questionId: number) {
    const response = await fetch(`/api/questions/${questionId}/answers`);
    if (!response.ok) throw new Error("Failed to fetch answers");
    const data: ApiAnswer[] = await response.json();
    
    return data.map((a, index) => ({
      id: a.id.toString(),
      content: a.content,
      timestamp: getRelativeTime(new Date(a.createdAt)),
      number: index + 1,
    }));
  },

  async createQuestion(data: {
    content: string;
    locationId?: string;
    locationName?: string;
  }) {
    const response = await fetch("/api/questions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Failed to create question");
    return response.json();
  },

  async createAnswer(questionId: number, content: string) {
    const response = await fetch(`/api/questions/${questionId}/answers`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content }),
    });
    if (!response.ok) throw new Error("Failed to create answer");
    return response.json();
  },
};

// Places API
export const placesApi = {
  async getPlaces(locationId?: string, category?: string) {
    const params = new URLSearchParams();
    if (locationId) params.append("locationId", locationId);
    if (category) params.append("category", category);
    
    const url = params.toString()
      ? `/api/places?${params.toString()}`
      : "/api/places";
    
    const response = await fetch(url);
    if (!response.ok) throw new Error("Failed to fetch places");
    const data: ApiPlace[] = await response.json();
    
    return data.map((p) => ({
      id: p.id.toString(),
      name: p.name,
      rating: p.rating,
      reviews: p.reviews,
      cuisine: p.cuisine,
      image: p.image,
      location: p.locationName || "المدينة المنورة",
      locationId: p.locationId || "all",
      priceRange: p.priceRange,
      googleMapsUrl: p.googleMapsUrl || undefined,
      category: p.category,
    }));
  },
};

// Trends API
export const trendsApi = {
  async getTrends(locationId?: string, limit?: number) {
    const params = new URLSearchParams();
    if (locationId) params.append("locationId", locationId);
    if (limit) params.append("limit", limit.toString());
    
    const url = params.toString()
      ? `/api/trends?${params.toString()}`
      : "/api/trends";
    
    const response = await fetch(url);
    if (!response.ok) throw new Error("Failed to fetch trends");
    const data: ApiTrend[] = await response.json();
    
    return data.map((t) => ({
      id: t.id.toString(),
      rank: t.rank,
      hashtag: t.hashtag,
      posts: t.posts,
      category: t.category || undefined,
    }));
  },
  
  async getTwitterTrends() {
    const response = await fetch("/api/twitter/trends");
    if (!response.ok) throw new Error("Failed to fetch Twitter trends");
    const data: { hashtag: string; posts: string; rank: number }[] = await response.json();
    return data.map((t) => ({
      id: `twitter-${t.rank}`,
      rank: t.rank,
      hashtag: t.hashtag,
      posts: t.posts,
      category: "تويتر",
    }));
  },
};

// Neighborhoods API
export const neighborhoodsApi = {
  async getNeighborhoods() {
    const response = await fetch("/api/neighborhoods");
    if (!response.ok) throw new Error("Failed to fetch neighborhoods");
    const data: ApiNeighborhood[] = await response.json();
    return data;
  },
  async getEngagement() {
    const response = await fetch("/api/neighborhoods/engagement");
    if (!response.ok) throw new Error("Failed to fetch engagement");
    const data: { locationId: string; engagement: number }[] = await response.json();
    return data;
  },
};

// Live Cameras API
export interface LiveCamera {
  id: number;
  name: string;
  description: string | null;
  category: string;
  locationId: string | null;
  locationName: string | null;
  sourceType: string;
  embedUrl: string;
  thumbnailUrl: string | null;
  isOfficial: boolean | null;
  isLive: boolean | null;
  viewerCount: number | null;
  createdAt: string;
}

export const camerasApi = {
  async getCameras(locationId?: string, category?: string) {
    const params = new URLSearchParams();
    if (locationId) params.append("locationId", locationId);
    if (category) params.append("category", category);
    const url = params.toString() ? `/api/cameras?${params.toString()}` : "/api/cameras";
    const response = await fetch(url);
    if (!response.ok) throw new Error("Failed to fetch cameras");
    const data: LiveCamera[] = await response.json();
    return data;
  },
  async getCameraById(id: number) {
    const response = await fetch(`/api/cameras/${id}`);
    if (!response.ok) throw new Error("Failed to fetch camera");
    const data: LiveCamera = await response.json();
    return data;
  },
};

// Users API
export const usersApi = {
  async searchUsers(query: string) {
    const response = await fetch(`/api/users/search?q=${encodeURIComponent(query)}`);
    if (!response.ok) throw new Error("Failed to search users");
    const data: ApiUser[] = await response.json();
    return data.map(convertUser);
  },

  async getUser(id: number) {
    const response = await fetch(`/api/users/${id}`);
    if (!response.ok) throw new Error("Failed to fetch user");
    const data: ApiUser = await response.json();
    return convertUser(data);
  },

  async getUserByHandle(handle: string) {
    const response = await fetch(`/api/users/handle/${handle}`);
    if (!response.ok) throw new Error("Failed to fetch user");
    const data: ApiUser = await response.json();
    return convertUser(data);
  },

  async getUserTweets(userId: number) {
    const response = await fetch(`/api/users/${userId}/tweets`);
    if (!response.ok) throw new Error("Failed to fetch user tweets");
    const data: ApiTweet[] = await response.json();
    
    return data.map((tweet) => ({
      id: tweet.id.toString(),
      content: tweet.content,
      image: tweet.image || undefined,
      likes: tweet.likes,
      replies: tweet.replies,
      retweets: tweet.retweets,
      timestamp: getRelativeTime(new Date(tweet.createdAt)),
      location: tweet.locationName || "المدينة المنورة",
      locationId: tweet.locationId || "all",
    }));
  },

  async getUserLikedTweets(userId: number) {
    const response = await fetch(`/api/users/${userId}/likes`);
    if (!response.ok) throw new Error("Failed to fetch user likes");
    const data: ApiTweet[] = await response.json();
    
    return data.map((tweet) => ({
      id: tweet.id.toString(),
      content: tweet.content,
      image: tweet.image || undefined,
      likes: tweet.likes,
      replies: tweet.replies,
      retweets: tweet.retweets,
      timestamp: getRelativeTime(new Date(tweet.createdAt)),
      location: tweet.locationName || "المدينة المنورة",
      locationId: tweet.locationId || "all",
      user: convertUser(tweet.user),
    }));
  },

  async getUserRetweetedTweets(userId: number) {
    const response = await fetch(`/api/users/${userId}/retweets`);
    if (!response.ok) throw new Error("Failed to fetch user retweets");
    const data: ApiTweet[] = await response.json();
    
    return data.map((tweet) => ({
      id: tweet.id.toString(),
      content: tweet.content,
      image: tweet.image || undefined,
      likes: tweet.likes,
      replies: tweet.replies,
      retweets: tweet.retweets,
      timestamp: getRelativeTime(new Date(tweet.createdAt)),
      location: tweet.locationName || "المدينة المنورة",
      locationId: tweet.locationId || "all",
      user: convertUser(tweet.user),
    }));
  },

  async followUser(userId: number): Promise<{ following: boolean }> {
    const response = await fetch(`/api/users/${userId}/follow`, {
      method: "POST",
    });
    if (!response.ok) {
      if (response.status === 401) throw new Error("يجب تسجيل الدخول");
      throw new Error("Failed to follow user");
    }
    return response.json();
  },

  async isFollowing(userId: number): Promise<boolean> {
    const response = await fetch(`/api/users/${userId}/following`);
    if (!response.ok) throw new Error("Failed to check follow status");
    const data = await response.json();
    return data.following;
  },

  async getFollowers(userId: number) {
    const response = await fetch(`/api/users/${userId}/followers`);
    if (!response.ok) throw new Error("Failed to fetch followers");
    const data: ApiUser[] = await response.json();
    return data.map(convertUser);
  },

  async getFollowingList(userId: number) {
    const response = await fetch(`/api/users/${userId}/following-list`);
    if (!response.ok) throw new Error("Failed to fetch following");
    const data: ApiUser[] = await response.json();
    return data.map(convertUser);
  },

  async hideAccount(userId: number): Promise<{ hidden: boolean; message: string }> {
    const response = await fetch(`/api/users/${userId}/hide`, {
      method: "POST",
    });
    if (!response.ok) {
      if (response.status === 401) throw new Error("يجب تسجيل الدخول");
      throw new Error("فشل في إخفاء الحساب");
    }
    return response.json();
  },

  async isAccountHidden(userId: number): Promise<boolean> {
    const response = await fetch(`/api/users/${userId}/hidden`);
    if (!response.ok) throw new Error("Failed to check hidden status");
    const data = await response.json();
    return data.hidden;
  },

  async getHiddenAccounts() {
    const response = await fetch("/api/hidden-accounts");
    if (!response.ok) throw new Error("Failed to fetch hidden accounts");
    const data: ApiUser[] = await response.json();
    return data.map(convertUser);
  },
};

// Events API
export const eventsApi = {
  async getEvents(locationId?: string) {
    const url = locationId
      ? `/api/events?locationId=${locationId}`
      : "/api/events";
    const response = await fetch(url);
    if (!response.ok) throw new Error("Failed to fetch events");
    const data: ApiEvent[] = await response.json();
    return data;
  },

  async getEvent(id: number) {
    const response = await fetch(`/api/events/${id}`);
    if (!response.ok) throw new Error("Failed to fetch event");
    return response.json() as Promise<ApiEvent>;
  },

  async createEvent(data: {
    title: string;
    description: string;
    image?: string;
    locationId?: string;
    locationName?: string;
    address?: string;
    eventDate: string;
    eventTime?: string;
    category: string;
    organizer?: string;
  }) {
    const response = await fetch("/api/events", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) {
      if (response.status === 401) throw new Error("يجب تسجيل الدخول");
      throw new Error("Failed to create event");
    }
    return response.json();
  },

  async toggleAttendance(eventId: number, status: "attending" | "interested"): Promise<{ event: ApiEvent; status: string | null }> {
    const response = await fetch(`/api/events/${eventId}/attend`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    if (!response.ok) {
      if (response.status === 401) throw new Error("يجب تسجيل الدخول");
      throw new Error("Failed to update attendance");
    }
    return response.json();
  },

  async getEventStatus(eventId: number): Promise<string | null> {
    const response = await fetch(`/api/events/${eventId}/status`);
    if (!response.ok) throw new Error("Failed to get event status");
    const data = await response.json();
    return data.status;
  },
};

// Auth API
export interface AuthUser {
  id: number;
  name: string;
  handle: string;
  email?: string;
  avatar: string;
  cover?: string | null;
  bio?: string | null;
  location?: string | null;
  website?: string | null;
  twitter?: string | null;
  snapchat?: string | null;
  tiktok?: string | null;
  linkedin?: string | null;
  verified?: boolean | null;
  following: number;
  followers: number;
  joinedAt: string;
  createdAt: string;
}

export const authApi = {
  async signup(data: { name: string; handle: string; email: string; password: string }) {
    const response = await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || "فشل في إنشاء الحساب");
    }
    return result as AuthUser;
  },

  async login(data: { email: string; password: string }) {
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || "فشل في تسجيل الدخول");
    }
    return result as AuthUser;
  },

  async logout() {
    const response = await fetch("/api/auth/logout", {
      method: "POST",
    });
    if (!response.ok) {
      throw new Error("فشل في تسجيل الخروج");
    }
    return response.json();
  },

  async getCurrentUser() {
    const response = await fetch("/api/auth/me");
    if (!response.ok) {
      if (response.status === 401) {
        return null;
      }
      throw new Error("فشل في جلب بيانات المستخدم");
    }
    return response.json() as Promise<AuthUser>;
  },

  async checkHandle(handle: string) {
    const response = await fetch(`/api/auth/check-handle/${handle}`);
    if (!response.ok) {
      throw new Error("فشل في التحقق من اسم المستخدم");
    }
    const result = await response.json();
    return result.available as boolean;
  },

  async updateProfile(data: {
    name?: string;
    bio?: string;
    location?: string;
    website?: string;
    twitter?: string;
    snapchat?: string;
    tiktok?: string;
    linkedin?: string;
  }) {
    const response = await fetch("/api/auth/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || "فشل في تحديث الملف الشخصي");
    }
    return result as AuthUser;
  },

  async forgotPassword(email: string) {
    const response = await fetch("/api/auth/forgot-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });
    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || "فشل في إرسال رمز التحقق");
    }
    return result as { message: string; code: string };
  },

  async resetPassword(email: string, code: string, newPassword: string) {
    const response = await fetch("/api/auth/reset-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, code, newPassword }),
    });
    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || "فشل في تغيير كلمة المرور");
    }
    return result as { message: string };
  },

  getAppleAuthUrl() {
    return "/api/auth/apple";
  },
};

export interface ApiChatMessage {
  id: number;
  userId: number;
  content: string;
  latitude: number;
  longitude: number;
  createdAt: string;
  user: ApiUser;
}

export const chatApi = {
  async getMessages(latitude: number, longitude: number, radius: number = 10): Promise<ApiChatMessage[]> {
    const response = await fetch(`/api/chat?lat=${latitude}&lng=${longitude}&radius=${radius}`);
    if (!response.ok) {
      throw new Error("فشل في جلب الرسائل");
    }
    return response.json();
  },

  async sendMessage(content: string, latitude: number, longitude: number): Promise<ApiChatMessage> {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content, latitude, longitude }),
    });
    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || "فشل في إرسال الرسالة");
    }
    return result;
  },
};
