import React, { createContext, useContext, useState, useCallback, useEffect, useRef } from "react";
import { neighborhoodsApi } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { findNearestNeighborhood, neighborhoodCoordinates } from "./neighborhood-coordinates";

type Neighborhood = {
  id: string;
  name: string;
};

type LocationContextType = {
  locationId: string;
  setLocationId: (id: string) => void;
  selectedLocation: Neighborhood | null;
  neighborhoods: Neighborhood[];
  gpsStatus: 'idle' | 'loading' | 'success' | 'error' | 'denied';
  userCoords: { lat: number; lng: number } | null;
  detectLocation: () => void;
  detectedNeighborhood: Neighborhood | null;
  isReady: boolean;
};

const LocationContext = createContext<LocationContextType | undefined>(undefined);

export function LocationProvider({ children }: { children: React.ReactNode }) {
  const [locationId, setLocationId] = useState("all");
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'loading' | 'success' | 'error' | 'denied'>('idle');
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [detectedNeighborhood, setDetectedNeighborhood] = useState<Neighborhood | null>(null);
  const pendingDetection = useRef(false);
  
  const { data: neighborhoods = [], isLoading } = useQuery({
    queryKey: ['neighborhoods'],
    queryFn: neighborhoodsApi.getNeighborhoods,
  });
  
  const isReady = !isLoading && neighborhoods.length > 0;
  const selectedLocation = neighborhoods.find(n => n.id === locationId) || null;

  const performDetection = useCallback(() => {
    if (!navigator.geolocation) {
      setGpsStatus('error');
      return;
    }

    setGpsStatus('loading');

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setUserCoords({ lat: latitude, lng: longitude });
        
        const nearest = findNearestNeighborhood(latitude, longitude);
        if (nearest) {
          setDetectedNeighborhood({ id: nearest.id, name: nearest.name });
          setLocationId(nearest.id);
          setGpsStatus('success');
        } else {
          setGpsStatus('error');
        }
      },
      (error) => {
        if (error.code === error.PERMISSION_DENIED) {
          setGpsStatus('denied');
        } else {
          setGpsStatus('error');
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000
      }
    );
  }, []);

  const detectLocation = useCallback(() => {
    if (isReady) {
      performDetection();
    } else {
      pendingDetection.current = true;
      setGpsStatus('loading');
    }
  }, [isReady, performDetection]);

  useEffect(() => {
    if (isReady && pendingDetection.current) {
      pendingDetection.current = false;
      performDetection();
    }
  }, [isReady, performDetection]);

  return (
    <LocationContext.Provider value={{ 
      locationId, 
      setLocationId, 
      selectedLocation, 
      neighborhoods,
      gpsStatus,
      userCoords,
      detectLocation,
      detectedNeighborhood,
      isReady
    }}>
      {children}
    </LocationContext.Provider>
  );
}

export function useLocationContext() {
  const context = useContext(LocationContext);
  if (context === undefined) {
    throw new Error("useLocationContext must be used within a LocationProvider");
  }
  return context;
}
